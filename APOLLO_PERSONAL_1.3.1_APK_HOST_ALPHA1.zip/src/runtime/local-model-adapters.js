import { LocalOpenAIClient } from './openai-compatible-client.js';
import { ResidencyBoundClient } from './residency-bound-client.js';
import { createKnowledgePacket } from '../intelligence/knowledge-packet.js';

const CAPABILITY_SET = new Set([
  'general_knowledge', 'scientific_reasoning', 'technical_explanation', 'comparison',
  'summarization', 'editorial_writing', 'mathematics', 'language_translation', 'conversation_context'
]);
const STRATEGIES = new Set(['explain_concept', 'editorial_article', 'compare_options', 'study_guide', 'conversation_reply']);
const CLAIM_KINDS = new Set(['fact', 'inference', 'hypothesis', 'definition', 'unknown']);

function parseJsonObject(text, label) {
  if (typeof text !== 'string' || !text.trim()) throw new Error(`${label} returned empty content`);
  const stripped = text.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
  try {
    const value = JSON.parse(stripped);
    if (value && typeof value === 'object' && !Array.isArray(value)) return value;
  } catch {}
  const start = stripped.indexOf('{');
  if (start >= 0) {
    let depth = 0;
    let inString = false;
    let escaped = false;
    for (let i = start; i < stripped.length; i++) {
      const char = stripped[i];
      if (inString) {
        if (escaped) escaped = false;
        else if (char === '\\') escaped = true;
        else if (char === '"') inString = false;
        continue;
      }
      if (char === '"') inString = true;
      else if (char === '{') depth++;
      else if (char === '}' && --depth === 0) {
        const candidate = JSON.parse(stripped.slice(start, i + 1));
        if (candidate && typeof candidate === 'object' && !Array.isArray(candidate)) return candidate;
      }
    }
  }
  throw new Error(`${label} did not return a valid JSON object`);
}

function sanitizeClaims(rawClaims, modelId, prefix = 'claim') {
  if (!Array.isArray(rawClaims) || rawClaims.length < 1 || rawClaims.length > 80) throw new Error('Model must return 1–80 claims');
  return rawClaims.map((claim, index) => {
    if (!claim || typeof claim !== 'object' || typeof claim.text !== 'string' || !claim.text.trim() || claim.text.length > 12_000) {
      throw new Error(`Invalid claim at index ${index}`);
    }
    const kind = CLAIM_KINDS.has(claim.kind) ? claim.kind : 'unknown';
    const id = typeof claim.id === 'string' && /^[A-Za-z][A-Za-z0-9._:-]{0,79}$/.test(claim.id) ? claim.id : `${prefix}-${index + 1}`;
    // A model identifier is provenance, not an external citation or verification.
    return {
      id,
      text: claim.text.trim(),
      kind,
      sourceRefs: [`model-output:${modelId}`],
      ...(typeof claim.caveat === 'string' && claim.caveat.length <= 2000 ? { caveat: claim.caveat } : {})
    };
  });
}

async function makePacket({ title, rawClaims, modelId, collection }) {
  const claims = sanitizeClaims(rawClaims, modelId);
  const { packet } = await createKnowledgePacket({
    title: typeof title === 'string' && title.trim() ? title.trim().slice(0, 240) : 'Apollo model response',
    claims,
    metadata: { createdBy: modelId, collection, language: 'en' }
  });
  return packet;
}

function historyBeforeLatest(history, latestText) {
  const recent = (Array.isArray(history) ? history : []).slice(-10);
  const last = recent.at(-1);
  if (last?.role === 'user' && typeof last.text === 'string' && last.text.trim() === String(latestText).trim()) recent.pop();
  return recent.map(turn => ({ role: turn.role, content: turn.text }));
}

function systemMessage(content) { return { role: 'system', content }; }

export class LocalSlmControllerAdapter {
  constructor({ client, modelId = client?.model ?? 'apollo-controller' } = {}) {
    if (!client || typeof client.complete !== 'function') throw new TypeError('A LocalOpenAIClient is required');
    this.client = client;
    this.modelId = modelId;
  }

  async plan({ latestMessage, history = [], signal } = {}) {
    const recent = historyBeforeLatest(history, latestMessage).slice(-8);
    const result = await this.client.complete({
      signal,
      temperature: 0,
      maxTokens: 220,
      responseFormat: { type: 'json_object' },
      messages: [
        systemMessage(`You are Apollo's lightweight routing controller. Classify the request and return ONLY JSON: {"needsMoE":boolean,"capabilities":string[],"strategyId":string}. Allowed capabilities: ${[...CAPABILITY_SET].join(', ')}. Allowed strategies: ${[...STRATEGIES].join(', ')}. Delegate only when deeper reasoning or broad knowledge is useful. Never request tools, scripts, network, file access or executable actions.`),
        ...recent,
        { role: 'user', content: latestMessage }
      ]
    });
    const value = parseJsonObject(result.text, 'Apollo controller planner');
    if (Object.keys(value).some(key => !['needsMoE', 'capabilities', 'strategyId'].includes(key))) throw new Error('Controller returned unapproved plan fields');
    if (typeof value.needsMoE !== 'boolean' || !Array.isArray(value.capabilities) || value.capabilities.some(item => !CAPABILITY_SET.has(item))) throw new Error('Controller returned unsupported capabilities');
    if (!STRATEGIES.has(value.strategyId)) value.strategyId = 'conversation_reply';
    return { needsMoE: value.needsMoE, capabilities: [...new Set(value.capabilities)], strategyId: value.strategyId };
  }

  async generate({ prompt, history = [], capabilities = [], signal } = {}) {
    const response = await this.respond({ prompt, history, signal, plan: { needsMoE: false, capabilities } });
    return response;
  }

  async respond({ prompt, history = [], signal } = {}) {
    const result = await this.client.complete({
      signal,
      temperature: 0.35,
      maxTokens: 1200,
      responseFormat: { type: 'json_object' },
      messages: [
        systemMessage('You are Apollo, an offline personal assistant. Return ONLY JSON with keys title and claims. claims is an array of objects {id,text,kind,caveat?}. Use only: fact, inference, hypothesis, definition, unknown. Do not invent citations. Admit uncertainty. Do not request tools or execute actions.'),
        ...historyBeforeLatest(history, prompt).slice(-8),
        { role: 'user', content: prompt }
      ]
    });
    const value = parseJsonObject(result.text, 'Apollo controller');
    return { knowledgePacket: await makePacket({ title: value.title, rawClaims: value.claims, modelId: this.modelId, collection: 'controller-response' }) };
  }
}

export class LocalMoEChildAdapter {
  constructor({ client, modelId = client?.model ?? 'apollo-sleeping-giant' } = {}) {
    if (!client || typeof client.complete !== 'function') throw new TypeError('A LocalOpenAIClient is required');
    this.client = client;
    this.modelId = modelId;
  }

  async generate({ prompt, history = [], capabilities = [], signal } = {}) {
    if (!Array.isArray(capabilities) || capabilities.length > 16 || capabilities.some(item => !CAPABILITY_SET.has(item))) throw new TypeError('Unsupported MoE capability request');
    const result = await this.client.complete({
      signal,
      temperature: 0.25,
      maxTokens: 2400,
      responseFormat: { type: 'json_object' },
      messages: [
        systemMessage(`You are the Sleeping Giant, Apollo's local specialist model. Return ONLY JSON {"title":string,"claims":[{"id":string,"text":string,"kind":string,"caveat"?:string}]}. Capabilities requested: ${capabilities.join(', ')}. Make the answer substantial but concise. Use only the approved epistemic kinds fact, inference, hypothesis, definition, unknown. Do not invent citations or tools. Clearly qualify uncertainty.`),
        ...historyBeforeLatest(history, prompt).slice(-10),
        { role: 'user', content: prompt }
      ]
    });
    const value = parseJsonObject(result.text, 'Apollo Sleeping Giant');
    return { knowledgePacket: await makePacket({ title: value.title, rawClaims: value.claims, modelId: this.modelId, collection: 'moe-child-response' }) };
  }
}

export class LocalEditorialAdapter {
  constructor({ client, modelId = client?.model ?? 'apollo-editor' } = {}) {
    if (!client || typeof client.complete !== 'function') throw new TypeError('A LocalOpenAIClient is required');
    this.client = client;
    this.modelId = modelId;
  }

  async rewrite({ prompt, draft, knowledgePacket, expectedClaimIds, signal } = {}) {
    const result = await this.client.complete({
      signal,
      temperature: 0.15,
      maxTokens: 1800,
      responseFormat: { type: 'json_object' },
      messages: [
        systemMessage('You are Apollo\'s editorial editor. Rewrite the supplied draft in polished, uncluttered encyclopedia prose. Preserve every claim ID in preservedClaimIds. Do not add unsupported facts, remove caveats, invent sources or alter the certainty of claims. Return ONLY JSON {"text":string,"preservedClaimIds":string[]}. If a claim cannot be safely integrated, retain it clearly qualified.'),
        { role: 'user', content: JSON.stringify({ prompt, draft, claims: knowledgePacket.claims.map(({ id, text, kind, caveat }) => ({ id, text, kind, caveat })), expectedClaimIds }) }
      ]
    });
    const value = parseJsonObject(result.text, 'Apollo editorial engine');
    return { text: value.text, preservedClaimIds: value.preservedClaimIds };
  }
}


export class LocalDreamDirectorAdapter {
  constructor({ client, modelId = client?.model ?? 'apollo-dream-director' } = {}) {
    if (!client || typeof client.complete !== 'function') throw new TypeError('A LocalOpenAIClient is required');
    this.client = client;
    this.modelId = modelId;
  }

  async plan({ objective, signal } = {}) {
    const result = await this.client.complete({
      signal,
      temperature: 0.35,
      maxTokens: 900,
      responseFormat: { type: 'json_object' },
      messages: [
        systemMessage('You are Apollo Dream Director. Plan a coherent educational/editorial text experience. Return ONLY JSON {"title":string,"sections":[{"id":lowercase_snake_or_hyphen_id,"title":string,"objective":string,"capabilities":string[]}]} with 2–8 sections. Allowed capabilities: ' + [...CAPABILITY_SET].join(', ') + '. Avoid redundant sections. Do not produce factual claims in the plan. No tools, scripts or executable code.'),
        { role: 'user', content: objective }
      ]
    });
    const value = parseJsonObject(result.text, 'Apollo Dream Director');
    return { title: value.title, sections: value.sections };
  }
}

export class LocalDreamSectionGenerator {
  constructor({ generator, fallback = null } = {}) {
    if (!generator || typeof generator.generate !== 'function') throw new TypeError('A section generator is required');
    if (fallback && typeof fallback.generate !== 'function') throw new TypeError('Dream fallback must implement generate');
    this.generator = generator;
    this.fallback = fallback;
    this.usesMoE = generator instanceof LocalMoEChildAdapter;
  }

  async generate({ objective, title, capabilities, signal } = {}) {
    const request = { prompt: `${title}\n\n${objective}`, capabilities, history: [], signal };
    try {
      const result = await this.generator.generate(request);
      return { ...result, delegatedToMoE: this.usesMoE };
    } catch (error) {
      if (signal?.aborted || !this.fallback) throw error;
      const fallback = await this.fallback.generate(request);
      return { ...fallback, delegatedToMoE: false, fallbackReason: 'sleeping_giant_unavailable' };
    }
  }
}

function createInferenceClient(config) {
  if (config instanceof LocalOpenAIClient || (config && typeof config.complete === 'function')) return config;
  if (!config || typeof config !== 'object') throw new TypeError('A local model configuration is required');
  const localClient = new LocalOpenAIClient(config);
  if (config.residencyManager) {
    return new ResidencyBoundClient({
      manager: config.residencyManager,
      modelId: config.residencyModelId ?? config.model,
      client: localClient,
      contextWindow: config.contextWindow ?? 2048
    });
  }
  return localClient;
}

export function createLocalApolloAdapters({ controller, moe, editor } = {}) {
  const controllerClient = createInferenceClient(controller);
  const moeClient = moe ? createInferenceClient(moe) : null;
  const editorClient = editor ? createInferenceClient(editor) : controllerClient;
  const controllerAdapter = new LocalSlmControllerAdapter({ client: controllerClient });
  const moeAdapter = moeClient ? new LocalMoEChildAdapter({ client: moeClient }) : null;
  return Object.freeze({
    controller: controllerAdapter,
    moeChild: moeAdapter,
    editor: new LocalEditorialAdapter({ client: editorClient }),
    dreamDirector: new LocalDreamDirectorAdapter({ client: controllerClient }),
    dreamSectionGenerator: new LocalDreamSectionGenerator({ generator: moeAdapter ?? controllerAdapter, fallback: moeAdapter ? controllerAdapter : null })
  });
}

export { parseJsonObject };
