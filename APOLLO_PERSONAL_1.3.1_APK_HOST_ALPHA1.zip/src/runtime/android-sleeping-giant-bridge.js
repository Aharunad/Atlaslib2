/**
 * Async bridge for the Android host's AtlasApolloModelHost JavaScript interface.
 * Native callbacks are delivered as `atlas-apollo-native-result` events.
 */
export class AndroidSleepingGiantBridgeError extends Error {
  constructor(message, code = 'ANDROID_MODEL_HOST') {
    super(message);
    this.name = 'AndroidSleepingGiantBridgeError';
    this.code = code;
  }
}

export class AndroidSleepingGiantBridge {
  constructor({ host = globalThis.AtlasApolloModelHost, eventTarget = globalThis.window, timeoutMs = 4 * 60 * 60 * 1000 } = {}) {
    this.host = host;
    this.eventTarget = eventTarget;
    this.timeoutMs = timeoutMs;
    this.pending = new Map();
    this.tokenListeners = new Map();
    this.onNativeResult = this.onNativeResult.bind(this);
    this.onNativeToken = this.onNativeToken.bind(this);
    this.eventTarget?.addEventListener?.('atlas-apollo-native-result', this.onNativeResult);
    this.eventTarget?.addEventListener?.('atlas-apollo-native-token', this.onNativeToken);
  }

  get available() {
    return Boolean(this.host && typeof this.host.importSleepingGiant === 'function');
  }

  get deviceProfileAvailable() {
    return Boolean(this.host && typeof this.host.getDeviceProfile === 'function');
  }

  get runtimeAvailable() {
    return Boolean(this.host && typeof this.host.getRuntimeCapabilities === 'function'
      && typeof this.host.loadSleepingGiant === 'function'
      && typeof this.host.generateSleepingGiant === 'function');
  }

  getDeviceProfile() {
    if (!this.deviceProfileAvailable) {
      return Promise.reject(new AndroidSleepingGiantBridgeError('Android device profiling is unavailable in this host.', 'DEVICE_PROFILE_UNAVAILABLE'));
    }
    const requestId = `sg-device-${globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(16).slice(2)}`}`;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(requestId);
        reject(new AndroidSleepingGiantBridgeError('Android device-profile request timed out', 'DEVICE_PROFILE_TIMEOUT'));
      }, 15_000);
      this.pending.set(requestId, { resolve, reject, timer });
      try { this.host.getDeviceProfile(requestId); }
      catch (error) {
        clearTimeout(timer);
        this.pending.delete(requestId);
        reject(new AndroidSleepingGiantBridgeError(error?.message || 'Android device profiling failed', 'DEVICE_PROFILE_FAILED'));
      }
    }).then(result => {
      if (!result?.profile || result.profile.platform !== 'android') {
        throw new AndroidSleepingGiantBridgeError('Android returned an invalid device profile', 'DEVICE_PROFILE_INVALID');
      }
      return result.profile;
    });
  }

  getRuntimeCapabilities() {
    if (!this.host || typeof this.host.getRuntimeCapabilities !== 'function') {
      return Promise.resolve(Object.freeze({ available: false, formats: [], architectureCandidates: [], reason: 'Native inference runtime is not connected.' }));
    }
    return this.#request('getRuntimeCapabilities', [], 'RUNTIME_CAPABILITIES', 15_000)
      .then(result => {
        const caps = result?.runtimeCapabilities;
        if (!caps || typeof caps.available !== 'boolean' || !Array.isArray(caps.formats) || !Array.isArray(caps.architectureCandidates)) {
          throw new AndroidSleepingGiantBridgeError('Android returned invalid runtime capabilities', 'RUNTIME_CAPABILITIES_INVALID');
        }
        return Object.freeze({
          available: caps.available,
          version: typeof caps.version === 'string' ? caps.version : null,
          formats: caps.formats.filter(value => typeof value === 'string').slice(0, 16),
          architectureCandidates: caps.architectureCandidates.filter(value => typeof value === 'string').slice(0, 256),
          backend: typeof caps.backend === 'string' ? caps.backend : null,
          gpuOffload: caps.gpuOffload === true,
          reason: typeof caps.reason === 'string' ? caps.reason : null
        });
      });
  }

  loadSleepingGiant(assetId, { contextTokens, threads, batchTokens } = {}) {
    if (!this.runtimeAvailable) return Promise.reject(new AndroidSleepingGiantBridgeError('Native llama.cpp runtime is unavailable in this Atlas Library build.', 'RUNTIME_UNAVAILABLE'));
    if (typeof assetId !== 'string' || !/^sg-[a-f0-9]{24}$/.test(assetId)) return Promise.reject(new TypeError('Invalid Sleeping Giant asset ID'));
    for (const [key, value, min, max] of [['contextTokens', contextTokens, 256, 131072], ['threads', threads, 1, 32], ['batchTokens', batchTokens, 8, 512]]) {
      if (!Number.isSafeInteger(value) || value < min || value > max) return Promise.reject(new RangeError(`${key} is outside the native runtime limits`));
    }
    return this.#request('loadSleepingGiant', [assetId, contextTokens, threads, batchTokens], 'RUNTIME_LOAD', this.timeoutMs)
      .then(result => {
        if (typeof result.sessionId !== 'string' || !result.modelInfo || typeof result.modelInfo !== 'object') {
          throw new AndroidSleepingGiantBridgeError('Native runtime returned an invalid loaded-session record', 'RUNTIME_LOAD_INVALID');
        }
        return Object.freeze({ sessionId: result.sessionId, assetId, modelInfo: result.modelInfo, runtime: result.runtime ?? null });
      });
  }

  generateSleepingGiant({ sessionId, messages, maxTokens = 1200, responseFormat = null, temperature = 0.2, signal, onToken } = {}) {
    if (!this.runtimeAvailable || typeof this.host.generateSleepingGiant !== 'function') return Promise.reject(new AndroidSleepingGiantBridgeError('Native generation is unavailable.', 'RUNTIME_UNAVAILABLE'));
    if (typeof sessionId !== 'string' || !/^[0-9a-fA-F-]{36}$/.test(sessionId)) return Promise.reject(new TypeError('Invalid native model session ID'));
    if (!Array.isArray(messages) || messages.length < 1 || messages.length > 32 || messages.some(message => !message || !['system', 'user', 'assistant'].includes(message.role) || typeof message.content !== 'string' || message.content.length > 48 * 1024)) {
      return Promise.reject(new TypeError('Invalid native chat messages'));
    }
    if (!Number.isSafeInteger(maxTokens) || maxTokens < 1 || maxTokens > 8192) return Promise.reject(new RangeError('maxTokens must be between 1 and 8192'));
    const format = responseFormat == null || responseFormat === 'text' ? '' : typeof responseFormat === 'object' ? responseFormat.type : responseFormat;
    if (!['', 'json_object'].includes(format)) return Promise.reject(new TypeError('responseFormat must be text or json_object'));
    if (typeof temperature !== 'number' || !Number.isFinite(temperature) || temperature < 0 || temperature > 2) return Promise.reject(new RangeError('temperature must be between 0 and 2'));
    const requestId = `sg-generate-${globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(16).slice(2)}`}`;
    const abort = () => { try { this.host.cancelSleepingGiant?.(sessionId); } catch {} };
    if (signal?.aborted) return Promise.reject(new AndroidSleepingGiantBridgeError('Native inference cancelled', 'RUNTIME_CANCELLED'));
    signal?.addEventListener('abort', abort, { once: true });
    if (typeof onToken === 'function') this.tokenListeners.set(requestId, onToken);
    return this.#requestWithId(requestId, 'generateSleepingGiant', [sessionId, JSON.stringify(messages), maxTokens, format, temperature], 'RUNTIME_GENERATE', this.timeoutMs)
      .then(result => {
        if (result.cancelled || signal?.aborted) throw new AndroidSleepingGiantBridgeError('Native inference cancelled', 'RUNTIME_CANCELLED');
        if (typeof result.text !== 'string') throw new AndroidSleepingGiantBridgeError('Native runtime returned no generated text', 'RUNTIME_EMPTY_OUTPUT');
        const metrics = result.metrics && typeof result.metrics === 'object' ? Object.freeze({
          promptTokens: Number.isFinite(result.metrics.promptTokens) ? result.metrics.promptTokens : null,
          generatedTokens: Number.isFinite(result.metrics.generatedTokens) ? result.metrics.generatedTokens : null,
          promptMs: Number.isFinite(result.metrics.promptMs) ? result.metrics.promptMs : null,
          generationMs: Number.isFinite(result.metrics.generationMs) ? result.metrics.generationMs : null,
          promptTokensPerSecond: Number.isFinite(result.metrics.promptTokensPerSecond) ? result.metrics.promptTokensPerSecond : null,
          generationTokensPerSecond: Number.isFinite(result.metrics.generationTokensPerSecond) ? result.metrics.generationTokensPerSecond : null
        }) : null;
        return Object.freeze({ text: result.text, cancelled: false, sessionId, metrics });
      })
      .finally(() => {
        signal?.removeEventListener('abort', abort);
        this.tokenListeners.delete(requestId);
      });
  }

  cancelSleepingGiant(sessionId) {
    if (typeof sessionId !== 'string' || !/^[0-9a-fA-F-]{36}$/.test(sessionId)) return false;
    if (!this.host || typeof this.host.cancelSleepingGiant !== 'function') return false;
    this.host.cancelSleepingGiant(sessionId);
    return true;
  }

  unloadSleepingGiant(sessionId) {
    if (typeof sessionId !== 'string' || !/^[0-9a-fA-F-]{36}$/.test(sessionId)) return Promise.reject(new TypeError('Invalid native model session ID'));
    return this.#request('unloadSleepingGiant', [sessionId], 'RUNTIME_UNLOAD', 60_000).then(result => result.unloaded === true);
  }

  #request(method, args, code, timeoutMs) {
    const requestId = `sg-${method}-${globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(16).slice(2)}`}`;
    return this.#requestWithId(requestId, method, args, code, timeoutMs);
  }

  #requestWithId(requestId, method, args, code, timeoutMs) {
    if (!this.host || typeof this.host[method] !== 'function') return Promise.reject(new AndroidSleepingGiantBridgeError(`Android host does not expose ${method}`, `${code}_UNAVAILABLE`));
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(requestId);
        reject(new AndroidSleepingGiantBridgeError(`${method} timed out`, `${code}_TIMEOUT`));
      }, timeoutMs);
      this.pending.set(requestId, { resolve, reject, timer });
      try { this.host[method](requestId, ...args); }
      catch (error) {
        clearTimeout(timer);
        this.pending.delete(requestId);
        reject(new AndroidSleepingGiantBridgeError(error?.message || `${method} failed`, `${code}_FAILED`));
      }
    });
  }

  onNativeToken(event) {
    const detail = event?.detail;
    const listener = detail?.requestId ? this.tokenListeners.get(detail.requestId) : null;
    if (!listener || typeof detail.token !== 'string') return;
    try { listener(detail.token); } catch { /* listener failures do not interrupt native inference */ }
  }

  onNativeResult(event) {
    const detail = event?.detail;
    const pending = detail?.requestId ? this.pending.get(detail.requestId) : null;
    if (!pending) return;
    this.pending.delete(detail.requestId);
    clearTimeout(pending.timer);
    if (detail.ok === true) pending.resolve(detail);
    else if (detail.cancelled === true) pending.resolve(detail);
    else pending.reject(new AndroidSleepingGiantBridgeError(detail.error || 'Native model import failed', detail.code || 'IMPORT_FAILED'));
  }

  importSleepingGiant() {
    if (!this.available) {
      return Promise.reject(new AndroidSleepingGiantBridgeError('Android model storage is not connected. Open Apollo inside the Atlas Library Android host to select a model.', 'HOST_UNAVAILABLE'));
    }
    const requestId = `sg-import-${globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(16).slice(2)}`}`;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(requestId);
        reject(new AndroidSleepingGiantBridgeError('Model import timed out. The incomplete private copy will be cleaned up by the Android host.', 'IMPORT_TIMEOUT'));
      }, this.timeoutMs);
      this.pending.set(requestId, { resolve, reject, timer });
      try { this.host.importSleepingGiant(requestId); }
      catch (error) {
        clearTimeout(timer);
        this.pending.delete(requestId);
        reject(new AndroidSleepingGiantBridgeError(error?.message || 'Android model picker could not be opened', 'PICKER_FAILED'));
      }
    });
  }

  async removeModelAsset(assetId) {
    if (!this.host || typeof this.host.removeSleepingGiant !== 'function') {
      throw new AndroidSleepingGiantBridgeError('Android host does not expose private model removal', 'REMOVE_UNAVAILABLE');
    }
    const requestId = `sg-remove-${globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(16).slice(2)}`}`;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(requestId);
        reject(new AndroidSleepingGiantBridgeError('Model removal timed out', 'REMOVE_TIMEOUT'));
      }, 30_000);
      this.pending.set(requestId, { resolve, reject, timer });
      try { this.host.removeSleepingGiant(requestId, assetId); }
      catch (error) {
        clearTimeout(timer);
        this.pending.delete(requestId);
        reject(error);
      }
    });
  }

  dispose() {
    this.eventTarget?.removeEventListener?.('atlas-apollo-native-result', this.onNativeResult);
    this.eventTarget?.removeEventListener?.('atlas-apollo-native-token', this.onNativeToken);
    this.tokenListeners.clear();
    for (const pending of this.pending.values()) {
      clearTimeout(pending.timer);
      pending.reject(new AndroidSleepingGiantBridgeError('Android model bridge was closed', 'BRIDGE_CLOSED'));
    }
    this.pending.clear();
  }
}
