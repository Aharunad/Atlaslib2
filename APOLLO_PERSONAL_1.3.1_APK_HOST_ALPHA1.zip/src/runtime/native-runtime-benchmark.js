/**
 * Repeatable, local-only smoke benchmark for a loaded native GGUF session.
 * Timings are supplied by the native runtime. This module does not estimate
 * throughput from wall-clock time around UI rendering.
 */
export async function benchmarkNativeModel(client, { maxTokens = 96 } = {}) {
  if (!client || typeof client.complete !== 'function') {
    throw new TypeError('A compatible local model client is required');
  }
  if (!Number.isSafeInteger(maxTokens) || maxTokens < 16 || maxTokens > 512) {
    throw new RangeError('Benchmark output must be between 16 and 512 tokens');
  }

  const result = await client.complete({
    messages: [
      {
        role: 'system',
        content: 'You are participating in a local inference benchmark. Answer clearly and naturally. Do not mention the benchmark.'
      },
      {
        role: 'user',
        content: 'Explain why a phone should use a locally stored language model. Give practical examples, important trade-offs, and a concise conclusion.'
      }
    ],
    maxTokens,
    responseFormat: 'text',
    temperature: 0
  });

  const metrics = result?.usage;
  const positive = value => Number.isFinite(value) && value > 0;
  if (typeof result?.text !== 'string' || !result.text.trim() || !metrics ||
      !positive(metrics.promptTokens) || !positive(metrics.generatedTokens) ||
      !positive(metrics.promptMs) || !positive(metrics.generationMs) ||
      !positive(metrics.promptTokensPerSecond) || !positive(metrics.generationTokensPerSecond)) {
    throw new Error('The native runtime did not return a complete benchmark result');
  }

  return Object.freeze({
    model: typeof result.model === 'string' ? result.model : 'local-gguf',
    promptTokens: metrics.promptTokens,
    generatedTokens: metrics.generatedTokens,
    promptMs: metrics.promptMs,
    generationMs: metrics.generationMs,
    promptTokensPerSecond: metrics.promptTokensPerSecond,
    generationTokensPerSecond: metrics.generationTokensPerSecond
  });
}
