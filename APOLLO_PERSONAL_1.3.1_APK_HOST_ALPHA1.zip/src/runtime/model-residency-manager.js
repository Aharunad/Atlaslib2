const MIB = 1024 * 1024;

export class ModelResidencyError extends Error {
  constructor(code, message, details = {}) {
    super(message);
    this.name = 'ModelResidencyError';
    this.code = code;
    this.details = Object.freeze({ ...details });
  }
}

function finiteNonNegative(value, name) {
  if (!Number.isFinite(value) || value < 0) {
    throw new TypeError(`${name} must be a finite non-negative number`);
  }
  return value;
}

function throwIfAborted(signal) {
  if (signal?.aborted) {
    throw new ModelResidencyError('ABORTED', 'Model request was cancelled before admission');
  }
}

/**
 * Calculates a conservative per-process AI memory budget from live OS telemetry.
 * The host application must provide available RAM; this module never assumes
 * that the device's advertised RAM is actually free.
 */
export function calculateAiMemoryBudget(snapshot, policy = {}) {
  if (!snapshot || typeof snapshot !== 'object') throw new TypeError('A live memory snapshot is required');
  const totalBytes = finiteNonNegative(snapshot.totalBytes, 'snapshot.totalBytes');
  const availableBytes = finiteNonNegative(snapshot.availableBytes, 'snapshot.availableBytes');
  if (totalBytes <= 0 || availableBytes > totalBytes) throw new TypeError('Invalid device memory snapshot');

  const memoryClassMb = Number.isFinite(snapshot.memoryClassMb)
    ? snapshot.memoryClassMb
    : totalBytes / MIB;
  const hardCapBytes = policy.hardCapBytes ?? (memoryClassMb <= 4096 ? 1200 : memoryClassMb <= 6144 ? 1536 : 2048) * MIB;
  const reserveBytes = policy.systemReserveBytes ?? 384 * MIB;
  const usableFraction = policy.usableFraction ?? 0.9;
  const thermalScale = policy.thermalScale ?? { nominal: 1, light: 0.9, moderate: 0.75, severe: 0, critical: 0 };

  finiteNonNegative(hardCapBytes, 'policy.hardCapBytes');
  finiteNonNegative(reserveBytes, 'policy.systemReserveBytes');
  if (!(usableFraction > 0 && usableFraction <= 1)) throw new TypeError('policy.usableFraction must be in (0, 1]');

  const thermal = snapshot.thermalStatus ?? 'nominal';
  const thermalFactor = thermalScale[thermal];
  if (!Number.isFinite(thermalFactor) || thermalFactor < 0 || thermalFactor > 1) {
    throw new TypeError(`Unknown thermal status: ${thermal}`);
  }

  if (snapshot.lowMemory === true || thermalFactor === 0) {
    return Object.freeze({ budgetBytes: 0, availableBytes, hardCapBytes, reserveBytes, thermal, reason: snapshot.lowMemory ? 'OS_LOW_MEMORY' : 'THERMAL_LIMIT' });
  }

  const headroom = Math.max(0, availableBytes - reserveBytes);
  const budgetBytes = Math.min(hardCapBytes, Math.floor(headroom * usableFraction * thermalFactor));
  return Object.freeze({ budgetBytes, availableBytes, hardCapBytes, reserveBytes, thermal, reason: 'OK' });
}

function normalizeModelDescriptor(input) {
  if (!input || typeof input !== 'object') throw new TypeError('Model descriptor must be an object');
  const { id, role, baseWorkingSetBytes, kvBytesPerToken = 0, maxContextTokens = 8192, cachePolicy = 'warm', evictionPriority = 50 } = input;
  if (typeof id !== 'string' || !/^[a-z0-9][a-z0-9._-]{1,95}$/i.test(id)) throw new TypeError('Invalid model id');
  if (!['controller', 'moe', 'editor', 'asr', 'tts'].includes(role)) throw new TypeError(`Unsupported model role for ${id}`);
  finiteNonNegative(baseWorkingSetBytes, `${id}.baseWorkingSetBytes`);
  finiteNonNegative(kvBytesPerToken, `${id}.kvBytesPerToken`);
  if (!Number.isSafeInteger(maxContextTokens) || maxContextTokens < 1 || maxContextTokens > 131072) throw new TypeError(`${id}.maxContextTokens is invalid`);
  if (!['warm', 'ephemeral'].includes(cachePolicy)) throw new TypeError(`${id}.cachePolicy must be warm or ephemeral`);
  if (!Number.isFinite(evictionPriority)) throw new TypeError(`${id}.evictionPriority must be finite`);
  return Object.freeze({ id, role, baseWorkingSetBytes, kvBytesPerToken, maxContextTokens, cachePolicy, evictionPriority });
}

/**
 * Coordinates model loading, warm residency, KV reservations and eviction.
 * The native inference runtime is injected via { load, unload }; this keeps
 * the core independent from ExecuTorch, llama.cpp, MLC or vendor-specific APIs.
 *
 * Only model loading/unloading/admission is serialized. Inference itself runs
 * outside the manager and can use the returned lease handle.
 */
export class ModelResidencyManager {
  constructor({ catalog, loader, getMemorySnapshot, policy = {}, now = () => Date.now() } = {}) {
    if (!Array.isArray(catalog) || catalog.length === 0) throw new TypeError('A non-empty model catalog is required');
    if (!loader || typeof loader.load !== 'function' || typeof loader.unload !== 'function') throw new TypeError('loader.load and loader.unload are required');
    if (typeof getMemorySnapshot !== 'function') throw new TypeError('getMemorySnapshot is required');
    this.catalog = new Map();
    for (const item of catalog) {
      const descriptor = normalizeModelDescriptor(item);
      if (this.catalog.has(descriptor.id)) throw new TypeError(`Duplicate model id: ${descriptor.id}`);
      this.catalog.set(descriptor.id, descriptor);
    }
    this.loader = loader;
    this.getMemorySnapshot = getMemorySnapshot;
    this.policy = policy;
    this.now = now;
    this.residents = new Map();
    this.leases = new Map();
    this.sequence = 0;
    this.tail = Promise.resolve();
    this.disposed = false;
  }

  async acquire(modelId, { contextTokens = 1024, signal } = {}) {
    return this.#exclusive(async () => {
      this.#assertOpen();
      throwIfAborted(signal);
      const descriptor = this.catalog.get(modelId);
      if (!descriptor) throw new ModelResidencyError('UNKNOWN_MODEL', `Model is not registered: ${modelId}`);
      if (!Number.isSafeInteger(contextTokens) || contextTokens < 1 || contextTokens > descriptor.maxContextTokens) {
        throw new ModelResidencyError('INVALID_CONTEXT', `Context length is invalid for ${modelId}`, { contextTokens, maxContextTokens: descriptor.maxContextTokens });
      }

      const kvBytes = descriptor.kvBytesPerToken * contextTokens;
      const budget = await this.#readBudget();
      throwIfAborted(signal);
      if (budget.budgetBytes <= 0) {
        throw new ModelResidencyError('MEMORY_PRESSURE', 'The operating system or thermal governor has paused model admission', budget);
      }

      let resident = this.residents.get(modelId);
      if (resident?.pendingEviction) {
        throw new ModelResidencyError('MEMORY_PRESSURE', `Model ${modelId} is scheduled for eviction after an OS memory-pressure event`);
      }
      // A warm but idle copy may itself be consuming the headroom needed for a
      // larger context. Release that idle copy and reload only if the complete
      // new working set fits the current budget.
      if (resident && resident.leaseCount === 0 && resident.baseResidentBytes + kvBytes > budget.budgetBytes) {
        await this.#evict(modelId);
        resident = undefined;
      }
      const extraBytes = resident ? kvBytes : descriptor.baseWorkingSetBytes + kvBytes;
      if (extraBytes > budget.budgetBytes) {
        throw new ModelResidencyError('MODEL_EXCEEDS_BUDGET', `Model ${modelId} exceeds the current AI memory budget`, {
          requiredBytes: extraBytes,
          budgetBytes: budget.budgetBytes,
          role: descriptor.role
        });
      }
      await this.#makeRoom(extraBytes, budget.budgetBytes, modelId);
      throwIfAborted(signal);

      if (!resident) {
        let handle;
        try {
          handle = await this.loader.load(modelId, {
            descriptor,
            contextTokens,
            estimatedBytes: descriptor.baseWorkingSetBytes,
            signal
          });
        } catch (error) {
          throw new ModelResidencyError('LOAD_FAILED', `Could not load model ${modelId}: ${error?.message ?? error}`);
        }
        if (!handle || typeof handle !== 'object') {
          throw new ModelResidencyError('INVALID_LOADER_HANDLE', `Loader returned an invalid handle for ${modelId}`);
        }
        try {
          throwIfAborted(signal);
        } catch (error) {
          await this.loader.unload(modelId, handle).catch(() => {});
          throw error;
        }
        const actualBaseBytes = handle.residentBytes === undefined
          ? descriptor.baseWorkingSetBytes
          : finiteNonNegative(handle.residentBytes, `${modelId}.residentBytes`);
        const actualTotal = actualBaseBytes + kvBytes;
        const latestBudget = await this.#readBudget();
        try {
          if (actualTotal > latestBudget.budgetBytes) {
            throw new ModelResidencyError('ACTUAL_MEMORY_EXCEEDS_BUDGET', 'Measured model working set exceeds the available budget', { actualTotal, budgetBytes: latestBudget.budgetBytes });
          }
          await this.#makeRoom(actualTotal, latestBudget.budgetBytes, modelId);
        } catch (error) {
          await this.loader.unload(modelId, handle).catch(() => {});
          throw error;
        }
        try {
          throwIfAborted(signal);
        } catch (error) {
          await this.loader.unload(modelId, handle).catch(() => {});
          throw error;
        }
        resident = {
          modelId,
          descriptor,
          handle,
          baseResidentBytes: actualBaseBytes,
          activeKvBytes: 0,
          leaseCount: 0,
          lastUsedAt: this.now(),
          pendingEviction: false
        };
        this.residents.set(modelId, resident);
      } else if (resident.baseResidentBytes + resident.activeKvBytes + kvBytes > budget.budgetBytes) {
        await this.#makeRoom(kvBytes, budget.budgetBytes, modelId);
      }

      resident.activeKvBytes += kvBytes;
      resident.leaseCount += 1;
      resident.lastUsedAt = this.now();
      const leaseId = `${modelId}:${++this.sequence}`;
      const leaseRecord = { leaseId, modelId, kvBytes, released: false };
      this.leases.set(leaseId, leaseRecord);
      return Object.freeze({
        modelId,
        role: descriptor.role,
        handle: resident.handle,
        leaseId,
        release: () => this.release(leaseId)
      });
    });
  }

  async withModel(modelId, options, operation) {
    if (typeof operation !== 'function') throw new TypeError('operation must be a function');
    const lease = await this.acquire(modelId, options);
    try {
      return await operation(lease.handle, lease);
    } finally {
      await lease.release();
    }
  }

  async release(leaseId) {
    return this.#exclusive(async () => {
      const lease = this.leases.get(leaseId);
      if (!lease || lease.released) return false;
      lease.released = true;
      this.leases.delete(leaseId);
      const resident = this.residents.get(lease.modelId);
      if (!resident) return false;
      resident.leaseCount = Math.max(0, resident.leaseCount - 1);
      resident.activeKvBytes = Math.max(0, resident.activeKvBytes - lease.kvBytes);
      resident.lastUsedAt = this.now();

      const snapshot = await this.getMemorySnapshot();
      const budget = calculateAiMemoryBudget(snapshot, this.policy);
      const shouldEvict = resident.descriptor.cachePolicy === 'ephemeral' || resident.pendingEviction || budget.budgetBytes <= 0;
      if (resident.leaseCount === 0 && shouldEvict) await this.#evict(resident.modelId);
      return true;
    });
  }

  async handleMemoryPressure() {
    return this.#exclusive(async () => {
      this.#assertOpen();
      const evicted = [];
      const entries = [...this.residents.values()].sort((a, b) => a.descriptor.evictionPriority - b.descriptor.evictionPriority || a.lastUsedAt - b.lastUsedAt);
      for (const resident of entries) {
        if (resident.leaseCount === 0) {
          await this.#evict(resident.modelId);
          evicted.push(resident.modelId);
        } else {
          resident.pendingEviction = true;
        }
      }
      return Object.freeze({ evicted, pending: [...this.residents.values()].filter(x => x.pendingEviction).map(x => x.modelId) });
    });
  }

  async status() {
    return this.#exclusive(async () => {
      const budget = await this.#readBudget();
      const models = [...this.residents.values()].map(item => Object.freeze({
        modelId: item.modelId,
        role: item.descriptor.role,
        leaseCount: item.leaseCount,
        baseResidentBytes: item.baseResidentBytes,
        activeKvBytes: item.activeKvBytes,
        lastUsedAt: item.lastUsedAt,
        pendingEviction: item.pendingEviction
      }));
      return Object.freeze({ budget, residentBytes: models.reduce((sum, item) => sum + item.baseResidentBytes + item.activeKvBytes, 0), models });
    });
  }

  async dispose() {
    return this.#exclusive(async () => {
      if (this.leases.size) throw new ModelResidencyError('ACTIVE_LEASES', 'Cannot dispose model manager while inference leases are active', { activeLeases: this.leases.size });
      for (const modelId of [...this.residents.keys()]) await this.#evict(modelId);
      this.disposed = true;
    });
  }

  async #readBudget() {
    const snapshot = await this.getMemorySnapshot();
    return calculateAiMemoryBudget(snapshot, this.policy);
  }

  async #makeRoom(extraBytes, budgetBytes, excludeModelId) {
    if (!Number.isFinite(budgetBytes) || budgetBytes <= 0) throw new ModelResidencyError('MEMORY_PRESSURE', 'No AI memory budget is available', { budgetBytes });
    let residentBytes = [...this.residents.values()].reduce((sum, item) => sum + item.baseResidentBytes + item.activeKvBytes, 0);
    if (residentBytes + extraBytes <= budgetBytes) return;
    const candidates = [...this.residents.values()]
      .filter(item => item.modelId !== excludeModelId && item.leaseCount === 0)
      .sort((a, b) => a.descriptor.evictionPriority - b.descriptor.evictionPriority || a.lastUsedAt - b.lastUsedAt);
    for (const candidate of candidates) {
      await this.#evict(candidate.modelId);
      residentBytes = [...this.residents.values()].reduce((sum, item) => sum + item.baseResidentBytes + item.activeKvBytes, 0);
      if (residentBytes + extraBytes <= budgetBytes) return;
    }
    throw new ModelResidencyError('INSUFFICIENT_HEADROOM', 'Active model leases prevent enough memory from being reclaimed', {
      residentBytes,
      requestedBytes: extraBytes,
      budgetBytes
    });
  }

  async #evict(modelId) {
    const resident = this.residents.get(modelId);
    if (!resident) return false;
    if (resident.leaseCount > 0) {
      resident.pendingEviction = true;
      return false;
    }
    await this.loader.unload(modelId, resident.handle);
    this.residents.delete(modelId);
    return true;
  }

  #assertOpen() {
    if (this.disposed) throw new ModelResidencyError('DISPOSED', 'Model residency manager has been disposed');
  }

  async #exclusive(operation) {
    let unlock;
    const previous = this.tail;
    this.tail = new Promise(resolve => { unlock = resolve; });
    await previous;
    try { return await operation(); }
    finally { unlock(); }
  }
}

export const MODEL_MEMORY_UNITS = Object.freeze({ MIB });
