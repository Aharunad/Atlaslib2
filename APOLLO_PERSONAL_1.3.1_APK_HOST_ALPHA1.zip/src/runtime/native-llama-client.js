/**
 * LocalOpenAIClient-compatible adapter for a loaded native Android llama.cpp session.
 * It sends structured chat messages through the trusted Android bridge. No network
 * endpoint or model path is exposed to JavaScript.
 */
export class NativeLlamaClient {
  constructor({ bridge, getSession, model = 'apollo-sleeping-giant-native' } = {}) {
    if (!bridge || typeof bridge.generateSleepingGiant !== 'function') throw new TypeError('An Android Sleeping Giant bridge is required');
    if (typeof getSession !== 'function') throw new TypeError('getSession must return the current native session');
    if (typeof model !== 'string' || !model.trim() || model.length > 160) throw new TypeError('A native model identifier is required');
    this.bridge = bridge;
    this.getSession = getSession;
    this.model = model.trim();
  }

  async probe() {
    const capabilities = await this.bridge.getRuntimeCapabilities();
    const session = this.getSession();
    return Object.freeze({
      available: capabilities.available === true && Boolean(session?.sessionId),
      configuredModel: this.model,
      models: session?.sessionId ? [this.model] : []
    });
  }

  async complete({ messages, maxTokens = 1200, responseFormat = null, temperature = 0.2, signal, onToken } = {}) {
    if (!Array.isArray(messages) || messages.length < 1 || messages.length > 32) throw new TypeError('messages must contain 1–32 entries');
    for (const [index, message] of messages.entries()) {
      if (!message || !['system', 'user', 'assistant'].includes(message.role) || typeof message.content !== 'string' || message.content.length > 48 * 1024) {
        throw new TypeError(`Invalid native chat message at index ${index}`);
      }
    }
    if (!Number.isSafeInteger(maxTokens) || maxTokens < 1 || maxTokens > 8192) throw new RangeError('maxTokens must be between 1 and 8192');
    const format = responseFormat == null || responseFormat === 'text' ? '' : typeof responseFormat === 'object' ? responseFormat.type : responseFormat;
    if (!['', 'json_object'].includes(format)) throw new TypeError('responseFormat must be text or json_object');
    if (typeof temperature !== 'number' || !Number.isFinite(temperature) || temperature < 0 || temperature > 2) throw new RangeError('temperature must be between 0 and 2');
    if (signal?.aborted) throw new Error('Native inference cancelled');
    const session = this.getSession();
    if (!session?.sessionId) throw new Error('No Sleeping Giant is currently loaded in Apollo');
    const result = await this.bridge.generateSleepingGiant({
      sessionId: session.sessionId,
      messages,
      maxTokens,
      responseFormat: format,
      temperature,
      signal,
      onToken
    });
    if (!result.text.trim()) throw new Error('Sleeping Giant returned an empty response');
    return Object.freeze({ text: result.text, model: this.model, usage: result.metrics ?? null });
  }
}
