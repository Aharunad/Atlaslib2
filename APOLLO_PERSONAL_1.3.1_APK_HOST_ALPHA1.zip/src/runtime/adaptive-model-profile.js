/**
 * Conservative, device-aware GGUF model sizing planner.
 *
 * This is an advisory estimator, not a model loader or a guarantee that Android
 * will admit the process. The native runtime remains authoritative at load time.
 */

const MiB = 1024 * 1024;
const CONTEXT_CANDIDATES = Object.freeze([8192, 4096, 2048, 1024, 512, 256]);
const MAX_SAFE_BYTES = Number.MAX_SAFE_INTEGER;

function finiteInteger(value, { min = 0, max = MAX_SAFE_BYTES } = {}) {
  return Number.isSafeInteger(value) && value >= min && value <= max ? value : null;
}

function clamp(value, min, max) { return Math.min(max, Math.max(min, value)); }

export function normalizeAndroidDeviceProfile(input) {
  if (!input || typeof input !== 'object') throw new TypeError('An Android device profile is required');
  const totalRamBytes = finiteInteger(input.totalRamBytes, { min: 256 * MiB });
  const availableRamBytes = finiteInteger(input.availableRamBytes, { min: 0 });
  const cpuCores = finiteInteger(input.cpuCores, { min: 1, max: 256 });
  const supportedAbis = Array.isArray(input.supportedAbis)
    ? input.supportedAbis.filter(value => typeof value === 'string' && /^[A-Za-z0-9._-]{1,40}$/.test(value)).slice(0, 16)
    : [];
  if (totalRamBytes == null || availableRamBytes == null || cpuCores == null || !supportedAbis.length) {
    throw new TypeError('Android device profile is missing valid RAM, CPU or ABI information');
  }
  return Object.freeze({
    platform: 'android',
    totalRamBytes,
    availableRamBytes: Math.min(availableRamBytes, totalRamBytes),
    lowRamDevice: input.lowRamDevice === true,
    lowMemory: input.lowMemory === true,
    cpuCores,
    supportedAbis: Object.freeze(supportedAbis),
    isArm64: supportedAbis.includes('arm64-v8a'),
    apiLevel: finiteInteger(input.apiLevel, { min: 21, max: 100 }) ?? null,
    appMemoryClassMb: finiteInteger(input.appMemoryClassMb, { min: 16, max: 65536 }) ?? null,
    availableStorageBytes: finiteInteger(input.availableStorageBytes, { min: 0 }) ?? null,
    deviceSignature: typeof input.deviceSignature === 'string' ? input.deviceSignature.slice(0, 120) : null
  });
}

export function estimateGgufKvCacheBytes(inspection, contextTokens, { bytesPerValue = 2 } = {}) {
  const layers = finiteInteger(inspection?.blockCount, { min: 1, max: 4096 });
  const kvHeads = finiteInteger(inspection?.headCountKv ?? inspection?.headCount, { min: 1, max: 4096 });
  const keyLength = finiteInteger(inspection?.keyLength, { min: 1, max: 65536 })
    ?? (() => {
      const embedding = finiteInteger(inspection?.embeddingLength, { min: 1, max: 1_000_000 });
      const heads = finiteInteger(inspection?.headCount, { min: 1, max: 4096 });
      return embedding && heads && embedding % heads === 0 ? embedding / heads : null;
    })();
  const valueLength = finiteInteger(inspection?.valueLength, { min: 1, max: 65536 }) ?? keyLength;
  const context = finiteInteger(contextTokens, { min: 1, max: 1_000_000 });
  const width = finiteInteger(bytesPerValue, { min: 1, max: 8 });
  if (![layers, kvHeads, keyLength, valueLength, context, width].every(Number.isSafeInteger)) return null;
  const estimate = context * layers * kvHeads * (keyLength + valueLength) * width;
  return Number.isSafeInteger(estimate) ? estimate : null;
}

/**
 * Choose a context size and thread/batch profile for this device and GGUF.
 * `runtimeCapabilities` is intentionally separate from the memory estimate.
 */
export function createAdaptiveModelProfile({ inspection, device, runtimeCapabilities = null, preferredContextTokens = null } = {}) {
  if (!inspection || inspection.format !== 'gguf' || !Number.isSafeInteger(inspection.fileBytes) || inspection.fileBytes <= 0) {
    throw new TypeError('A validated GGUF inspection is required');
  }
  const hardware = normalizeAndroidDeviceProfile(device);
  const isLowMemory = hardware.lowRamDevice || hardware.lowMemory || hardware.totalRamBytes <= 4 * 1024 * MiB;

  // Reserve memory for Android, Atlas Library, WebView and user applications.
  // Use the smaller of a fraction of current free RAM and a total-RAM ceiling.
  const osReserveBytes = Math.max(384 * MiB, Math.floor(hardware.totalRamBytes * (isLowMemory ? 0.16 : 0.12)));
  const availableAfterReserve = Math.max(0, hardware.availableRamBytes - osReserveBytes);
  const deviceBudgetBytes = Math.floor(hardware.totalRamBytes * (isLowMemory ? 0.18 : 0.28));
  const modelBudgetBytes = Math.min(Math.floor(availableAfterReserve * (isLowMemory ? 0.55 : 0.65)), deviceBudgetBytes);

  // mmap-backed weights still compete for physical memory as pages become resident.
  const weightWorkingSetBytes = Math.ceil(inspection.fileBytes * 1.05);
  const runtimeOverheadBytes = Math.max(96 * MiB, Math.ceil(inspection.fileBytes * 0.08));
  const baseWorkingSetBytes = weightWorkingSetBytes + runtimeOverheadBytes;
  const modelContextLimit = finiteInteger(inspection.contextLength, { min: 1, max: 1_000_000 }) ?? 2048;
  const preferred = finiteInteger(preferredContextTokens, { min: 1, max: 1_000_000 });
  const contexts = CONTEXT_CANDIDATES
    .filter(value => value <= modelContextLimit && (!preferred || value <= preferred))
    .sort((a, b) => b - a);
  if (!contexts.length) contexts.push(Math.max(256, Math.min(512, modelContextLimit)));

  let chosen = null;
  let bestEstimate = null;
  for (const contextTokens of contexts) {
    const kvCacheBytes = estimateGgufKvCacheBytes(inspection, contextTokens);
    if (kvCacheBytes == null) continue;
    const scratchBytes = Math.max(48 * MiB, Math.ceil(contextTokens * (isLowMemory ? 24 : 40) * 1024));
    const estimatedWorkingSetBytes = baseWorkingSetBytes + kvCacheBytes + scratchBytes;
    bestEstimate = { contextTokens, kvCacheBytes, scratchBytes, estimatedWorkingSetBytes };
    if (estimatedWorkingSetBytes <= modelBudgetBytes) { chosen = bestEstimate; break; }
  }

  const contextEstimateAvailable = bestEstimate != null;
  const recommendedContextTokens = chosen?.contextTokens ?? null;
  const cpuThreads = clamp(hardware.cpuCores - 1, 1, isLowMemory ? 2 : 4);
  const batchTokens = isLowMemory ? 32 : hardware.totalRamBytes <= 6 * 1024 * MiB ? 64 : 128;
  const architectureCandidates = runtimeCapabilities?.architectureCandidates ?? runtimeCapabilities?.supportedArchitectures;
  const architectureSupported = Array.isArray(architectureCandidates)
    && (architectureCandidates.includes('*') || architectureCandidates.includes(inspection.architecture));
  const runtimeAvailable = runtimeCapabilities?.available === true
    && Array.isArray(runtimeCapabilities.formats)
    && runtimeCapabilities.formats.includes('gguf')
    && architectureSupported;
  const llamaCppOptions = recommendedContextTokens ? Object.freeze({
    contextTokens: recommendedContextTokens,
    threads: cpuThreads,
    threadsBatch: cpuThreads,
    batchTokens,
    microBatchTokens: Math.min(batchTokens, 32),
    gpuLayers: 0,
    useMmap: true,
    kvCacheTypeK: 'f16',
    kvCacheTypeV: 'f16'
  }) : null;

  let status;
  let reason;
  if (!hardware.isArm64) {
    status = 'unsupported_abi';
    reason = 'This device does not report ARM64 support. Apollo needs a qualified runtime build for its ABI.';
  } else if (!contextEstimateAvailable) {
    status = 'needs_more_metadata';
    reason = 'The GGUF does not expose enough attention metadata for a reliable context estimate. A native load test is required.';
  } else if (!chosen) {
    status = 'likely_too_large';
    reason = 'The model exceeds Apollo’s conservative memory budget, even at the smallest estimated context.';
  } else if (!runtimeAvailable) {
    status = 'runtime_required';
    reason = 'The model is estimated to fit at the recommended context, but a native runtime must advertise and load this architecture before use.';
  } else {
    status = 'load_test_required';
    reason = 'The device and runtime appear compatible. Apollo must complete a native model load test before enabling inference.';
  }

  return Object.freeze({
    schemaVersion: 1,
    status,
    reason,
    device: hardware,
    isLowMemory,
    memoryBudgetBytes: modelBudgetBytes,
    estimatedBaseWorkingSetBytes: baseWorkingSetBytes,
    estimatedWorkingSetBytes: chosen?.estimatedWorkingSetBytes ?? bestEstimate?.estimatedWorkingSetBytes ?? null,
    estimatedKvCacheBytes: chosen?.kvCacheBytes ?? bestEstimate?.kvCacheBytes ?? null,
    recommendedContextTokens,
    modelContextLimit,
    cpuThreads,
    batchTokens,
    llamaCppOptions,
    gpuOffload: 'not_enabled_until_native_backend_probe',
    runtimeAvailable,
    contextEstimateAvailable,
    isEstimate: true
  });
}

export function formatAdaptiveProfileSummary(profile) {
  if (!profile || typeof profile !== 'object') throw new TypeError('An adaptive model profile is required');
  if (profile.status === 'likely_too_large') return 'This model is likely too large for the current device memory budget.';
  if (profile.status === 'unsupported_abi') return 'This device needs a different native runtime build.';
  if (profile.recommendedContextTokens) return `Estimated fit at ${profile.recommendedContextTokens.toLocaleString()} context tokens. Native load validation is still required.`;
  return profile.reason;
}
