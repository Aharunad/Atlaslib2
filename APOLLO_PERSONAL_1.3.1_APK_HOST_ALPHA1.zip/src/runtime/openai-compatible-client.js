const DEFAULT_TIMEOUT_MS = 120_000;
const LOOPBACK_HOSTS = new Set(['127.0.0.1', 'localhost', '[::1]']);

function normalizeBaseUrl(value) {
  if (typeof value !== 'string' || !value.trim()) throw new TypeError('A local inference base URL is required');
  const url = new URL(value);
  if (url.protocol !== 'http:' && url.protocol !== 'https:') throw new TypeError('Inference endpoint must use HTTP or HTTPS');
  if (!LOOPBACK_HOSTS.has(url.hostname)) throw new TypeError('Apollo offline mode only permits loopback inference endpoints');
  url.pathname = url.pathname.replace(/\/+$/, '');
  return url.toString().replace(/\/$/, '');
}

function extractContent(payload) {
  const content = payload?.choices?.[0]?.message?.content;
  if (typeof content === 'string') return content;
  if (Array.isArray(content)) return content.map(part => typeof part?.text === 'string' ? part.text : '').join('');
  throw new Error('Local inference response did not contain assistant text');
}

function parseSseBlock(block) {
  const data = block.split(/\r?\n/).filter(line => line.startsWith('data:')).map(line => line.slice(5).trim()).join('\n');
  if (!data || data === '[DONE]') return null;
  try { return JSON.parse(data); }
  catch { return null; }
}

/**
 * OpenAI-compatible local inference client. Intended for llama.cpp/MLC or a
 * separately qualified local MoE bridge. It refuses non-loopback hosts so the
 * default Apollo conversation path cannot silently become a cloud dependency.
 */
export class LocalOpenAIClient {
  constructor({ baseUrl = 'http://127.0.0.1:8080/v1', model, apiKey = '', fetchImpl = globalThis.fetch, timeoutMs = DEFAULT_TIMEOUT_MS } = {}) {
    if (typeof fetchImpl !== 'function') throw new TypeError('A Fetch-compatible implementation is required');
    if (typeof model !== 'string' || !model.trim() || model.length > 160) throw new TypeError('A local model identifier is required');
    if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 1000 || timeoutMs > 10 * 60 * 1000) throw new RangeError('timeoutMs must be between 1 second and 10 minutes');
    this.baseUrl = normalizeBaseUrl(baseUrl);
    if (typeof apiKey !== 'string' || apiKey.length > 512) throw new TypeError('apiKey must be a string of at most 512 characters');
    this.model = model.trim();
    this.apiKey = apiKey;
    this.fetchImpl = fetchImpl;
    this.timeoutMs = timeoutMs;
  }

  async probe({ signal } = {}) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(new Error('Local model probe timed out')), this.timeoutMs);
    const abort = () => controller.abort(signal?.reason ?? new Error('Local model probe cancelled'));
    if (signal?.aborted) abort();
    else signal?.addEventListener('abort', abort, { once: true });
    try {
      const response = await this.fetchImpl(`${this.baseUrl}/models`, {
        method: 'GET', signal: controller.signal,
        headers: this.apiKey ? { authorization: `Bearer ${this.apiKey}` } : {}
      });
      if (!response.ok) throw new Error(`Local model endpoint unavailable (HTTP ${response.status})`);
      const payload = await response.json();
      const models = Array.isArray(payload.data) ? payload.data.map(item => item.id).filter(id => typeof id === 'string') : [];
      return Object.freeze({ available: true, configuredModel: this.model, models });
    } catch (error) {
      if (controller.signal.aborted) throw new Error(controller.signal.reason?.message?.includes('timed out') ? 'Local model probe timed out' : 'Local model probe cancelled', { cause: error });
      throw error;
    } finally {
      clearTimeout(timeout);
      signal?.removeEventListener('abort', abort);
    }
  }

  async complete({ messages, temperature = 0.2, maxTokens = 1200, responseFormat, signal, onToken } = {}) {
    if (!Array.isArray(messages) || messages.length === 0 || messages.length > 64) throw new TypeError('messages must contain 1–64 entries');
    if (!Number.isFinite(temperature) || temperature < 0 || temperature > 2) throw new RangeError('temperature must be between 0 and 2');
    if (!Number.isSafeInteger(maxTokens) || maxTokens < 1 || maxTokens > 8192) throw new RangeError('maxTokens must be between 1 and 8192');
    for (const [index, message] of messages.entries()) {
      if (!message || !['system', 'user', 'assistant'].includes(message.role) || typeof message.content !== 'string' || message.content.length > 64_000) {
        throw new TypeError(`Invalid message at index ${index}`);
      }
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(new Error('Local inference timed out')), this.timeoutMs);
    const abort = () => controller.abort(signal?.reason ?? new Error('Local inference cancelled'));
    if (signal?.aborted) abort();
    else signal?.addEventListener('abort', abort, { once: true });

    try {
      const response = await this.fetchImpl(`${this.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: { 'content-type': 'application/json', ...(this.apiKey ? { authorization: `Bearer ${this.apiKey}` } : {}) },
        signal: controller.signal,
        body: JSON.stringify({
          model: this.model,
          messages,
          temperature,
          max_tokens: maxTokens,
          stream: typeof onToken === 'function',
          ...(responseFormat ? { response_format: responseFormat } : {})
        })
      });
      if (!response.ok) {
        const body = (await response.text().catch(() => '')).slice(0, 1200);
        throw new Error(`Local inference HTTP ${response.status}: ${body || response.statusText}`);
      }

      if (typeof onToken !== 'function') {
        const payload = await response.json();
        return Object.freeze({ text: extractContent(payload), model: payload.model ?? this.model, usage: payload.usage ?? null });
      }

      if (!response.body?.getReader) throw new Error('Streaming response body is unavailable in this runtime');
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let fullText = '';
      let done = false;
      while (!done) {
        const part = await reader.read();
        done = part.done;
        buffer += decoder.decode(part.value ?? new Uint8Array(), { stream: !done });
        let boundary;
        while ((boundary = buffer.search(/\r?\n\r?\n/)) >= 0) {
          const block = buffer.slice(0, boundary);
          const sep = buffer.slice(boundary).match(/^\r?\n\r?\n/)[0];
          buffer = buffer.slice(boundary + sep.length);
          const event = parseSseBlock(block);
          if (!event) continue;
          const delta = event.choices?.[0]?.delta?.content;
          const token = typeof delta === 'string' ? delta : Array.isArray(delta) ? delta.map(x => x.text ?? '').join('') : '';
          if (token) {
            fullText += token;
            await onToken(token);
          }
        }
      }
      return Object.freeze({ text: fullText, model: this.model, usage: null });
    } catch (error) {
      if (controller.signal.aborted) {
        const reason = controller.signal.reason;
        throw new Error(reason?.message?.includes('timed out') ? 'Local inference timed out' : 'Local inference cancelled', { cause: error });
      }
      throw error;
    } finally {
      clearTimeout(timeout);
      signal?.removeEventListener('abort', abort);
    }
  }
}

export { normalizeBaseUrl as validateLocalInferenceUrl };
