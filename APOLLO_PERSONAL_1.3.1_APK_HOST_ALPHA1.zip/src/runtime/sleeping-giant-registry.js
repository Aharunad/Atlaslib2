import { evaluateGgufCompatibility } from './gguf-inspector.js';

const KEY_PREFIX = 'apollo:sleeping-giant:model:';
const ACTIVE_KEY = 'apollo:sleeping-giant:active';
const MODEL_ID_RE = /^sg-[a-f0-9]{16,64}$/;
const SHA256_RE = /^[a-f0-9]{64}$/;

function clone(value) { return value === undefined ? undefined : structuredClone(value); }

function normalizeImportResult(result) {
  if (!result || result.ok !== true || !result.model || typeof result.model !== 'object') {
    throw new TypeError('Native model import did not return a successful model record');
  }
  const model = result.model;
  if (!SHA256_RE.test(model.sha256 ?? '') || !Number.isSafeInteger(model.bytes) || model.bytes < 24) {
    throw new TypeError('Native model import returned an invalid SHA-256 or file size');
  }
  if (model.format !== 'gguf' || !model.inspection || model.inspection.format !== 'gguf') {
    throw new TypeError('This Apollo release accepts validated GGUF models only');
  }
  const source = model.inspection;
  if (source.fileBytes !== model.bytes || typeof source.architecture !== 'string' || !/^[A-Za-z0-9._-]{1,80}$/.test(source.architecture)) {
    throw new TypeError('Native GGUF inspection does not match the imported artifact');
  }
  if (!Number.isSafeInteger(source.tensorCount) || source.tensorCount < 1 || source.tensorCount > 1_000_000) {
    throw new TypeError('Native GGUF inspection returned an invalid tensor count');
  }
  if (![2, 3].includes(source.version)) throw new TypeError('Native GGUF inspection returned an unsupported format version');
  const optionalInteger = (value, min, max, label) => {
    if (value == null) return null;
    if (!Number.isSafeInteger(value) || value < min || value > max) throw new TypeError(`Native GGUF inspection returned an invalid ${label}`);
    return value;
  };
  const expertCount = optionalInteger(source.expertCount, 1, 100_000, 'expert count');
  const expertUsedCount = optionalInteger(source.expertUsedCount, 1, 100_000, 'active expert count');
  if (expertCount && expertUsedCount && expertUsedCount > expertCount) throw new TypeError('Native GGUF inspection returned more active experts than total experts');
  if (typeof model.assetId !== 'string' || model.assetId !== `sg-${model.sha256.slice(0, 24)}`) {
    throw new TypeError('Native model import returned an invalid private asset identifier');
  }
  if (typeof model.displayName !== 'string' || !model.displayName.trim() || model.displayName.length > 240) {
    throw new TypeError('Native model import returned an invalid display name');
  }
  const inspection = Object.freeze({
    format: 'gguf', version: source.version, architecture: source.architecture,
    name: typeof source.name === 'string' ? source.name.slice(0, 240) : null,
    tensorCount: source.tensorCount,
    fileType: optionalInteger(source.fileType, 0, 0xffffffff, 'GGUF file type'),
    tokenizerModel: typeof source.tokenizerModel === 'string' ? source.tokenizerModel.slice(0, 120) : null,
    hasChatTemplate: source.hasChatTemplate === true,
    contextLength: optionalInteger(source.contextLength, 1, 131072, 'context length'),
    blockCount: optionalInteger(source.blockCount, 1, 4096, 'block count'),
    embeddingLength: optionalInteger(source.embeddingLength, 1, 1_000_000, 'embedding length'),
    headCount: optionalInteger(source.headCount, 1, 4096, 'attention head count'),
    headCountKv: optionalInteger(source.headCountKv, 1, 4096, 'KV head count'),
    keyLength: optionalInteger(source.keyLength, 1, 65536, 'key length'),
    valueLength: optionalInteger(source.valueLength, 1, 65536, 'value length'),
    expertCount, expertUsedCount, isMoE: Boolean(expertCount),
    fileBytes: model.bytes,
    metadataBytesRead: optionalInteger(source.metadataBytesRead, 0, 16 * 1024 * 1024, 'metadata byte count') ?? 0
  });
  const incomingCapabilities = model.runtimeCapabilities;
  const runtimeCapabilities = incomingCapabilities && typeof incomingCapabilities === 'object'
    ? Object.freeze({
      available: incomingCapabilities.available === true,
      formats: Array.isArray(incomingCapabilities.formats) ? incomingCapabilities.formats.filter(value => typeof value === 'string').slice(0, 16) : [],
      architectureCandidates: Array.isArray(incomingCapabilities.architectureCandidates ?? incomingCapabilities.supportedArchitectures)
        ? (incomingCapabilities.architectureCandidates ?? incomingCapabilities.supportedArchitectures).filter(value => typeof value === 'string').slice(0, 256)
        : []
    })
    : null;
  return Object.freeze({
    displayName: model.displayName.trim(), assetId: model.assetId,
    sha256: model.sha256, bytes: model.bytes, format: 'gguf',
    inspection, runtimeCapabilities
  });
}

/** Persistent registry for user-supplied Sleeping Giant model files. */
export class SleepingGiantRegistry {
  constructor({ adapter, nativeHost = null, now = () => Date.now() } = {}) {
    if (!adapter || typeof adapter.get !== 'function' || typeof adapter.put !== 'function' || typeof adapter.list !== 'function') {
      throw new TypeError('SleepingGiantRegistry requires a persistent key/value adapter');
    }
    this.adapter = adapter;
    this.nativeHost = nativeHost;
    this.now = now;
  }

  async registerImport(importResult) {
    const nativeModel = normalizeImportResult(importResult);
    const modelId = `sg-${nativeModel.sha256.slice(0, 24)}`;
    const compatibility = evaluateGgufCompatibility(nativeModel.inspection, nativeModel.runtimeCapabilities ?? null);
    const record = Object.freeze({
      schemaVersion: 1,
      modelId,
      role: 'sleeping-giant',
      displayName: nativeModel.displayName,
      format: 'gguf',
      assetId: nativeModel.assetId,
      sha256: nativeModel.sha256,
      bytes: nativeModel.bytes,
      inspection: clone(nativeModel.inspection),
      compatibility: clone(compatibility),
      status: compatibility.status,
      licenseReview: 'pending_user_review',
      createdAt: new Date(this.now()).toISOString(),
      updatedAt: new Date(this.now()).toISOString()
    });
    const key = `${KEY_PREFIX}${modelId}`;
    const existing = await this.adapter.get(key);
    if (existing && (existing.sha256 !== record.sha256 || existing.assetId !== record.assetId)) {
      throw new Error('Sleeping Giant model ID collision; existing record was not overwritten');
    }
    const persistedRecord = existing
      ? { ...record, createdAt: existing.createdAt, licenseReview: existing.licenseReview ?? 'pending_user_review' }
      : record;
    await this.adapter.put(key, persistedRecord);
    await this.adapter.put(ACTIVE_KEY, { modelId, selectedAt: new Date(this.now()).toISOString() });
    return clone(persistedRecord);
  }

  async list() {
    const rows = await this.adapter.list(KEY_PREFIX);
    return rows.map(row => clone(row.value)).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }

  async get(modelId) {
    if (!MODEL_ID_RE.test(modelId ?? '')) throw new TypeError('Invalid Sleeping Giant model ID');
    const record = await this.adapter.get(`${KEY_PREFIX}${modelId}`);
    return clone(record);
  }

  async getSelected() {
    const active = await this.adapter.get(ACTIVE_KEY);
    return active?.modelId ? this.get(active.modelId) : undefined;
  }

  async select(modelId) {
    const record = await this.get(modelId);
    if (!record) throw new Error('Sleeping Giant model is not registered');
    await this.adapter.put(ACTIVE_KEY, { modelId, selectedAt: new Date(this.now()).toISOString() });
    return record;
  }

  async updateLicenseReview(modelId, reviewed) {
    if (typeof reviewed !== 'boolean') throw new TypeError('License review state must be boolean');
    const record = await this.get(modelId);
    if (!record) throw new Error('Sleeping Giant model is not registered');
    const updated = { ...record, licenseReview: reviewed ? 'user_reviewed' : 'pending_user_review', updatedAt: new Date(this.now()).toISOString() };
    await this.adapter.put(`${KEY_PREFIX}${modelId}`, updated);
    return clone(updated);
  }

  /**
   * Removes only Apollo's private copy when explicitly requested. The original
   * user-selected document is never deleted by this registry.
   */
  async remove(modelId, { deletePrivateCopy = false } = {}) {
    const record = await this.get(modelId);
    if (!record) return false;
    if (deletePrivateCopy) {
      if (!this.nativeHost || typeof this.nativeHost.removeModelAsset !== 'function') {
        throw new Error('Native storage host cannot remove Apollo private model assets');
      }
      // Delete the managed asset first. If native deletion fails, keep the
      // registry record so the user can retry instead of losing track of bytes.
      await this.nativeHost.removeModelAsset(record.assetId);
    }
    const selected = await this.adapter.get(ACTIVE_KEY);
    if (selected?.modelId === modelId) await this.adapter.delete(ACTIVE_KEY);
    await this.adapter.delete(`${KEY_PREFIX}${modelId}`);
    return true;
  }
}
