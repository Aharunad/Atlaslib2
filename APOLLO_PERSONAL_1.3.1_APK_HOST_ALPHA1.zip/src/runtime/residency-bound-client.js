/**
 * Adds ModelResidencyManager leases around any local inference client. The
 * host loader is responsible for attaching/loading the actual model handle;
 * inference always releases the lease, including abort/error paths.
 */
export class ResidencyBoundClient {
  constructor({ manager, modelId, client, contextWindow = 2048, estimateTokens = null } = {}) {
    if (!manager || typeof manager.withModel !== 'function') throw new TypeError('A ModelResidencyManager is required');
    if (typeof modelId !== 'string' || !modelId.trim()) throw new TypeError('A modelId is required');
    if (!client || typeof client.complete !== 'function') throw new TypeError('A local inference client is required');
    if (!Number.isSafeInteger(contextWindow) || contextWindow < 128 || contextWindow > 131072) throw new RangeError('contextWindow is invalid');
    this.manager = manager;
    this.modelId = modelId;
    this.client = client;
    this.contextWindow = contextWindow;
    this.estimateTokens = estimateTokens ?? (options => {
      const chars = (options.messages ?? []).reduce((sum, item) => sum + (typeof item.content === 'string' ? item.content.length : 0), 0);
      const promptTokens = Math.max(1, Math.ceil(chars / 3.5));
      const requested = Number.isSafeInteger(options.maxTokens) ? options.maxTokens : 512;
      return Math.min(this.contextWindow, Math.max(128, promptTokens + requested));
    });
  }

  async complete(options = {}) {
    const contextTokens = this.estimateTokens(options);
    if (!Number.isSafeInteger(contextTokens) || contextTokens < 1 || contextTokens > this.contextWindow) throw new RangeError('Estimated context exceeds the configured model window');
    return this.manager.withModel(this.modelId, { contextTokens, signal: options.signal }, async handle => {
      if (typeof handle.complete === 'function') return handle.complete(options);
      return this.client.complete(options);
    });
  }

  async probe(options = {}) {
    if (typeof this.client.probe !== 'function') throw new Error('The wrapped local client does not support endpoint probing');
    return this.client.probe(options);
  }
}
