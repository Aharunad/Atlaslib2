/**
 * Bounded GGUF header/metadata inspector.
 *
 * This intentionally does not parse tensor payloads or load model code. It reads
 * only the bounded metadata prefix from a Blob/File and extracts the fields
 * Apollo needs for an initial compatibility profile.
 */

export class GgufInspectionError extends Error {
  constructor(message, code = 'GGUF_INVALID') {
    super(message);
    this.name = 'GgufInspectionError';
    this.code = code;
  }
}

const FIXED_WIDTHS = new Map([
  [0, 1], [1, 1], [2, 2], [3, 2], [4, 4], [5, 4], [6, 4], [7, 1],
  [10, 8], [11, 8], [12, 8]
]);
const DEFAULT_LIMITS = Object.freeze({
  maxMetadataBytes: 16 * 1024 * 1024,
  maxMetadataEntries: 100_000,
  maxStringBytes: 1 * 1024 * 1024,
  maxArrayElements: 1_000_000,
  maxTensorCount: 1_000_000,
  maxNestingDepth: 8
});

function assertSafeLength(value, max, label) {
  if (typeof value !== 'number' || !Number.isSafeInteger(value) || value < 0 || value > max) {
    throw new GgufInspectionError(`${label} exceeds Apollo's inspection limit`, 'GGUF_LIMIT');
  }
  return value;
}

class Reader {
  constructor(buffer, fileBytes, limits) {
    this.bytes = new Uint8Array(buffer);
    this.view = new DataView(buffer);
    this.fileBytes = fileBytes;
    this.limits = limits;
    this.offset = 0;
    this.decoder = new TextDecoder('utf-8', { fatal: true });
  }

  ensure(length, label = 'GGUF metadata') {
    if (!Number.isSafeInteger(length) || length < 0 || this.offset + length > this.bytes.byteLength) {
      const reason = this.fileBytes > this.bytes.byteLength
        ? `${label} exceeds the ${this.bytes.byteLength}-byte inspection window`
        : `${label} is truncated`;
      throw new GgufInspectionError(reason, 'GGUF_TRUNCATED');
    }
  }

  u8() { this.ensure(1); return this.view.getUint8(this.offset++); }
  i8() { this.ensure(1); return this.view.getInt8(this.offset++); }
  u16() { this.ensure(2); const v = this.view.getUint16(this.offset, true); this.offset += 2; return v; }
  i16() { this.ensure(2); const v = this.view.getInt16(this.offset, true); this.offset += 2; return v; }
  u32() { this.ensure(4); const v = this.view.getUint32(this.offset, true); this.offset += 4; return v; }
  i32() { this.ensure(4); const v = this.view.getInt32(this.offset, true); this.offset += 4; return v; }
  f32() { this.ensure(4); const v = this.view.getFloat32(this.offset, true); this.offset += 4; return v; }
  f64() { this.ensure(8); const v = this.view.getFloat64(this.offset, true); this.offset += 8; return v; }

  u64() {
    this.ensure(8);
    const value = this.view.getBigUint64(this.offset, true);
    this.offset += 8;
    if (value > BigInt(Number.MAX_SAFE_INTEGER)) {
      throw new GgufInspectionError('GGUF contains a value too large for safe inspection', 'GGUF_LIMIT');
    }
    return Number(value);
  }

  string() {
    const length = assertSafeLength(this.u64(), this.limits.maxStringBytes, 'GGUF string');
    this.ensure(length, 'GGUF string');
    let result;
    try { result = this.decoder.decode(this.bytes.subarray(this.offset, this.offset + length)); }
    catch { throw new GgufInspectionError('GGUF contains invalid UTF-8 metadata', 'GGUF_ENCODING'); }
    this.offset += length;
    return result;
  }

  skipValue(type, depth = 0) {
    if (depth > this.limits.maxNestingDepth) throw new GgufInspectionError('GGUF metadata nesting is too deep', 'GGUF_LIMIT');
    if (type === 8) { this.string(); return; }
    if (type === 9) {
      const elementType = this.u32();
      const count = assertSafeLength(this.u64(), this.limits.maxArrayElements, 'GGUF array');
      if (!FIXED_WIDTHS.has(elementType) && elementType !== 8 && elementType !== 9) {
        throw new GgufInspectionError(`GGUF uses unsupported metadata type ${elementType}`, 'GGUF_TYPE');
      }
      if (elementType === 8 || elementType === 9) {
        for (let i = 0; i < count; i++) this.skipValue(elementType, depth + 1);
        return;
      }
      const bytes = count * FIXED_WIDTHS.get(elementType);
      this.ensure(bytes, 'GGUF array');
      this.offset += bytes;
      return;
    }
    const width = FIXED_WIDTHS.get(type);
    if (!width) throw new GgufInspectionError(`GGUF uses unsupported metadata type ${type}`, 'GGUF_TYPE');
    this.ensure(width, 'GGUF scalar');
    this.offset += width;
  }

  value(type) {
    switch (type) {
      case 0: return this.u8();
      case 1: return this.i8();
      case 2: return this.u16();
      case 3: return this.i16();
      case 4: return this.u32();
      case 5: return this.i32();
      case 6: return this.f32();
      case 7: {
        const value = this.u8();
        if (value !== 0 && value !== 1) throw new GgufInspectionError('GGUF boolean metadata is invalid', 'GGUF_VALUE');
        return value === 1;
      }
      case 8: return this.string();
      case 9: this.skipValue(type); return undefined;
      case 10: return this.u64();
      case 11: {
        this.ensure(8);
        const value = this.view.getBigInt64(this.offset, true);
        this.offset += 8;
        return value >= BigInt(Number.MIN_SAFE_INTEGER) && value <= BigInt(Number.MAX_SAFE_INTEGER) ? Number(value) : value.toString();
      }
      case 12: return this.f64();
      default: throw new GgufInspectionError(`GGUF uses unknown metadata type ${type}`, 'GGUF_TYPE');
    }
  }
}

function numericMetadata(value) {
  return typeof value === 'number' && Number.isFinite(value) ? value : null;
}

/**
 * Inspect a `.gguf` File/Blob. The `file` object must support size and slice().
 * No tensor bytes are loaded into memory.
 */
export async function inspectGgufFile(file, options = {}) {
  if (!file || !Number.isSafeInteger(file.size) || file.size < 24 || typeof file.slice !== 'function') {
    throw new TypeError('A readable GGUF File or Blob is required');
  }
  const limits = { ...DEFAULT_LIMITS, ...options };
  if (file.size > (options.maxArtifactBytes ?? Number.MAX_SAFE_INTEGER)) {
    throw new GgufInspectionError('Model file exceeds the configured artifact size limit', 'GGUF_FILE_TOO_LARGE');
  }
  const windowBytes = Math.min(file.size, limits.maxMetadataBytes);
  const buffer = await file.slice(0, windowBytes).arrayBuffer();
  const reader = new Reader(buffer, file.size, limits);
  const magic = String.fromCharCode(reader.u8(), reader.u8(), reader.u8(), reader.u8());
  if (magic !== 'GGUF') throw new GgufInspectionError('Selected file is not a GGUF model (magic header mismatch)', 'GGUF_MAGIC');
  const version = reader.u32();
  if (version < 2 || version > 3) throw new GgufInspectionError(`GGUF version ${version} is not supported by this inspector`, 'GGUF_VERSION');
  const tensorCount = assertSafeLength(reader.u64(), limits.maxTensorCount, 'GGUF tensor count');
  const metadataCount = assertSafeLength(reader.u64(), limits.maxMetadataEntries, 'GGUF metadata entry count');
  const metadata = new Map();
  for (let index = 0; index < metadataCount; index++) {
    const key = reader.string();
    if (!/^[\x20-\x7e]{1,65535}$/.test(key)) throw new GgufInspectionError('GGUF metadata key is not valid ASCII', 'GGUF_KEY');
    const type = reader.u32();
    // Scalar metadata is bounded by the inspection window. Arrays (notably the
    // tokenizer vocabulary) are skipped without materializing their elements.
    metadata.set(key, reader.value(type));
  }

  const architecture = metadata.get('general.architecture');
  if (typeof architecture !== 'string' || !/^[a-zA-Z0-9._-]{1,80}$/.test(architecture)) {
    throw new GgufInspectionError('GGUF does not contain a valid general.architecture field', 'GGUF_ARCHITECTURE');
  }
  const readNumber = key => numericMetadata(metadata.get(`${architecture}.${key}`));
  const expertCount = readNumber('expert_count');
  const expertUsedCount = readNumber('expert_used_count');
  const contextLength = readNumber('context_length');
  const blockCount = readNumber('block_count');
  const embeddingLength = readNumber('embedding_length');
  const headCount = readNumber('attention.head_count');
  const headCountKv = readNumber('attention.head_count_kv');
  const keyLength = readNumber('attention.key_length');
  const valueLength = readNumber('attention.value_length');
  const fileType = numericMetadata(metadata.get('general.file_type'));

  return Object.freeze({
    format: 'gguf',
    version,
    architecture,
    name: typeof metadata.get('general.name') === 'string' ? metadata.get('general.name').slice(0, 240) : null,
    tensorCount,
    fileType,
    tokenizerModel: typeof metadata.get('tokenizer.ggml.model') === 'string' ? metadata.get('tokenizer.ggml.model').slice(0, 120) : null,
    hasChatTemplate: typeof metadata.get('tokenizer.chat_template') === 'string' && metadata.get('tokenizer.chat_template').length > 0,
    contextLength: contextLength && contextLength > 0 ? Math.min(contextLength, 131072) : null,
    blockCount: blockCount && blockCount > 0 ? Math.min(blockCount, 4096) : null,
    embeddingLength: embeddingLength && embeddingLength > 0 ? Math.min(embeddingLength, 1_000_000) : null,
    headCount: headCount && headCount > 0 ? Math.min(headCount, 4096) : null,
    headCountKv: headCountKv && headCountKv > 0 ? Math.min(headCountKv, 4096) : null,
    keyLength: keyLength && keyLength > 0 ? Math.min(keyLength, 65536) : null,
    valueLength: valueLength && valueLength > 0 ? Math.min(valueLength, 65536) : null,
    expertCount: expertCount && expertCount > 0 ? Math.min(expertCount, 100000) : null,
    expertUsedCount: expertUsedCount && expertUsedCount > 0 ? Math.min(expertUsedCount, 100000) : null,
    isMoE: Boolean(expertCount && expertCount > 0),
    fileBytes: file.size,
    metadataBytesRead: reader.offset
  });
}

/** Runtime compatibility is only claimed when the native runtime explicitly advertises it. */
export function evaluateGgufCompatibility(inspection, runtimeCapabilities = null) {
  if (!inspection || inspection.format !== 'gguf' || !inspection.architecture) {
    return Object.freeze({ status: 'invalid', reason: 'GGUF metadata is incomplete.' });
  }
  if (!runtimeCapabilities || runtimeCapabilities.available !== true) {
    return Object.freeze({ status: 'needs_runtime', reason: 'The model is imported, but no compatible native inference runtime is registered.' });
  }
  if (!Array.isArray(runtimeCapabilities.formats) || !runtimeCapabilities.formats.includes('gguf')) {
    return Object.freeze({ status: 'unsupported_format', reason: 'The connected runtime does not advertise GGUF support.' });
  }
  const architectureCandidates = runtimeCapabilities.architectureCandidates ?? runtimeCapabilities.supportedArchitectures;
  if (!Array.isArray(architectureCandidates) || (!architectureCandidates.includes('*') && !architectureCandidates.includes(inspection.architecture))) {
    return Object.freeze({ status: 'unsupported_architecture', reason: `The connected runtime does not list ${inspection.architecture} as an architecture candidate.` });
  }
  return Object.freeze({ status: 'runtime_compatible', reason: architectureCandidates.includes('*')
    ? 'The runtime will attempt architectures supported by its pinned loader. The exact model still requires a native load and inference test.'
    : 'The runtime lists this architecture as a candidate. The exact model still requires a native load and inference test.' });
}
