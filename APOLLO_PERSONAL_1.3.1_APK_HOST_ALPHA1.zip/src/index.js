export { DreamKernel } from './core/dream-kernel.js';
export { DreamPlanner } from './core/dream-planner.js';
export { validateBlueprint } from './core/blueprint-validator.js';
export { createGenerationSeed, makeSeededRandom, hashSeed } from './core/seed.js';
export { createFluidOrbSpec } from './generators/fluid-orb.js';
export { selectResourceProfile } from './core/resource-governor.js';
export { DomRenderer } from './render/dom-renderer.js';
export { SeedCache } from './cache/seed-cache.js';
export { canonicalStringify, estimateUtf8Bytes } from './cache/canonical.js';
export { SeedIntelligenceEngine } from './intelligence/seed-intelligence-engine.js';
export { StrategyRegistry, DEFAULT_STRATEGIES } from './intelligence/strategy-registry.js';
export { ReasoningPlanner } from './intelligence/reasoning-planner.js';
export { OperatorRegistry, BUILTIN_OPERATORS } from './intelligence/operators.js';
export { ContentAddressedStore } from './intelligence/content-addressed-store.js';
export { createKnowledgePacket, validateKnowledgePacket } from './intelligence/knowledge-packet.js';
export { createReasoningSeed, validateReasoningRequest, validateReasoningSeed, exportReasoningSeed, importReasoningSeed } from './intelligence/seed-packet.js';
export { validateControllerPlan, validateMoEResponse, validateEditorialResponse } from './intelligence/model-adapter-contracts.js';
export { SeedValidationError, MissingContextError, StrategyError } from './intelligence/errors.js';

export { MakeTiny2Engine, MakeTinyRecipeRegistry, createQuadraticMetaSeed, expandQuadraticMetaSeed, inspectQuadraticChildSeed, generateQuadraticChunk, MAKETINY2_FORMATS } from './intelligence/maketiny2.js';

export { MemoryKVAdapter, IndexedDBKVAdapter } from './persistence/kv-adapters.js';
export { FileKVAdapter } from './persistence/file-kv-adapter.js';
export { ApolloPersistentStore } from './persistence/apollo-persistent-store.js';
export { ApolloConversationService } from './conversation/apollo-conversation-service.js';
export { createPersistentApolloRuntime } from './persistence/create-apollo-runtime.js';

export { ModelResidencyManager, ModelResidencyError, calculateAiMemoryBudget, MODEL_MEMORY_UNITS } from './runtime/model-residency-manager.js';

export { LocalOpenAIClient, validateLocalInferenceUrl } from './runtime/openai-compatible-client.js';
export { LocalSlmControllerAdapter, LocalMoEChildAdapter, LocalEditorialAdapter, LocalDreamDirectorAdapter, LocalDreamSectionGenerator, createLocalApolloAdapters } from './runtime/local-model-adapters.js';
export { ApolloDreamService, validateDreamPlan } from './dream/apollo-dream-service.js';
export { ApolloVoiceSession, ApolloVoiceUnavailableError, createAndroidApolloVoiceProviders } from './voice/apollo-voice-session.js';
export { ResidencyBoundClient } from './runtime/residency-bound-client.js';

export { inspectGgufFile, evaluateGgufCompatibility, GgufInspectionError } from './runtime/gguf-inspector.js';
export { SleepingGiantRegistry } from './runtime/sleeping-giant-registry.js';
export { AndroidSleepingGiantBridge, AndroidSleepingGiantBridgeError } from './runtime/android-sleeping-giant-bridge.js';
export { NativeLlamaClient } from './runtime/native-llama-client.js';

export { normalizeAndroidDeviceProfile, estimateGgufKvCacheBytes, createAdaptiveModelProfile, formatAdaptiveProfileSummary } from './runtime/adaptive-model-profile.js';

export { benchmarkNativeModel } from './runtime/native-runtime-benchmark.js';
