import { createKnowledgePacket } from '../intelligence/knowledge-packet.js';
import { validateEditorialResponse } from '../intelligence/model-adapter-contracts.js';

const CAPABILITIES = new Set([
  'general_knowledge', 'scientific_reasoning', 'technical_explanation', 'comparison',
  'summarization', 'editorial_writing', 'mathematics', 'language_translation', 'conversation_context'
]);

function validateDreamPlan(plan) {
  if (!plan || typeof plan !== 'object' || Array.isArray(plan) || Object.keys(plan).some(key => !['title', 'sections'].includes(key))) throw new TypeError('Dream plan must be an object with only title and sections');
  if (typeof plan.title !== 'string' || !plan.title.trim() || plan.title.length > 180) throw new TypeError('Dream title is invalid');
  if (!Array.isArray(plan.sections) || plan.sections.length < 2 || plan.sections.length > 8) throw new RangeError('Dream must contain 2–8 sections');
  const ids = new Set();
  const sections = plan.sections.map((section, index) => {
    if (!section || typeof section !== 'object' || Array.isArray(section) || Object.keys(section).some(key => !['id', 'title', 'objective', 'capabilities'].includes(key)) || typeof section.id !== 'string' || !/^[a-z][a-z0-9_-]{1,39}$/.test(section.id) || ids.has(section.id)) throw new TypeError(`Invalid or duplicate Dream section at ${index}`);
    ids.add(section.id);
    if (typeof section.title !== 'string' || !section.title.trim() || section.title.length > 120) throw new TypeError(`Invalid Dream section title at ${index}`);
    if (typeof section.objective !== 'string' || !section.objective.trim() || section.objective.length > 600) throw new TypeError(`Invalid Dream section objective at ${index}`);
    const capabilities = Array.isArray(section.capabilities) ? [...new Set(section.capabilities)] : [];
    if (capabilities.length > 8 || capabilities.some(item => !CAPABILITIES.has(item))) throw new TypeError(`Unsupported capability in Dream section ${section.id}`);
    return Object.freeze({ id: section.id, title: section.title.trim(), objective: section.objective.trim(), capabilities: Object.freeze(capabilities) });
  });
  return Object.freeze({ title: plan.title.trim(), sections: Object.freeze(sections) });
}

function prefixClaims(packet, sectionId) {
  return packet.claims.map((claim, index) => ({
    ...claim,
    id: `${sectionId}-${index + 1}`,
    topic: sectionId
  }));
}

/**
 * Multi-section text Dream compositor. It uses the existing Dream/MAKETINY
 * parent seed, derives section seeds lazily, asks an injected local model
 * adapter for each section, and runs the common claim-preservation editorial gate.
 */
export class ApolloDreamService {
  constructor({ store, seedEngine, director, sectionGenerator, editor = null, maxConcurrency = 1 } = {}) {
    if (!store || !seedEngine || !director || typeof director.plan !== 'function' || !sectionGenerator || typeof sectionGenerator.generate !== 'function') {
      throw new TypeError('ApolloDreamService requires store, seedEngine, director and sectionGenerator');
    }
    if (maxConcurrency !== 1) throw new RangeError('v1 personal profile serializes Dream generation to protect 4 GB devices');
    this.store = store;
    this.seedEngine = seedEngine;
    this.director = director;
    this.sectionGenerator = sectionGenerator;
    this.editor = editor;
  }

  async create({ objective, randomSeed, signal, onStatus } = {}) {
    if (typeof objective !== 'string' || !objective.trim() || objective.length > 2000) throw new TypeError('Dream objective must be 1–2,000 characters');
    onStatus?.('dreaming_plan');
    const plan = validateDreamPlan(await this.director.plan({ objective: objective.trim(), signal }));
    const sectionNames = plan.sections.map(section => section.title);

    const contextPackets = [];
    const sectionOutputs = [];
    // Low-memory profile: one section model request at a time; only a section seed is materialized.
    for (let index = 0; index < plan.sections.length; index++) {
      if (signal?.aborted) throw new Error('Dream generation cancelled');
      const section = plan.sections[index];
      onStatus?.(`dreaming_section_${index + 1}_of_${plan.sections.length}`);
      const result = await this.sectionGenerator.generate({
        objective: section.objective,
        title: section.title,
        capabilities: [...section.capabilities],
        sectionIndex: index,
        signal
      });
      const packet = result?.knowledgePacket;
      if (!packet || !Array.isArray(packet.claims) || packet.claims.length < 1) throw new Error(`Dream section ${section.id} returned no claims`);
      const sectionPacket = await createKnowledgePacket({
        title: section.title,
        claims: prefixClaims(packet, section.id),
        metadata: { createdBy: packet.metadata?.createdBy ?? 'apollo-dream-model', collection: `dream:${section.id}`, language: 'en' }
      });
      contextPackets.push(sectionPacket.packet);
      sectionOutputs.push({ sectionId: section.id, claims: sectionPacket.packet.claims.length, delegatedToMoE: result.delegatedToMoE === true, fallbackUsed: result.fallbackReason === 'sleeping_giant_unavailable' });
    }

    const allClaims = contextPackets.flatMap(packet => packet.claims);
    const delegatedToMoE = sectionOutputs.some(section => section.delegatedToMoE);
    const moeFallbackUsed = sectionOutputs.some(section => section.fallbackUsed);
    const combined = await createKnowledgePacket({
      title: plan.title,
      claims: allClaims,
      metadata: { createdBy: 'apollo-dream-compositor', collection: 'apollo-dream', language: 'en' }
    });

    onStatus?.('dreaming_compile');
    const compiled = await this.seedEngine.compile({
      request: {
        taskType: 'article',
        objective: objective.trim(),
        title: plan.title,
        audience: 'curious general reader',
        language: 'en',
        editorialStyle: 'editorial'
      },
      knowledgePackets: [combined.packet],
      strategyId: 'editorial_article',
      dreamSections: sectionNames,
      randomSeed,
      modelPlan: { needsMoE: delegatedToMoE, capabilities: [...new Set(plan.sections.flatMap(section => section.capabilities))] }
    });

    await this.store.putSeed(compiled.seed, async seed => this.seedEngine.inspect(seed));
    await this.store.putSeed(compiled.dreamSeed, seed => this.seedEngine.makeTiny.validate(seed));

    // Root child 2 is the editorial plan. Derive only the requested section seeds.
    const editorialPlanSeed = await this.store.deriveChildSeed(compiled.dreamSeed.seedId, 2, this.seedEngine.makeTiny);
    const sectionSeedCount = await this.seedEngine.makeTiny.countChildren(editorialPlanSeed);
    if (sectionSeedCount !== plan.sections.length) throw new Error('Dream blueprint and MAKETINY section count diverged');
    const sectionSeedIds = [];
    for (let index = 0; index < sectionSeedCount; index++) {
      const child = await this.store.deriveChildSeed(editorialPlanSeed, index, this.seedEngine.makeTiny);
      sectionSeedIds.push(child.seedId);
    }

    onStatus?.('dreaming_editorial');
    const assembled = await this.seedEngine.replay(compiled.seed, { allowPrecomputedMoEContext: delegatedToMoE });
    let document = assembled.document.text;
    let editorialApplied = false;
    let editorialFallback = false;
    if (this.editor?.rewrite) {
      const expectedClaimIds = allClaims.map(claim => claim.id);
      try {
        const edited = validateEditorialResponse(await this.editor.rewrite({
          prompt: objective,
          draft: document,
          knowledgePacket: combined.packet,
          expectedClaimIds,
          style: 'editorial',
          signal
        }), expectedClaimIds);
        document = edited.text;
        editorialApplied = true;
      } catch (error) {
        if (signal?.aborted) throw error;
        editorialFallback = true;
      }
    }

    onStatus?.('dream_complete');
    return Object.freeze({
      title: plan.title,
      objective: objective.trim(),
      document,
      sections: Object.freeze(sectionOutputs),
      seeds: Object.freeze({ reasoning: compiled.seed.seedId, dream: compiled.dreamSeed.seedId, editorialPlan: editorialPlanSeed.seedId, sectionSeeds: Object.freeze(sectionSeedIds) }),
      metrics: Object.freeze({ claimCount: allClaims.length, sectionCount: plan.sections.length, editorialApplied, editorialFallback, delegatedToMoE, moeFallbackUsed, cacheHit: assembled.cache.hit }),
      provenance: assembled.provenance
    });
  }
}

export { validateDreamPlan };
