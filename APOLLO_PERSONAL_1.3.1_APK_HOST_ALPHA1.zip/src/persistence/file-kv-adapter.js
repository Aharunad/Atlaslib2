import { mkdir, readFile, rename, writeFile, rm } from 'node:fs/promises';
import { dirname, basename, resolve } from 'node:path';
import { randomUUID } from 'node:crypto';

function validateKey(key) {
  if (typeof key !== 'string' || !key || key.length > 512) throw new TypeError('Storage key must be a non-empty string of at most 512 characters');
}
function clone(value) { return value === undefined ? undefined : structuredClone(value); }

/** Node-side durable adapter for repeatable integration tests and desktop tooling.
 * Android/WebView production uses IndexedDBKVAdapter or a native SQLite adapter.
 */
export class FileKVAdapter {
  constructor(filePath, { maxBytes = 64 * 1024 * 1024 } = {}) {
    if (typeof filePath !== 'string' || !filePath.trim()) throw new TypeError('A storage file path is required');
    this.filePath = resolve(filePath);
    this.maxBytes = maxBytes;
    this.queue = Promise.resolve();
  }

  async #read() {
    try {
      const raw = await readFile(this.filePath, 'utf8');
      const data = JSON.parse(raw);
      if (!data || data.format !== 'APOLLO_FILE_KV' || data.schemaVersion !== 1 || !Array.isArray(data.records)) throw new Error('Invalid Apollo storage database');
      return new Map(data.records);
    } catch (error) {
      if (error.code === 'ENOENT') return new Map();
      throw error;
    }
  }

  async #commit(records) {
    const payload = JSON.stringify({ format: 'APOLLO_FILE_KV', schemaVersion: 1, records: [...records.entries()] });
    const bytes = Buffer.byteLength(payload);
    if (bytes > this.maxBytes) throw new RangeError('Persistent storage byte budget exceeded');
    await mkdir(dirname(this.filePath), { recursive: true });
    const tempPath = resolve(dirname(this.filePath), `.${basename(this.filePath)}.${randomUUID()}.tmp`);
    try {
      await writeFile(tempPath, payload, { encoding: 'utf8', flag: 'wx', mode: 0o600 });
      await rename(tempPath, this.filePath);
    } catch (error) {
      await rm(tempPath, { force: true }).catch(() => {});
      throw error;
    }
  }

  #serial(task) {
    const result = this.queue.then(task, task);
    this.queue = result.catch(() => {});
    return result;
  }

  async get(key) {
    validateKey(key);
    return this.#serial(async () => clone((await this.#read()).get(key)));
  }
  async put(key, value) { await this.batch([{ type: 'put', key, value }]); }
  async delete(key) { await this.batch([{ type: 'delete', key }]); }
  async list(prefix = '') {
    return this.#serial(async () => [...(await this.#read()).entries()]
      .filter(([key]) => key.startsWith(prefix)).map(([key, value]) => ({ key, value: clone(value) })));
  }
  async update(key, updater) {
    validateKey(key);
    if (typeof updater !== 'function') throw new TypeError('Updater must be a function');
    return this.#serial(async () => {
      const records = await this.#read();
      const next = updater(clone(records.get(key)));
      if (next === undefined) records.delete(key);
      else records.set(key, clone(next));
      await this.#commit(records);
      return clone(next);
    });
  }
  async batch(operations) {
    if (!Array.isArray(operations) || operations.length > 10000) throw new TypeError('Invalid storage batch');
    for (const op of operations) {
      if (!op || !['put', 'delete'].includes(op.type)) throw new TypeError('Unknown storage operation');
      validateKey(op.key);
      if (op.type === 'put' && op.value === undefined) throw new TypeError('Storage put requires a value');
    }
    return this.#serial(async () => {
      const records = await this.#read();
      for (const op of operations) op.type === 'delete' ? records.delete(op.key) : records.set(op.key, clone(op.value));
      await this.#commit(records);
      return Object.freeze({ applied: operations.length });
    });
  }
  async clear(prefix = '') {
    return this.#serial(async () => {
      const records = await this.#read();
      const keys = [...records.keys()].filter(key => key.startsWith(prefix));
      for (const key of keys) records.delete(key);
      await this.#commit(records);
      return keys.length;
    });
  }
}
