import { canonicalStringify } from '../cache/canonical.js';
import { canonicalBytes, sha256Hex } from '../intelligence/digest.js';
import { MissingContextError } from '../intelligence/errors.js';

const REF_RE = /^sha256:[a-f0-9]{64}$/;
const ID_RE = /^[a-zA-Z0-9][a-zA-Z0-9._:-]{0,95}$/;
const ROLE_SET = new Set(['system', 'user', 'assistant']);

function validateSessionId(id) {
  if (typeof id !== 'string' || !ID_RE.test(id)) throw new TypeError('Invalid Apollo session ID');
}
function validateTurn(turn) {
  if (!turn || typeof turn !== 'object' || Array.isArray(turn)) throw new TypeError('Conversation turn must be an object');
  if (!ROLE_SET.has(turn.role)) throw new TypeError('Unsupported conversation role');
  if (typeof turn.text !== 'string' || !turn.text.trim() || turn.text.length > 30000) throw new TypeError('Conversation text must be non-empty and at most 30,000 characters');
  if (turn.seedRefs !== undefined && (!Array.isArray(turn.seedRefs) || turn.seedRefs.length > 8 || turn.seedRefs.some(ref => typeof ref !== 'string' || !/^[a-f0-9]{64}$/.test(ref)))) throw new TypeError('Invalid conversation seed references');
  if (turn.metadata !== undefined && (!turn.metadata || typeof turn.metadata !== 'object' || Array.isArray(turn.metadata) || canonicalBytes(turn.metadata) > 8192)) throw new TypeError('Conversation metadata is invalid or too large');
}
function nowIso() { return new Date().toISOString(); }

/**
 * Persistent repository shared by browser IndexedDB, native adapters and the
 * durable Node test adapter. Seeds and content are separate records.
 */
export class ApolloPersistentStore {
  constructor({ adapter, maxContentBytes = 64 * 1024 * 1024, maxSessionTurns = 120, maxSessionBytes = 2 * 1024 * 1024, maxCacheBytes = 8 * 1024 * 1024, now = () => Date.now() } = {}) {
    if (!adapter || !['get', 'put', 'delete', 'list', 'update', 'batch'].every(name => typeof adapter[name] === 'function')) throw new TypeError('A transactional key/value adapter is required');
    for (const [name, value] of Object.entries({ maxContentBytes, maxSessionTurns, maxSessionBytes, maxCacheBytes })) {
      if (!Number.isSafeInteger(value) || value <= 0) throw new RangeError(`${name} must be a positive safe integer`);
    }
    this.adapter = adapter;
    this.maxContentBytes = maxContentBytes;
    this.maxSessionTurns = maxSessionTurns;
    this.maxSessionBytes = maxSessionBytes;
    this.maxCacheBytes = maxCacheBytes;
    this.now = now;
    this.contentQueue = Promise.resolve();
  }

  // ContentAddressedStore-compatible port used by SeedIntelligenceEngine.
  async put(value) { return this.putContent(value); }
  async get(reference) { return this.getContent(reference); }
  async has(reference) { return this.hasContent(reference); }
  async delete(reference) { return this.deleteContent(reference); }

  async putContent(value) {
    const operation = this.contentQueue.then(() => this.#putContent(value));
    this.contentQueue = operation.catch(() => {});
    return operation;
  }

  async #putContent(value) {
    const digest = await sha256Hex(value);
    const reference = `sha256:${digest}`;
    const size = canonicalBytes(value);
    if (size > this.maxContentBytes) throw new RangeError('Content packet exceeds the persistent content budget');
    const key = `content:${digest}`;
    const existing = await this.adapter.get(key);
    if (existing) {
      await this.getContent(reference);
      return Object.freeze({ reference, digest, size: existing.size, inserted: false });
    }
    const entries = await this.adapter.list('content:');
    const currentBytes = entries.reduce((sum, item) => sum + item.value.size, 0);
    if (currentBytes + size > this.maxContentBytes) throw new RangeError('Persistent content store is full; prune unreferenced content before inserting');
    await this.adapter.put(key, { reference, digest, size, value: structuredClone(value), storedAt: this.now() });
    return Object.freeze({ reference, digest, size, inserted: true });
  }

  async getContent(reference) {
    if (typeof reference !== 'string' || !REF_RE.test(reference)) throw new TypeError('Invalid content reference');
    const record = await this.adapter.get(`content:${reference.slice(7)}`);
    if (!record) throw new MissingContextError(reference);
    if (record.reference !== reference || `sha256:${await sha256Hex(record.value)}` !== reference) throw new Error(`Persistent content integrity check failed: ${reference}`);
    return structuredClone(record.value);
  }

  async hasContent(reference) {
    if (typeof reference !== 'string' || !REF_RE.test(reference)) return false;
    return Boolean(await this.adapter.get(`content:${reference.slice(7)}`));
  }

  async deleteContent(reference) {
    if (typeof reference !== 'string' || !REF_RE.test(reference)) throw new TypeError('Invalid content reference');
    const dependentSeeds = (await this.adapter.list('seed:')).filter(item => (item.value.seed.contextRefs ?? []).includes(reference));
    if (dependentSeeds.length) throw new Error('Cannot delete knowledge still referenced by persisted seeds');
    await this.adapter.delete(`content:${reference.slice(7)}`);
  }

  async putSeed(seed, validator) {
    if (!seed || typeof seed !== 'object' || typeof seed.seedId !== 'string' || !/^[a-f0-9]{64}$/.test(seed.seedId)) throw new TypeError('Invalid seed object');
    if (typeof validator !== 'function') throw new TypeError('A seed validator is required');
    await validator(seed);
    for (const reference of (seed.contextRefs ?? [])) {
      if (!await this.hasContent(reference)) throw new MissingContextError(reference);
    }
    if (seed.parentSeedId && !await this.adapter.get(`seed:${seed.parentSeedId}`)) {
      throw new Error('Cannot persist a child seed without its parent seed');
    }
    const size = canonicalBytes(seed);
    if (size > 64 * 1024) throw new RangeError('Seed exceeds the persistent seed size limit');
    const key = `seed:${seed.seedId}`;
    const existing = await this.adapter.get(key);
    if (existing) {
      if (canonicalStringify(existing.seed) !== canonicalStringify(seed)) throw new Error('Seed ID collision or stored seed mismatch');
      return Object.freeze({ seedId: seed.seedId, size, inserted: false });
    }
    await this.adapter.put(key, { seedId: seed.seedId, size, seed: structuredClone(seed), storedAt: this.now() });
    return Object.freeze({ seedId: seed.seedId, size, inserted: true });
  }

  async deriveChildSeed(parentSeedOrId, index, makeTinyEngine, { persist = false } = {}) {
    if (!makeTinyEngine || typeof makeTinyEngine.deriveChild !== 'function') throw new TypeError('A MAKETINY-compatible engine is required');
    const parentSeed = typeof parentSeedOrId === 'string'
      ? await this.getSeed(parentSeedOrId, seed => makeTinyEngine.validate(seed))
      : parentSeedOrId;
    if (!parentSeed) throw new Error('Parent seed was not found');
    await makeTinyEngine.validate(parentSeed);
    const child = await makeTinyEngine.deriveChild(parentSeed, index);
    if (persist) await this.putSeed(child, seed => makeTinyEngine.validate(seed));
    return child;
  }

  async deleteSeed(seedId) {
    if (typeof seedId !== 'string' || !/^[a-f0-9]{64}$/.test(seedId)) throw new TypeError('Invalid seed ID');
    const children = (await this.adapter.list('seed:')).filter(item => item.value.seed?.parentSeedId === seedId);
    if (children.length) throw new Error('Cannot delete a parent seed while persisted child seeds depend on it');
    await this.adapter.delete(`seed:${seedId}`);
  }

  async getSeed(seedId, validator) {
    if (typeof seedId !== 'string' || !/^[a-f0-9]{64}$/.test(seedId)) throw new TypeError('Invalid seed ID');
    const record = await this.adapter.get(`seed:${seedId}`);
    if (!record) return undefined;
    if (typeof validator === 'function') await validator(record.seed);
    if (record.seed.seedId !== seedId) throw new Error('Stored seed ID mismatch');
    return structuredClone(record.seed);
  }

  async createSession({ id, title = 'Conversation', createdAt = nowIso(), metadata = {} } = {}) {
    id ??= `apollo-${globalThis.crypto.randomUUID()}`;
    validateSessionId(id);
    if (typeof title !== 'string' || !title.trim() || title.length > 160) throw new TypeError('Session title must be 1–160 characters');
    if (!metadata || typeof metadata !== 'object' || Array.isArray(metadata) || canonicalBytes(metadata) > 8192) throw new TypeError('Session metadata is invalid or too large');
    const record = { id, title: title.trim(), createdAt, updatedAt: createdAt, revision: 0, turns: [], metadata: structuredClone(metadata) };
    let created = false;
    const session = await this.adapter.update(`session:${id}`, current => {
      if (current) return current;
      created = true;
      return record;
    });
    return Object.freeze({ session, created });
  }

  async getSession(id, { limit = this.maxSessionTurns } = {}) {
    validateSessionId(id);
    if (!Number.isInteger(limit) || limit < 1 || limit > this.maxSessionTurns) throw new RangeError('Invalid session turn limit');
    const session = await this.adapter.get(`session:${id}`);
    if (!session) return undefined;
    return Object.freeze({ ...session, turns: session.turns.slice(-limit) });
  }

  async appendTurn(id, turn) {
    validateSessionId(id);
    validateTurn(turn);
    const enriched = {
      id: turn.id ?? `turn-${globalThis.crypto.randomUUID()}`,
      role: turn.role,
      text: turn.text,
      createdAt: turn.createdAt ?? nowIso(),
      ...(turn.seedRefs ? { seedRefs: [...turn.seedRefs] } : {}),
      ...(turn.metadata ? { metadata: structuredClone(turn.metadata) } : {})
    };
    const session = await this.adapter.update(`session:${id}`, current => {
      if (!current) throw new Error(`Apollo session not found: ${id}`);
      const turns = [...current.turns, enriched].slice(-this.maxSessionTurns);
      const next = { ...current, turns, revision: current.revision + 1, updatedAt: enriched.createdAt };
      if (canonicalBytes(next) > this.maxSessionBytes) throw new RangeError('Apollo conversation reached its storage budget');
      return next;
    });
    return Object.freeze({ revision: session.revision, turn: enriched });
  }

  async listSessions({ limit = 50 } = {}) {
    if (!Number.isInteger(limit) || limit < 1 || limit > 500) throw new RangeError('Invalid session list limit');
    const records = await this.adapter.list('session:');
    return records.map(item => item.value).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)).slice(0, limit).map(({ turns, ...session }) => session);
  }

  async deleteSession(id) {
    validateSessionId(id);
    await this.adapter.delete(`session:${id}`);
  }

  // Async result-cache port consumed by SeedIntelligenceEngine.
  async getAsync(key) { return this.cacheGet(key); }
  async setAsync(key, value, options) { return this.cacheSet(key, value, options); }

  async cacheGet(key) {
    if (typeof key !== 'string' || !key || key.length > 500) throw new TypeError('Invalid cache key');
    const recordKey = `cache:${key}`;
    const record = await this.adapter.get(recordKey);
    if (!record) return undefined;
    if (record.expiresAt <= this.now()) {
      await this.adapter.delete(recordKey);
      return undefined;
    }
    await this.adapter.update(recordKey, current => current ? { ...current, accessedAt: this.now() } : undefined);
    return structuredClone(record.value);
  }

  async cacheSet(key, value, { ttlMs = 6 * 60 * 60 * 1000 } = {}) {
    if (typeof key !== 'string' || !key || key.length > 500) throw new TypeError('Invalid cache key');
    if (!Number.isSafeInteger(ttlMs) || ttlMs < 1000 || ttlMs > 30 * 24 * 60 * 60 * 1000) throw new RangeError('Invalid cache TTL');
    const size = canonicalBytes(value);
    if (size > this.maxCacheBytes) return false;
    const entries = await this.adapter.list('cache:');
    const currentKey = `cache:${key}`;
    const now = this.now();
    const expired = entries.filter(item => item.key !== currentKey && item.value.expiresAt <= now);
    let total = entries.reduce((sum, item) => sum + (item.key === currentKey || item.value.expiresAt <= now ? 0 : item.value.size), 0);
    const remaining = entries.filter(item => item.key !== currentKey && item.value.expiresAt > now).sort((a, b) => a.value.accessedAt - b.value.accessedAt);
    const operations = expired.map(item => ({ type: 'delete', key: item.key }));
    for (const item of remaining) {
      if (total + size <= this.maxCacheBytes) break;
      operations.push({ type: 'delete', key: item.key });
      total -= item.value.size;
    }
    operations.push({ type: 'put', key: currentKey, value: { value: structuredClone(value), size, expiresAt: this.now() + ttlMs, accessedAt: this.now() } });
    await this.adapter.batch(operations);
    return true;
  }

  async cacheDelete(key) { await this.adapter.delete(`cache:${key}`); }

  async pruneCache() {
    const now = this.now();
    const entries = await this.adapter.list('cache:');
    const expired = entries.filter(item => item.value.expiresAt <= now);
    if (expired.length) await this.adapter.batch(expired.map(item => ({ type: 'delete', key: item.key })));
    return expired.length;
  }

  async stats() {
    const [contents, seeds, sessions, cache] = await Promise.all([
      this.adapter.list('content:'), this.adapter.list('seed:'), this.adapter.list('session:'), this.adapter.list('cache:')
    ]);
    return Object.freeze({
      contentEntries: contents.length,
      contentBytes: contents.reduce((sum, item) => sum + item.value.size, 0),
      seedEntries: seeds.length,
      seedBytes: seeds.reduce((sum, item) => sum + item.value.size, 0),
      sessions: sessions.length,
      cacheEntries: cache.length,
      cacheBytes: cache.reduce((sum, item) => sum + item.value.size, 0),
      cacheLimit: this.maxCacheBytes
    });
  }

  async clearCache() { return this.adapter.clear('cache:'); }
}
