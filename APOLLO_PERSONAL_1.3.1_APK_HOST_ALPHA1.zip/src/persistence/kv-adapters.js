/**
 * Minimal transactional key/value adapters used by Apollo's persistent store.
 * Values are JSON-compatible structured-clone data; executable values are never stored.
 */

function clone(value) {
  return value === undefined ? undefined : structuredClone(value);
}

function validateKey(key) {
  if (typeof key !== 'string' || !key || key.length > 512) throw new TypeError('Storage key must be a non-empty string of at most 512 characters');
}

function validateOperations(operations) {
  if (!Array.isArray(operations) || operations.length > 10000) throw new TypeError('Storage batch must contain at most 10,000 operations');
  for (const operation of operations) {
    if (!operation || !['put', 'delete'].includes(operation.type)) throw new TypeError('Unknown storage operation');
    validateKey(operation.key);
    if (operation.type === 'put' && operation.value === undefined) throw new TypeError('Storage put requires a value');
  }
}

/** In-memory adapter for tests and ephemeral sessions. */
export class MemoryKVAdapter {
  constructor({ maxBytes = 64 * 1024 * 1024 } = {}) {
    this.maxBytes = maxBytes;
    this.records = new Map();
  }
  async get(key) { validateKey(key); return clone(this.records.get(key)); }
  async put(key, value) { await this.batch([{ type: 'put', key, value }]); }
  async delete(key) { await this.batch([{ type: 'delete', key }]); }
  async list(prefix = '') {
    return [...this.records.entries()].filter(([key]) => key.startsWith(prefix)).map(([key, value]) => ({ key, value: clone(value) }));
  }
  async update(key, updater) {
    validateKey(key);
    if (typeof updater !== 'function') throw new TypeError('Updater must be a function');
    const staged = new Map(this.records);
    const next = updater(clone(staged.get(key)));
    if (next === undefined) staged.delete(key);
    else staged.set(key, clone(next));
    this.#assertBudget(staged);
    this.records = staged;
    return clone(next);
  }
  async batch(operations) {
    validateOperations(operations);
    const staged = new Map(this.records);
    for (const operation of operations) {
      if (operation.type === 'delete') staged.delete(operation.key);
      else staged.set(operation.key, clone(operation.value));
    }
    this.#assertBudget(staged);
    this.records = staged;
    return Object.freeze({ applied: operations.length });
  }
  async clear(prefix = '') {
    const keys = [...this.records.keys()].filter(key => key.startsWith(prefix));
    for (const key of keys) this.records.delete(key);
    return keys.length;
  }
  #assertBudget(records = this.records) {
    const size = new TextEncoder().encode(JSON.stringify([...records.entries()])).byteLength;
    if (size > this.maxBytes) throw new RangeError('Storage adapter byte budget exceeded');
  }
}

/**
 * Browser/WebView IndexedDB adapter. Uses one object store so each batch or
 * update commits atomically. Intended for app-private origin storage.
 */
export class IndexedDBKVAdapter {
  constructor({ dbName = 'atlas-apollo', storeName = 'records', version = 1 } = {}) {
    if (!globalThis.indexedDB) throw new Error('IndexedDB is unavailable in this runtime');
    this.dbName = dbName;
    this.storeName = storeName;
    this.version = version;
    this.openPromise = null;
  }

  async #db() {
    if (!this.openPromise) {
      this.openPromise = new Promise((resolve, reject) => {
        const request = globalThis.indexedDB.open(this.dbName, this.version);
        request.onupgradeneeded = () => {
          const db = request.result;
          if (!db.objectStoreNames.contains(this.storeName)) db.createObjectStore(this.storeName, { keyPath: 'key' });
        };
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error ?? new Error('Could not open Atlas IndexedDB'));
        request.onblocked = () => reject(new Error('Atlas IndexedDB upgrade is blocked by another open connection'));
      });
    }
    return this.openPromise;
  }

  async get(key) {
    validateKey(key);
    const db = await this.#db();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(this.storeName, 'readonly');
      const request = tx.objectStore(this.storeName).get(key);
      request.onsuccess = () => resolve(clone(request.result?.value));
      request.onerror = () => reject(request.error ?? new Error('IndexedDB read failed'));
      tx.onabort = () => reject(tx.error ?? new Error('IndexedDB read aborted'));
    });
  }

  async put(key, value) { await this.batch([{ type: 'put', key, value }]); }
  async delete(key) { await this.batch([{ type: 'delete', key }]); }

  async list(prefix = '') {
    const db = await this.#db();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(this.storeName, 'readonly');
      const request = tx.objectStore(this.storeName).getAll();
      request.onsuccess = () => resolve(request.result
        .filter(item => item.key.startsWith(prefix))
        .map(item => ({ key: item.key, value: clone(item.value) })));
      request.onerror = () => reject(request.error ?? new Error('IndexedDB list failed'));
      tx.onabort = () => reject(tx.error ?? new Error('IndexedDB list aborted'));
    });
  }

  async update(key, updater) {
    validateKey(key);
    if (typeof updater !== 'function') throw new TypeError('Updater must be a function');
    const db = await this.#db();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(this.storeName, 'readwrite');
      const store = tx.objectStore(this.storeName);
      const request = store.get(key);
      let result;
      request.onsuccess = () => {
        try {
          result = updater(clone(request.result?.value));
          if (result === undefined) store.delete(key);
          else store.put({ key, value: clone(result) });
        } catch (error) {
          try { tx.abort(); } catch {}
          reject(error);
        }
      };
      tx.oncomplete = () => resolve(clone(result));
      tx.onerror = () => reject(tx.error ?? new Error('IndexedDB update failed'));
      tx.onabort = () => reject(tx.error ?? new Error('IndexedDB update aborted'));
    });
  }

  async batch(operations) {
    validateOperations(operations);
    const db = await this.#db();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(this.storeName, 'readwrite');
      const store = tx.objectStore(this.storeName);
      for (const operation of operations) {
        if (operation.type === 'delete') store.delete(operation.key);
        else store.put({ key: operation.key, value: clone(operation.value) });
      }
      tx.oncomplete = () => resolve(Object.freeze({ applied: operations.length }));
      tx.onerror = () => reject(tx.error ?? new Error('IndexedDB batch failed'));
      tx.onabort = () => reject(tx.error ?? new Error('IndexedDB batch aborted'));
    });
  }

  async clear(prefix = '') {
    const matches = await this.list(prefix);
    if (matches.length) await this.batch(matches.map(item => ({ type: 'delete', key: item.key })));
    return matches.length;
  }

  async close() {
    if (!this.openPromise) return;
    const db = await this.openPromise;
    db.close();
    this.openPromise = null;
  }
}
