import { DreamKernel } from '../core/dream-kernel.js';
import { SeedIntelligenceEngine } from '../intelligence/seed-intelligence-engine.js';
import { ApolloConversationService } from '../conversation/apollo-conversation-service.js';
import { IndexedDBKVAdapter } from './kv-adapters.js';
import { ApolloPersistentStore } from './apollo-persistent-store.js';
import { ModelResidencyManager } from '../runtime/model-residency-manager.js';

/**
 * Production browser/Android-WebView composition root. Uses app-origin IndexedDB
 * for persistent content, seed, session and result-cache records. Model adapters
 * are supplied when the real local SLM/MoE runtimes are integrated.
 */
export function createPersistentApolloRuntime({
  device = {},
  dbName = 'atlas-library-apollo',
  maxContentBytes = 64 * 1024 * 1024,
  maxSessionTurns = 120,
  maxSessionBytes = 2 * 1024 * 1024,
  maxCacheBytes = 8 * 1024 * 1024,
  modelCatalog = null,
  modelLoader = null,
  getMemorySnapshot = null,
  modelMemoryPolicy = {}
} = {}) {
  const runtimeOptions = [modelCatalog, modelLoader, getMemorySnapshot];
  const runtimeOptionsProvided = runtimeOptions.filter(value => value !== null && value !== undefined).length;
  if (runtimeOptionsProvided !== 0 && runtimeOptionsProvided !== 3) {
    throw new TypeError('Model residency integration requires modelCatalog, modelLoader and getMemorySnapshot together');
  }
  const modelResidencyManager = runtimeOptionsProvided === 3
    ? new ModelResidencyManager({ catalog: modelCatalog, loader: modelLoader, getMemorySnapshot, policy: modelMemoryPolicy })
    : null;
  const storageAdapter = new IndexedDBKVAdapter({ dbName, storeName: 'records', version: 1 });
  const store = new ApolloPersistentStore({
    adapter: storageAdapter,
    maxContentBytes,
    maxSessionTurns,
    maxSessionBytes,
    maxCacheBytes
  });
  const seedIntelligence = new SeedIntelligenceEngine({ contentStore: store, cache: store });
  const kernel = new DreamKernel({ device, seedIntelligence });

  return Object.freeze({
    kernel,
    store,
    storageAdapter,
    modelResidencyManager,
    createConversationService({ controller, moeChild, editor, maxHistoryTurns } = {}) {
      return new ApolloConversationService({ store, seedEngine: seedIntelligence, controller, moeChild, editor, maxHistoryTurns });
    },
    async close() {
      if (modelResidencyManager) await modelResidencyManager.dispose();
      await storageAdapter.close();
    }
  });
}
