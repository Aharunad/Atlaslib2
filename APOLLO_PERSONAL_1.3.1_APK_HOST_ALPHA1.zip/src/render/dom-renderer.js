import { DreamRenderError } from '../core/errors.js';
import { validateBlueprint } from '../core/blueprint-validator.js';
import { createFluidOrbSpec } from '../generators/fluid-orb.js';

const STYLE = `
:host{display:block;color:#17191b;font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif}
.dream-screen{min-height:100%;display:flex;flex-direction:column;background:#fff;padding:18px 22px 24px;box-sizing:border-box;max-width:560px;margin:0 auto}
.dream-topbar{display:flex;align-items:center;justify-content:space-between;padding:3px 0 28px;font-size:10px;letter-spacing:.19em;color:#85898d}
.dream-topbar strong{color:#17191b;font-weight:550}.dream-topbar small{font-size:8px;letter-spacing:.13em}
.dream-column{display:flex;flex-direction:column;gap:15px}.dream-row{display:flex;align-items:center;gap:12px}.dream-title{font-size:clamp(32px,8vw,43px);line-height:1.04;letter-spacing:-.075em;font-weight:400;margin:0}.dream-body{font-size:15px;line-height:1.75;color:#45494d;margin:0}.dream-editorial{font-family:Georgia,"Times New Roman",serif;font-size:18px;line-height:1.85;color:#303438}.dream-muted{font-size:13px;line-height:1.65;color:#85898d;margin:0;max-width:340px}.dream-label{font-size:9px;letter-spacing:.19em;color:#9a9da0;text-transform:uppercase}.dream-card{border:1px solid #e9eaeb;border-radius:17px;padding:16px;background:#fff}.dream-card.soft{background:#fafafa;border-color:#f0f0f0}.dream-divider{height:1px;background:#ededee;border:0;margin:7px 0}.dream-spacer{height:12px}.dream-button{border:0;border-radius:13px;background:#17191b;color:#fff;padding:14px 17px;font-size:13px}.dream-button.ghost{background:#fff;color:#45494d;border:1px solid #e8e9ea}.dream-tabs{margin-top:auto;padding-top:22px;display:grid;grid-template-columns:repeat(3,1fr);gap:7px}.dream-tab{border:1px solid #ececee;border-radius:12px;background:#fff;padding:11px 5px;color:#85898d;font-size:11px}.dream-tab.active{background:#f5f5f6;color:#17191b;border-color:#dedfe1}.dream-composer{display:flex;gap:8px;border:1px solid #e6e7e9;border-radius:17px;padding:7px;background:#fff;box-shadow:0 7px 26px #00000005}.dream-composer input{flex:1;min-width:0;border:0;outline:0;padding:9px;background:transparent;color:#17191b;font:inherit;font-size:13px}.dream-composer button{border:0;border-radius:12px;background:#17191b;color:#fff;width:42px;font-size:16px}.dream-suggestions{display:flex;flex-direction:column;gap:8px}.dream-suggestion{border:1px solid #ececee;border-radius:12px;padding:12px 14px;color:#555b60;font-size:12px;background:#fff;text-align:left}.dream-orb{width:min(100%,270px);aspect-ratio:1;margin:3px auto 0;overflow:visible;filter:drop-shadow(0 18px 28px #18274420)}.dream-orb svg{width:100%;height:100%;display:block;overflow:visible}.dream-orb .ribbon{transform-origin:120px 120px;filter:drop-shadow(0 4px 7px #a8a6cb35)}.dream-orb.motion .ribbon{animation:dreamFloat 11s ease-in-out infinite alternate}.dream-orb.motion .ribbon:nth-child(2n){animation-duration:14s}.dream-orb.motion .ribbon:nth-child(3n){animation-duration:17s}@keyframes dreamFloat{from{transform:rotate(-4deg) scale(.98)}to{transform:rotate(5deg) scale(1.025)}}
@media(prefers-reduced-motion:reduce){.dream-orb.motion .ribbon{animation:none}}
`;

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = String(text);
  return node;
}

export class DomRenderer {
  constructor({ root, onAction = () => {}, animations = true }) {
    if (!root) throw new DreamRenderError('Renderer root element is required.');
    this.root = root;
    this.onAction = onAction;
    this.animations = animations;
    this.root.replaceChildren();
    const style = document.createElement('style');
    style.textContent = STYLE;
    this.styleElement = style;
  }

  render(blueprint) {
    validateBlueprint(blueprint);
    const view = this.#renderNode(blueprint.tree);
    this.root.replaceChildren(this.styleElement, view);
    return view;
  }

  #renderNode(spec) {
    const p = spec.props ?? {};
    let out;
    switch (spec.type) {
      case 'screen': out = el('main', 'dream-screen'); break;
      case 'topbar': {
        out = el('header', 'dream-topbar');
        const left = el('div');
        const strong = el('strong', '', p.title ?? 'ATLAS');
        left.append(strong);
        if (p.subtitle) left.append(el('span', '', `  ${p.subtitle}`));
        out.append(left);
        if (p.trailing) out.append(el('small', '', p.trailing));
        break;
      }
      case 'column': out = el('section', 'dream-column'); break;
      case 'row': out = el('div', 'dream-row'); break;
      case 'text': {
        const tag = p.tone === 'title' ? 'h1' : 'p';
        const cls = p.tone === 'title' ? 'dream-title' : p.tone === 'editorial' ? 'dream-editorial' : 'dream-body';
        out = el(tag, cls, p.text ?? '');
        break;
      }
      case 'caption': out = el('p', p.tone === 'label' ? 'dream-label' : 'dream-muted', p.text ?? ''); break;
      case 'card': out = el('section', `dream-card ${p.variant === 'soft' ? 'soft' : ''}`); break;
      case 'divider': out = el('hr', 'dream-divider'); break;
      case 'spacer': out = el('div', 'dream-spacer'); break;
      case 'button': {
        out = el('button', `dream-button ${p.variant === 'ghost' ? 'ghost' : ''}`, p.label ?? 'Continue');
        out.type = 'button';
        out.addEventListener('click', () => this.onAction(p.action));
        break;
      }
      case 'fluid-orb': out = this.#renderOrb(p); break;
      case 'chat-composer': {
        out = el('form', 'dream-composer');
        const input = el('input'); input.type = 'text'; input.placeholder = p.placeholder ?? 'Ask Apollo…'; input.maxLength = 4000; input.autocomplete = 'off';
        const button = el('button', '', '↑'); button.type = 'submit'; button.setAttribute('aria-label', 'Send message');
        out.append(input, button);
        out.addEventListener('submit', event => {
          event.preventDefault();
          const value = input.value.trim();
          if (!value) return;
          this.onAction(p.action, { text: value });
          input.value = '';
        });
        break;
      }
      case 'suggestion-list': {
        out = el('div', 'dream-suggestions');
        for (const item of (p.items ?? [])) {
          const button = el('button', 'dream-suggestion', item); button.type = 'button';
          button.addEventListener('click', () => this.onAction('apollo.submit', { text: item }));
          out.append(button);
        }
        break;
      }
      case 'tabs': {
        out = el('nav', 'dream-tabs');
        for (const item of (p.items ?? [])) {
          const button = el('button', `dream-tab ${item.id === p.active ? 'active' : ''}`, item.label);
          button.type = 'button'; button.addEventListener('click', () => this.onAction(item.action)); out.append(button);
        }
        break;
      }
      case 'status-line': out = el('p', 'dream-muted', p.text ?? ''); break;
      case 'feature-list':
      case 'book-shelf':
      case 'magazine-feed':
      case 'reader-content': out = el('section', 'dream-column'); break;
      default: throw new DreamRenderError(`Unsupported component: ${spec.type}`);
    }
    if (spec.children && spec.type !== 'fluid-orb') {
      for (const child of spec.children) out.append(this.#renderNode(child));
    }
    return out;
  }

  #renderOrb(props) {
    const wrap = el('div', `dream-orb ${this.animations ? 'motion' : ''}`);
    wrap.setAttribute('role', 'img');
    wrap.setAttribute('aria-label', 'Apollo fluid intelligence presence');
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', '0 0 240 240');
    svg.setAttribute('aria-hidden', 'true');
    const defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
    const colors = ['#D957A7', '#EF7666', '#4ECBDD', '#8E7AD4'];
    colors.forEach((color, index) => {
      const gradient = document.createElementNS('http://www.w3.org/2000/svg', 'linearGradient');
      gradient.id = `apollo-ribbon-${index}`; gradient.setAttribute('x1', '0%'); gradient.setAttribute('y1', '0%'); gradient.setAttribute('x2', '100%'); gradient.setAttribute('y2', '100%');
      const a = document.createElementNS('http://www.w3.org/2000/svg', 'stop'); a.setAttribute('offset', '0%'); a.setAttribute('stop-color', color); a.setAttribute('stop-opacity', '.12');
      const b = document.createElementNS('http://www.w3.org/2000/svg', 'stop'); b.setAttribute('offset', '48%'); b.setAttribute('stop-color', color); b.setAttribute('stop-opacity', '.72');
      const c = document.createElementNS('http://www.w3.org/2000/svg', 'stop'); c.setAttribute('offset', '100%'); c.setAttribute('stop-color', colors[(index + 1) % colors.length]); c.setAttribute('stop-opacity', '.18');
      gradient.append(a, b, c); defs.append(gradient);
    });
    const coreGradient = document.createElementNS('http://www.w3.org/2000/svg', 'radialGradient');
    coreGradient.id = 'apollo-orb-core';
    coreGradient.setAttribute('cx', '37%'); coreGradient.setAttribute('cy', '30%'); coreGradient.setAttribute('r', '75%');
    const coreStops = [
      ['0%', '#27354D', '.98'], ['56%', '#101D34', '.99'], ['100%', '#071426', '.96']
    ];
    for (const [offset, color, opacity] of coreStops) {
      const stop = document.createElementNS('http://www.w3.org/2000/svg', 'stop');
      stop.setAttribute('offset', offset); stop.setAttribute('stop-color', color); stop.setAttribute('stop-opacity', opacity); coreGradient.append(stop);
    }
    defs.append(coreGradient);
    svg.append(defs);
    const core = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    core.setAttribute('cx', '120'); core.setAttribute('cy', '120'); core.setAttribute('r', '72');
    core.setAttribute('fill', 'url(#apollo-orb-core)'); core.setAttribute('stroke', '#9bb2c9'); core.setAttribute('stroke-opacity', '.18');
    svg.append(core);
    const generated = createFluidOrbSpec(props.seed ?? 'apollo-fluid-identity', props.quality ?? 'balanced');
    const layers = generated.layers;
    layers.forEach((layer, index) => {
      const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      path.setAttribute('d', layer.path);
      path.setAttribute('fill', 'none');
      path.setAttribute('stroke', `url(#apollo-ribbon-${index % 4})`);
      path.setAttribute('stroke-opacity', String(Math.min(.96, layer.opacity)));
      path.setAttribute('fill-opacity', '.04');
      path.setAttribute('stroke-linecap', 'round');
      path.setAttribute('stroke-linejoin', 'round');
      path.setAttribute('stroke-width', String(layer.width));
      path.setAttribute('class', 'ribbon');
      path.style.animationDelay = `${layer.delay}s`;
      path.style.transform = `rotate(${layer.rotation}deg)`;
      svg.append(path);
    });
    wrap.append(svg);
    return wrap;
  }
}
