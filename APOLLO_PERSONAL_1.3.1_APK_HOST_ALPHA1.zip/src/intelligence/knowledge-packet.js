import { sha256Hex } from './digest.js';
import { SeedValidationError } from './errors.js';

const CLAIM_KINDS = new Set(['fact', 'inference', 'hypothesis', 'definition', 'unknown']);
const ID = /^[a-zA-Z][a-zA-Z0-9._:-]{0,79}$/;
const MAX_CLAIMS = 500;
const MAX_CLAIM_TEXT = 12000;
const MAX_REFS = 24;

function assertString(value, path, max = 500) {
  if (typeof value !== 'string' || !value.trim() || value.length > max) {
    throw new SeedValidationError('Expected a non-empty bounded string', path);
  }
}

export function validateKnowledgePacket(packet) {
  if (!packet || typeof packet !== 'object' || Array.isArray(packet)) {
    throw new SeedValidationError('Knowledge packet must be an object');
  }
  if (packet.format !== 'APOLLO_KNOWLEDGE_PACKET' || packet.schemaVersion !== 1) {
    throw new SeedValidationError('Unsupported knowledge packet format or version');
  }
  assertString(packet.title, '$.title', 240);
  if (!Array.isArray(packet.claims) || packet.claims.length > MAX_CLAIMS) {
    throw new SeedValidationError(`claims must be an array of at most ${MAX_CLAIMS}`, '$.claims');
  }
  if (packet.metadata !== undefined) {
    if (!packet.metadata || typeof packet.metadata !== 'object' || Array.isArray(packet.metadata)) {
      throw new SeedValidationError('metadata must be an object', '$.metadata');
    }
    const metadataKeys = Object.keys(packet.metadata);
    if (metadataKeys.some(key => !['collection', 'revision', 'language', 'createdBy'].includes(key))) {
      throw new SeedValidationError('metadata contains an unapproved property', '$.metadata');
    }
    for (const [key, value] of Object.entries(packet.metadata)) {
      if (typeof value !== 'string' || value.length > 160) throw new SeedValidationError('metadata values must be bounded strings', `$.metadata.${key}`);
    }
  }
  const ids = new Set();
  for (let i = 0; i < packet.claims.length; i++) {
    const claim = packet.claims[i];
    const path = `$.claims[${i}]`;
    if (!claim || typeof claim !== 'object' || Array.isArray(claim)) {
      throw new SeedValidationError('Claim must be an object', path);
    }
    const allowedClaimKeys = new Set(['id', 'text', 'kind', 'sourceRefs', 'confidence', 'priority', 'topic', 'caveat']);
    if (Object.keys(claim).some(key => !allowedClaimKeys.has(key))) throw new SeedValidationError('Claim contains an unapproved property', path);
    if (typeof claim.id !== 'string' || !ID.test(claim.id) || ids.has(claim.id)) {
      throw new SeedValidationError('Claim id is invalid or duplicated', `${path}.id`);
    }
    ids.add(claim.id);
    assertString(claim.text, `${path}.text`, MAX_CLAIM_TEXT);
    if (!CLAIM_KINDS.has(claim.kind)) throw new SeedValidationError('Unknown claim kind', `${path}.kind`);
    if (!Array.isArray(claim.sourceRefs) || claim.sourceRefs.length > MAX_REFS) {
      throw new SeedValidationError(`sourceRefs must contain at most ${MAX_REFS} references`, `${path}.sourceRefs`);
    }
    claim.sourceRefs.forEach((ref, j) => assertString(ref, `${path}.sourceRefs[${j}]`, 500));
    if (claim.confidence !== undefined && (!Number.isFinite(claim.confidence) || claim.confidence < 0 || claim.confidence > 1)) {
      throw new SeedValidationError('confidence must be between 0 and 1', `${path}.confidence`);
    }
    if (claim.priority !== undefined && (!Number.isFinite(claim.priority) || claim.priority < 0 || claim.priority > 100)) {
      throw new SeedValidationError('priority must be between 0 and 100', `${path}.priority`);
    }
    if (claim.topic !== undefined) assertString(claim.topic, `${path}.topic`, 100);
    if (claim.caveat !== undefined && (typeof claim.caveat !== 'string' || claim.caveat.length > 2000)) {
      throw new SeedValidationError('caveat must be a bounded string', `${path}.caveat`);
    }
  }
  return Object.freeze({ claimCount: packet.claims.length });
}

export async function createKnowledgePacket({ title, claims, metadata = {} }) {
  const packet = {
    format: 'APOLLO_KNOWLEDGE_PACKET',
    schemaVersion: 1,
    title,
    claims: (claims ?? []).map(claim => ({
      id: claim.id,
      text: claim.text,
      kind: claim.kind ?? 'fact',
      sourceRefs: [...(claim.sourceRefs ?? [])],
      ...(claim.confidence !== undefined ? { confidence: claim.confidence } : {}),
      ...(claim.priority !== undefined ? { priority: claim.priority } : {}),
      ...(claim.topic ? { topic: claim.topic } : {}),
      ...(claim.caveat ? { caveat: claim.caveat } : {})
    })),
    metadata: structuredClone(metadata)
  };
  validateKnowledgePacket(packet);
  const digest = await sha256Hex(packet);
  return Object.freeze({ packet, reference: `sha256:${digest}`, digest });
}
