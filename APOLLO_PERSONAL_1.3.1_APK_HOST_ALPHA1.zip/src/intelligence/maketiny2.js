import { estimateUtf8Bytes } from '../cache/canonical.js';
import { createGenerationSeed } from '../core/seed.js';
import { sha256Hex } from './digest.js';
import { SeedValidationError, StrategyError } from './errors.js';

const FORMAT = 'MAKETINY_PARENT_SEED';
const CHILD_FORMAT = 'MAKETINY_CHILD_SEED';
const VERSION = 2;
const REF = /^sha256:[a-f0-9]{64}$/;
const ID = /^[a-z][a-z0-9_]{2,47}$/;
const ROLE = /^[a-z][a-z0-9_-]{1,47}$/;
const MAX_OBJECTIVE = 2000;
const MAX_CAPABILITIES = 16;
const MAX_SECTIONS = 64;
const MAX_DEPTH_HARD = 4;
const MAX_CHILDREN_HARD = 128;
const MAX_TREE_NODES_HARD = 512;
const MAX_SEED_BYTES_HARD = 64 * 1024;

function assertPlainObject(value, path) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new SeedValidationError('Expected an object', path);
  }
}

function assertString(value, path, max = 160) {
  if (typeof value !== 'string' || !value.trim() || value.length > max) {
    throw new SeedValidationError('Expected a non-empty bounded string', path);
  }
}

function assertStringArray(value, path, maxItems, maxLength = 80) {
  if (!Array.isArray(value) || value.length > maxItems || value.some(item => typeof item !== 'string' || !item.trim() || item.length > maxLength)) {
    throw new SeedValidationError(`Expected an array of at most ${maxItems} bounded strings`, path);
  }
  if (new Set(value).size !== value.length) throw new SeedValidationError('Duplicate values are not allowed', path);
}

function freezeDeep(value) {
  if (!value || typeof value !== 'object' || Object.isFrozen(value)) return value;
  Object.freeze(value);
  for (const item of Object.values(value)) freezeDeep(item);
  return value;
}

function childRole(role) {
  if (typeof role !== 'string' || !ROLE.test(role)) throw new SeedValidationError('Invalid child role', '$.role');
  return role;
}

/**
 * Trusted recipe registry. Seeds select recipes by ID; they never carry code.
 * Recipe handlers are application code and must be reviewed/versioned with the app.
 */
export class MakeTinyRecipeRegistry {
  constructor() {
    this.recipes = new Map();
    this.register({
      id: 'apollo_dream_v1', version: 1,
      validate(parameters) {
        assertPlainObject(parameters, '$.parameters');
        const allowed = new Set(['taskType', 'objective', 'editorialStyle', 'capabilities', 'sections', 'contextRefs', 'voiceEnabled', 'visualEnabled']);
        if (Object.keys(parameters).some(key => !allowed.has(key))) throw new SeedValidationError('Unapproved Apollo dream parameter', '$.parameters');
        assertString(parameters.taskType, '$.parameters.taskType', 32);
        assertString(parameters.objective, '$.parameters.objective', MAX_OBJECTIVE);
        if (!['editorial', 'balanced', 'concise'].includes(parameters.editorialStyle)) throw new SeedValidationError('Unsupported editorial style', '$.parameters.editorialStyle');
        assertStringArray(parameters.capabilities ?? [], '$.parameters.capabilities', MAX_CAPABILITIES, 48);
        assertStringArray(parameters.sections ?? [], '$.parameters.sections', MAX_SECTIONS, 100);
        if (!Array.isArray(parameters.contextRefs ?? []) || (parameters.contextRefs ?? []).length > 16 || (parameters.contextRefs ?? []).some(ref => !REF.test(ref))) {
          throw new SeedValidationError('Invalid content-addressed context references', '$.parameters.contextRefs');
        }
        if (typeof (parameters.voiceEnabled ?? false) !== 'boolean' || typeof (parameters.visualEnabled ?? false) !== 'boolean') {
          throw new SeedValidationError('Feature flags must be boolean', '$.parameters');
        }
      },
      childCount(parameters) { return 3 + Number(Boolean(parameters.voiceEnabled)) + Number(Boolean(parameters.visualEnabled)); },
      childAt(parameters, index) {
        const descriptors = [
          { role: 'knowledge_plan', recipeId: 'knowledge_plan_v1', parameters: { capabilities: [...(parameters.capabilities ?? [])] } },
          { role: 'moe_plan', recipeId: 'moe_capability_batch_v1', parameters: { capabilities: [...(parameters.capabilities ?? [])] } },
          { role: 'editorial_plan', recipeId: 'editorial_sections_v1', parameters: { style: parameters.editorialStyle, sections: [...(parameters.sections ?? [])] } }
        ];
        if (parameters.voiceEnabled) descriptors.push({ role: 'voice_plan', recipeId: 'voice_segment_plan_v1', parameters: { voiceProfile: 'pocket_tts_adaptive' } });
        if (parameters.visualEnabled) descriptors.push({ role: 'visual_plan', recipeId: 'visual_asset_plan_v1', parameters: { visualProfile: 'procedural_first' } });
        return descriptors[index];
      },
      expand(parameters) { return Array.from({ length: this.childCount(parameters) }, (_, index) => this.childAt(parameters, index)); }
    });

    this.register({
      id: 'knowledge_plan_v1', version: 1,
      validate(parameters) {
        assertPlainObject(parameters, '$.parameters');
        assertStringArray(parameters.capabilities ?? [], '$.parameters.capabilities', MAX_CAPABILITIES, 48);
      },
      childCount(parameters) { return parameters.capabilities.length || 2; },
      childAt(parameters, index) {
        const topics = parameters.capabilities.length ? parameters.capabilities : ['primary_topic', 'supporting_context'];
        const topic = topics[index];
        if (topic === undefined) return undefined;
        return { role: `knowledge_query_${index + 1}`, recipeId: 'atomic_task_v1', parameters: { taskType: 'knowledge_query', topic } };
      },
      expand(parameters) { return Array.from({ length: this.childCount(parameters) }, (_, index) => this.childAt(parameters, index)); }
    });

    this.register({
      id: 'moe_capability_batch_v1', version: 1,
      validate(parameters) {
        assertPlainObject(parameters, '$.parameters');
        assertStringArray(parameters.capabilities ?? [], '$.parameters.capabilities', MAX_CAPABILITIES, 48);
      },
      childCount(parameters) { return parameters.capabilities.length; },
      childAt(parameters, index) {
        const capability = parameters.capabilities[index];
        if (capability === undefined) return undefined;
        return { role: `moe_capability_${index + 1}`, recipeId: 'atomic_task_v1', parameters: { taskType: 'moe_capability_request', capability } };
      },
      expand(parameters) { return Array.from({ length: this.childCount(parameters) }, (_, index) => this.childAt(parameters, index)); }
    });

    this.register({
      id: 'editorial_sections_v1', version: 1,
      validate(parameters) {
        assertPlainObject(parameters, '$.parameters');
        if (!['editorial', 'balanced', 'concise'].includes(parameters.style)) throw new SeedValidationError('Unsupported editorial style', '$.parameters.style');
        assertStringArray(parameters.sections, '$.parameters.sections', MAX_SECTIONS, 100);
      },
      childCount(parameters) { return parameters.sections.length; },
      childAt(parameters, index) {
        const section = parameters.sections[index];
        if (section === undefined) return undefined;
        return { role: `editorial_section_${index + 1}`, recipeId: 'atomic_task_v1', parameters: { taskType: 'editorial_section', section, style: parameters.style } };
      },
      expand(parameters) { return Array.from({ length: this.childCount(parameters) }, (_, index) => this.childAt(parameters, index)); }
    });

    this.register({
      id: 'voice_segment_plan_v1', version: 1,
      validate(parameters) {
        assertPlainObject(parameters, '$.parameters');
        if (parameters.voiceProfile !== 'pocket_tts_adaptive') throw new SeedValidationError('Unsupported voice profile', '$.parameters.voiceProfile');
      },
      expand(parameters) {
        return [{ role: 'voice_render_plan', recipeId: 'atomic_task_v1', parameters: { taskType: 'voice_render_plan', voiceProfile: parameters.voiceProfile } }];
      }
    });

    this.register({
      id: 'visual_asset_plan_v1', version: 1,
      validate(parameters) {
        assertPlainObject(parameters, '$.parameters');
        if (parameters.visualProfile !== 'procedural_first') throw new SeedValidationError('Unsupported visual profile', '$.parameters.visualProfile');
      },
      childCount() { return 1; },
      childAt(parameters, index) { return index === 0 ? { role: 'visual_generation_plan', recipeId: 'atomic_task_v1', parameters: { taskType: 'visual_generation_plan', visualProfile: parameters.visualProfile } } : undefined; },
      expand(parameters) { return [this.childAt(parameters, 0)]; }
    });

    this.register({
      id: 'atomic_task_v1', version: 1,
      validate(parameters) {
        assertPlainObject(parameters, '$.parameters');
        const allowed = new Set(['taskType', 'topic', 'capability', 'section', 'style', 'objective', 'voiceProfile', 'visualProfile', 'contextRefs']);
        if (Object.keys(parameters).some(key => !allowed.has(key))) throw new SeedValidationError('Unapproved atomic-task parameter', '$.parameters');
        assertString(parameters.taskType, '$.parameters.taskType', 48);
        if (parameters.objective !== undefined) assertString(parameters.objective, '$.parameters.objective', MAX_OBJECTIVE);
        for (const key of ['topic', 'capability', 'section', 'style', 'voiceProfile', 'visualProfile']) if (parameters[key] !== undefined) assertString(parameters[key], `$.parameters.${key}`, 100);
        validateRefs(parameters.contextRefs ?? []);
      },
      childCount() { return 0; },
      childAt() { return undefined; },
      expand() { return []; }
    });
  }

  register(recipe) {
    if (!recipe || typeof recipe.id !== 'string' || !ID.test(recipe.id) || !Number.isInteger(recipe.version) || recipe.version < 1 || typeof recipe.validate !== 'function' || typeof recipe.expand !== 'function') {
      throw new StrategyError('Invalid MakeTiny recipe registration');
    }
    if (this.recipes.has(recipe.id)) throw new StrategyError(`Duplicate MakeTiny recipe: ${recipe.id}`);
    this.recipes.set(recipe.id, Object.freeze({ ...recipe }));
  }

  get(id) {
    const recipe = this.recipes.get(id);
    if (!recipe) throw new StrategyError(`Unknown MakeTiny recipe: ${String(id)}`);
    return recipe;
  }

  list() { return Object.freeze([...this.recipes.values()].map(({ id, version }) => Object.freeze({ id, version }))); }

  countChildren(recipe, parameters, context) {
    const count = typeof recipe.childCount === 'function'
      ? recipe.childCount(structuredClone(parameters), context)
      : recipe.expand(structuredClone(parameters), context).length;
    if (!Number.isInteger(count) || count < 0 || count > MAX_CHILDREN_HARD) throw new SeedValidationError('Recipe child count is outside the permitted range');
    return count;
  }

  describeChild(recipe, parameters, index, context) {
    if (typeof recipe.childAt === 'function') return recipe.childAt(structuredClone(parameters), index, context);
    return recipe.expand(structuredClone(parameters), context)[index];
  }
}

function validateRefs(refs) {
  if (!Array.isArray(refs) || refs.length > 16 || refs.some(ref => !REF.test(ref)) || new Set(refs).size !== refs.length) throw new SeedValidationError('Invalid or duplicate context references', '$.parameters.contextRefs');
}

export class MakeTiny2Engine {
  constructor({ registry = new MakeTinyRecipeRegistry(), maxDepth = 4, maxChildren = 128, maxTreeNodes = 512, maxSeedBytes = 64 * 1024 } = {}) {
    this.registry = registry;
    this.maxDepth = Math.min(MAX_DEPTH_HARD, Math.max(1, maxDepth));
    this.maxChildren = Math.min(MAX_CHILDREN_HARD, Math.max(1, maxChildren));
    this.maxTreeNodes = Math.min(MAX_TREE_NODES_HARD, Math.max(1, maxTreeNodes));
    this.maxSeedBytes = Math.min(MAX_SEED_BYTES_HARD, Math.max(256, maxSeedBytes));
  }

  async createRoot({ recipeId = 'apollo_dream_v1', parameters, generationSeed = createGenerationSeed(), contextRefs = [], maxDepth = this.maxDepth, maxChildren = this.maxChildren } = {}) {
    const recipe = this.registry.get(recipeId);
    recipe.validate(parameters);
    const effectiveContextRefs = contextRefs.length ? contextRefs : (parameters.contextRefs ?? []);
    validateRefs(effectiveContextRefs);
    if (typeof generationSeed !== 'string' || !generationSeed.trim() || generationSeed.length > 128) throw new SeedValidationError('Invalid generation seed', '$.generationSeed');
    if (!Number.isInteger(maxDepth) || maxDepth < 1 || !Number.isInteger(maxChildren) || maxChildren < 1) throw new SeedValidationError('maxDepth and maxChildren must be positive integers');
    const normalizedDepth = Math.min(this.maxDepth, maxDepth);
    const normalizedChildren = Math.min(this.maxChildren, maxChildren);
    const payload = {
      format: FORMAT,
      schemaVersion: VERSION,
      engineVersion: '2.0.0',
      recipe: { id: recipe.id, version: recipe.version },
      role: 'root',
      parentSeedId: null,
      depth: 0,
      childIndex: null,
      generationSeed,
      parameters: structuredClone(parameters),
      contextRefs: [...new Set(effectiveContextRefs)].sort(),
      inheritedContextFromParent: false,
      limits: { maxDepth: normalizedDepth, maxChildren: normalizedChildren, maxTreeNodes: this.maxTreeNodes, maxSeedBytes: this.maxSeedBytes, executablePayloads: false, networkAccess: false }
    };
    const seed = await this.#seal(payload);
    return Object.freeze({ seed, bytes: estimateUtf8Bytes(seed), digest: seed.seedId });
  }

  async validate(seed) {
    assertPlainObject(seed, '$seed');
    const keys = new Set(['format', 'schemaVersion', 'engineVersion', 'recipe', 'role', 'parentSeedId', 'depth', 'childIndex', 'generationSeed', 'parameters', 'contextRefs', 'inheritedContextFromParent', 'limits', 'seedId']);
    if (Object.keys(seed).some(key => !keys.has(key))) throw new SeedValidationError('Unknown MakeTiny seed field');
    if (seed.format !== FORMAT || seed.schemaVersion !== VERSION || seed.engineVersion !== '2.0.0') throw new SeedValidationError('Unsupported MakeTiny seed format/version');
    if (!seed.recipe || typeof seed.recipe !== 'object' || Array.isArray(seed.recipe) || Object.keys(seed.recipe).some(key => !['id', 'version'].includes(key)) || !ID.test(seed.recipe.id) || !Number.isInteger(seed.recipe.version)) throw new SeedValidationError('Invalid recipe descriptor', '$.recipe');
    const recipe = this.registry.get(seed.recipe.id);
    if (recipe.version !== seed.recipe.version) throw new StrategyError('MakeTiny recipe version mismatch');
    recipe.validate(seed.parameters);
    childRole(seed.role);
    if (!Number.isInteger(seed.depth) || seed.depth < 0 || seed.depth > this.maxDepth) throw new SeedValidationError('Invalid seed depth', '$.depth');
    if (seed.depth === 0 && (seed.parentSeedId !== null || seed.role !== 'root' || seed.childIndex !== null)) throw new SeedValidationError('Invalid root seed linkage', '$.parentSeedId');
    if (seed.depth > 0 && (typeof seed.parentSeedId !== 'string' || !/^[a-f0-9]{64}$/.test(seed.parentSeedId) || !Number.isInteger(seed.childIndex) || seed.childIndex < 0 || seed.childIndex >= this.maxChildren)) throw new SeedValidationError('Invalid child seed linkage', '$.parentSeedId');
    if (typeof seed.generationSeed !== 'string' || !seed.generationSeed || seed.generationSeed.length > 128) throw new SeedValidationError('Invalid generation state', '$.generationSeed');
    validateRefs(seed.contextRefs);
    if (typeof seed.inheritedContextFromParent !== 'boolean' || (seed.depth === 0 && seed.inheritedContextFromParent) || (seed.depth > 0 && !seed.inheritedContextFromParent)) throw new SeedValidationError('Invalid context inheritance descriptor', '$.inheritedContextFromParent');
    assertPlainObject(seed.limits, '$.limits');
    if (Object.keys(seed.limits).some(key => !['maxDepth', 'maxChildren', 'maxTreeNodes', 'maxSeedBytes', 'executablePayloads', 'networkAccess'].includes(key)) || seed.limits.executablePayloads !== false || seed.limits.networkAccess !== false || !Number.isInteger(seed.limits.maxDepth) || seed.limits.maxDepth < 1 || seed.limits.maxDepth > this.maxDepth || seed.depth > seed.limits.maxDepth || !Number.isInteger(seed.limits.maxChildren) || seed.limits.maxChildren < 1 || seed.limits.maxChildren > this.maxChildren || !Number.isInteger(seed.limits.maxSeedBytes) || seed.limits.maxSeedBytes < 256 || seed.limits.maxSeedBytes > this.maxSeedBytes || !Number.isInteger(seed.limits.maxTreeNodes) || seed.limits.maxTreeNodes < 1 || seed.limits.maxTreeNodes > this.maxTreeNodes) throw new SeedValidationError('Unsafe or invalid resource limits', '$.limits');
    const { seedId, ...payload } = seed;
    const actual = await sha256Hex(payload);
    if (actual !== seedId) throw new SeedValidationError('MakeTiny seed digest mismatch', '$.seedId');
    const byteSize = estimateUtf8Bytes(seed);
    if (byteSize > Math.min(this.maxSeedBytes, seed.limits.maxSeedBytes)) throw new SeedValidationError('MakeTiny seed exceeds byte budget');
    return Object.freeze({ valid: true, seedId, bytes: byteSize, recipeId: recipe.id, depth: seed.depth });
  }

  async countChildren(seed) {
    await this.validate(seed);
    if (seed.depth >= seed.limits.maxDepth) return 0;
    const recipe = this.registry.get(seed.recipe.id);
    const count = this.registry.countChildren(recipe, seed.parameters, {
      generationSeed: seed.generationSeed,
      depth: seed.depth,
      contextRefs: [...seed.contextRefs]
    });
    if (count > seed.limits.maxChildren) throw new SeedValidationError('Recipe emitted too many child seeds');
    return count;
  }

  async deriveChild(seed, index) {
    await this.validate(seed);
    if (!Number.isInteger(index) || index < 0) throw new RangeError('Child index must be a non-negative integer');
    if (seed.depth >= seed.limits.maxDepth) throw new RangeError('Maximum seed depth reached');
    const recipe = this.registry.get(seed.recipe.id);
    const context = { generationSeed: seed.generationSeed, depth: seed.depth, contextRefs: [...seed.contextRefs] };
    const count = this.registry.countChildren(recipe, seed.parameters, context);
    if (index >= count) throw new RangeError(`Child index ${index} is outside ${count} available children`);
    const descriptor = this.registry.describeChild(recipe, seed.parameters, index, context);
    if (!descriptor || typeof descriptor !== 'object' || Array.isArray(descriptor) || Object.keys(descriptor).some(key => !['role', 'recipeId', 'parameters'].includes(key))) {
      throw new SeedValidationError('Recipe emitted an invalid child descriptor');
    }
    const role = childRole(descriptor.role);
    const childRecipe = this.registry.get(descriptor.recipeId);
    childRecipe.validate(descriptor.parameters);
    const childGenerationSeed = await sha256Hex(`${seed.generationSeed}:${seed.seedId}:${index}:${role}`);
    const payload = {
      format: FORMAT,
      schemaVersion: VERSION,
      engineVersion: seed.engineVersion,
      recipe: { id: childRecipe.id, version: childRecipe.version },
      role,
      parentSeedId: seed.seedId,
      depth: seed.depth + 1,
      childIndex: index,
      generationSeed: childGenerationSeed,
      parameters: structuredClone(descriptor.parameters),
      contextRefs: [...seed.contextRefs],
      inheritedContextFromParent: true,
      limits: structuredClone(seed.limits)
    };
    return this.#seal(payload);
  }

  async expand(seed, { offset = 0, limit = this.maxChildren } = {}) {
    await this.validate(seed);
    if (!Number.isInteger(offset) || offset < 0 || !Number.isInteger(limit) || limit < 1) throw new RangeError('offset and limit must be non-negative/positive integers');
    if (seed.depth >= seed.limits.maxDepth) return Object.freeze({ parentSeedId: seed.seedId, children: Object.freeze([]), truncated: true, reason: 'maximum_depth' });
    const totalChildren = await this.countChildren(seed);
    const start = Math.max(0, Math.min(totalChildren, offset));
    const end = Math.max(start, Math.min(totalChildren, start + Math.min(limit, seed.limits.maxChildren)));
    const children = [];
    for (let index = start; index < end; index++) children.push(await this.deriveChild(seed, index));
    return Object.freeze({ parentSeedId: seed.seedId, children: Object.freeze(children), totalChildren, truncated: end < totalChildren, offset: start });
  }

  async expandTree(rootSeed, { maxDepth = rootSeed?.limits?.maxDepth ?? this.maxDepth, maxNodes = this.maxTreeNodes } = {}) {
    await this.validate(rootSeed);
    if (!Number.isInteger(maxDepth) || maxDepth < 0 || !Number.isInteger(maxNodes) || maxNodes < 1) throw new RangeError('maxDepth and maxNodes must be valid integers');
    const depthLimit = Math.min(this.maxDepth, maxDepth);
    const nodeLimit = Math.min(this.maxTreeNodes, maxNodes);
    const nodes = [];
    const queue = [rootSeed];
    let truncated = false;
    while (queue.length && nodes.length < nodeLimit) {
      const current = queue.shift();
      nodes.push(current);
      if (current.depth >= depthLimit) continue;
      const remaining = nodeLimit - nodes.length;
      if (remaining <= 0) break;
      const expanded = await this.expand(current, { limit: Math.min(current.limits.maxChildren, remaining) });
      if (expanded.truncated) truncated = true;
      queue.push(...expanded.children);
    }
    return Object.freeze({ rootSeedId: rootSeed.seedId, nodes: Object.freeze(nodes), nodeCount: nodes.length, truncated: truncated || queue.length > 0, maxDepth: depthLimit });
  }

  async footprint(rootSeed, generatedChildren = []) {
    await this.validate(rootSeed);
    for (const child of generatedChildren) await this.validate(child);
    const rootBytes = estimateUtf8Bytes(rootSeed);
    const childBytes = generatedChildren.reduce((sum, child) => sum + estimateUtf8Bytes(child), 0);
    return Object.freeze({
      rootSeedBytes: rootBytes,
      generatedChildSeedBytes: childBytes,
      generatedChildCount: generatedChildren.length,
      expansionFactor: rootBytes === 0 ? 0 : Number((childBytes / rootBytes).toFixed(3)),
      persistedBytesIfChildrenAreRegeneratedOnDemand: rootBytes,
      persistedBytesIfAllChildrenAreStored: rootBytes + childBytes,
      note: 'Regenerated child bytes are transient output, not compressed original data. Saving storage requires keeping the parent seed and regenerating children on demand.'
    });
  }

  async #seal(payload) {
    const seedId = await sha256Hex(payload);
    const seed = freezeDeep({ ...payload, seedId });
    const bytes = estimateUtf8Bytes(seed);
    if (bytes > this.maxSeedBytes) throw new SeedValidationError('Generated seed exceeds byte budget');
    return seed;
  }
}

/**
 * Compact nested-seed fixture. A 40-byte parent recipe expands into a 118-byte
 * child descriptor for a deterministic quadratic int64 stream. This fixture
 * demonstrates seed->seed->data generation for a known structured family only.
 */
const QUADRATIC_PARENT_MAGIC = new TextEncoder().encode('MT2P');
const QUADRATIC_CHILD_MAGIC = new TextEncoder().encode('MT2C');
const QUADRATIC_PARENT_BYTES = 44;
const QUADRATIC_CHILD_BYTES = 118;
const RECURRENCE_RECIPE_ID = 1;
const encoder = new TextEncoder();

function crc32(bytes) {
  let crc = 0xffffffff;
  for (const byte of bytes) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit++) crc = (crc >>> 1) ^ (0xedb88320 & -(crc & 1));
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function writeU64LE(view, offset, value) {
  const n = BigInt(value);
  if (n < 0n || n > 0xffffffffffffffffn) throw new RangeError('Unsigned 64-bit field out of range');
  view.setBigUint64(offset, n, true);
}
function readU64LE(view, offset) { return view.getBigUint64(offset, true); }

export function createQuadraticMetaSeed({ count = 131072n, initial = 7n, firstDifference = 3n, secondDifference = 1n } = {}) {
  const values = [count, initial, firstDifference, secondDifference].map(BigInt);
  if (values[0] < 1n || values[0] > 100000000n) throw new RangeError('count must be between 1 and 100,000,000');
  for (const value of values.slice(1)) if (value < 0n || value > 0x7fffffffffffffffn) throw new RangeError('Recurrence parameter outside supported signed int64 range');
  const bytes = new Uint8Array(QUADRATIC_PARENT_BYTES);
  bytes.set(QUADRATIC_PARENT_MAGIC, 0);
  const view = new DataView(bytes.buffer);
  view.setUint8(4, 2);
  view.setUint8(5, RECURRENCE_RECIPE_ID);
  view.setUint16(6, QUADRATIC_CHILD_BYTES, true);
  writeU64LE(view, 8, values[0]);
  writeU64LE(view, 16, values[1]);
  writeU64LE(view, 24, values[2]);
  writeU64LE(view, 32, values[3]);
  view.setUint32(40, crc32(bytes.subarray(0, 40)), true);
  return bytes;
}

export async function expandQuadraticMetaSeed(parentBytes) {
  const parent = parentBytes instanceof Uint8Array ? parentBytes : new Uint8Array(parentBytes);
  if (parent.byteLength !== QUADRATIC_PARENT_BYTES || !QUADRATIC_PARENT_MAGIC.every((byte, index) => parent[index] === byte)) throw new SeedValidationError('Invalid quadratic parent seed');
  const pv = new DataView(parent.buffer, parent.byteOffset, parent.byteLength);
  if (pv.getUint8(4) !== 2 || pv.getUint8(5) !== RECURRENCE_RECIPE_ID || pv.getUint16(6, true) !== QUADRATIC_CHILD_BYTES) throw new SeedValidationError('Unsupported quadratic parent seed recipe');
  if (pv.getUint32(40, true) !== crc32(parent.subarray(0, 40))) throw new SeedValidationError('Quadratic parent seed checksum mismatch');
  const count = readU64LE(pv, 8);
  const initial = readU64LE(pv, 16);
  const firstDifference = readU64LE(pv, 24);
  const secondDifference = readU64LE(pv, 32);
  if (count < 1n || count > 100000000n) throw new SeedValidationError('Quadratic child count exceeds limit');
  const child = new Uint8Array(QUADRATIC_CHILD_BYTES);
  child.set(QUADRATIC_CHILD_MAGIC, 0);
  const cv = new DataView(child.buffer);
  cv.setUint8(4, 2);
  cv.setUint8(5, RECURRENCE_RECIPE_ID);
  cv.setUint8(6, 8); // int64 elements
  cv.setUint8(7, 1); // little-endian
  writeU64LE(cv, 8, count);
  writeU64LE(cv, 16, initial);
  writeU64LE(cv, 24, firstDifference);
  writeU64LE(cv, 32, secondDifference);
  writeU64LE(cv, 40, count * 8n);
  const generatorFingerprint = await sha256Hex('MAKETINY2:quadratic-int64-le:v1:x[n]=x0+n*d1+n*(n-1)/2*d2');
  const digestBytes = Uint8Array.from(generatorFingerprint.match(/.{2}/g), item => Number.parseInt(item, 16));
  child.set(digestBytes, 48);
  const metadata = encoder.encode('APOLLO_MAKETINY2_REPRODUCTIVE_SEED');
  child.set(encoder.encode('APOLLO'), 80);
  const checksum = await sha256Hex(child.slice(0, 86));
  const checksumBytes = Uint8Array.from(checksum.match(/.{2}/g), item => Number.parseInt(item, 16));
  child.set(checksumBytes, 86);
  return child;
}

export async function inspectQuadraticChildSeed(childBytes) {
  const child = childBytes instanceof Uint8Array ? childBytes : new Uint8Array(childBytes);
  if (child.byteLength !== QUADRATIC_CHILD_BYTES || !QUADRATIC_CHILD_MAGIC.every((byte, index) => child[index] === byte)) throw new SeedValidationError('Invalid quadratic child seed');
  const view = new DataView(child.buffer, child.byteOffset, child.byteLength);
  if (view.getUint8(4) !== 2 || view.getUint8(5) !== RECURRENCE_RECIPE_ID || view.getUint8(6) !== 8 || view.getUint8(7) !== 1) throw new SeedValidationError('Unsupported quadratic child seed');
  const actualChecksum = await sha256Hex(child.slice(0, 86));
  const expectedChecksum = [...child.slice(86, 118)].map(byte => byte.toString(16).padStart(2, '0')).join('');
  if (actualChecksum !== expectedChecksum) throw new SeedValidationError('Quadratic child seed checksum mismatch');
  const params = {
    count: readU64LE(view, 8),
    initial: readU64LE(view, 16),
    firstDifference: readU64LE(view, 24),
    secondDifference: readU64LE(view, 32),
    outputBytes: readU64LE(view, 40)
  };
  if (params.outputBytes !== params.count * 8n || params.count < 1n || params.count > 100000000n) throw new SeedValidationError('Invalid quadratic child output bounds');
  return Object.freeze(params);
}

export async function generateQuadraticChunk(childBytes, { startIndex = 0n, count = 1024 } = {}) {
  const params = await inspectQuadraticChildSeed(childBytes);
  const start = BigInt(startIndex);
  const length = BigInt(count);
  if (start < 0n || length < 0n || start + length > params.count || length > 1_000_000n) throw new RangeError('Quadratic chunk outside permitted bounds');
  const output = new Uint8Array(Number(length * 8n));
  const view = new DataView(output.buffer);
  for (let i = 0n; i < length; i++) {
    const n = start + i;
    const value = params.initial + n * params.firstDifference + (n * (n - 1n) / 2n) * params.secondDifference;
    if (value > 0x7fffffffffffffffn) throw new RangeError('Generated value exceeds signed int64 range');
    view.setBigInt64(Number(i * 8n), value, true);
  }
  return output;
}

export const MAKETINY2_FORMATS = Object.freeze({ parent: FORMAT, child: CHILD_FORMAT, version: VERSION, quadraticParentBytes: QUADRATIC_PARENT_BYTES, quadraticChildBytes: QUADRATIC_CHILD_BYTES });
