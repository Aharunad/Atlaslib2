import { StrategyRegistry } from './strategy-registry.js';
import { StrategyError } from './errors.js';

const SUPPORTED_TASKS = new Set(['conversation', 'explain', 'question', 'article', 'write', 'compare', 'study', 'teach']);

/**
 * Deterministic fallback planner. Later, Apollo's SLM may propose a plan,
 * but its proposal must still map to the same registered strategy IDs.
 */
export class ReasoningPlanner {
  constructor({ strategies = new StrategyRegistry() } = {}) {
    this.strategies = strategies;
  }

  plan({ taskType, requestedStrategy } = {}) {
    if (!SUPPORTED_TASKS.has(taskType)) throw new StrategyError(`Unsupported task type: ${String(taskType)}`);
    const strategy = requestedStrategy
      ? this.strategies.get(requestedStrategy)
      : this.strategies.findForTask(taskType);
    return Object.freeze({
      strategyId: strategy.id,
      strategyVersion: strategy.version,
      operators: strategy.operators,
      variants: strategy.variants.map(variant => variant.id),
      requiresModelDecision: false
    });
  }
}
