export class SeedValidationError extends Error {
  constructor(message, path = '$') {
    super(`${message} at ${path}`);
    this.name = 'SeedValidationError';
    this.path = path;
  }
}

export class MissingContextError extends Error {
  constructor(reference) {
    super(`Required content-addressed context is unavailable: ${reference}`);
    this.name = 'MissingContextError';
    this.reference = reference;
  }
}

export class StrategyError extends Error {
  constructor(message) {
    super(message);
    this.name = 'StrategyError';
  }
}
