import { canonicalBytes } from './digest.js';

export function validateResourceBounds(value, maxBytes) {
  const bytes = canonicalBytes(value);
  if (bytes > maxBytes) throw new RangeError(`Generated result exceeds ${maxBytes} byte output budget`);
  return Object.freeze({ bytes, withinBudget: true });
}
