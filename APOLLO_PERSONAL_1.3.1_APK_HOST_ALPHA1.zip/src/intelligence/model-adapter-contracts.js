import { validateKnowledgePacket } from './knowledge-packet.js';

/**
 * Contracts for future on-device model adapters. This module performs no model
 * inference; it validates the boundary so controller, MoE and editor runtimes
 * can be added without allowing a model to inject executable operations.
 */
const CAPABILITIES = new Set([
  'general_knowledge', 'scientific_reasoning', 'technical_explanation',
  'comparison', 'summarization', 'editorial_writing', 'mathematics',
  'language_translation', 'conversation_context'
]);

export function validateControllerPlan(plan) {
  if (!plan || typeof plan !== 'object' || Array.isArray(plan) || Object.keys(plan).some(key => !['needsMoE', 'capabilities', 'strategyId'].includes(key)) || typeof plan.needsMoE !== 'boolean' || !Array.isArray(plan.capabilities)) {
    throw new TypeError('Controller plan has an invalid shape');
  }
  if (plan.capabilities.length > 16 || plan.capabilities.some(item => !CAPABILITIES.has(item))) {
    throw new TypeError('Controller requested an unregistered capability');
  }
  if (plan.strategyId !== undefined && !/^[a-z][a-z0-9_]{2,39}$/.test(plan.strategyId)) {
    throw new TypeError('Controller requested an invalid strategy identifier');
  }
  return Object.freeze({
    needsMoE: plan.needsMoE,
    capabilities: Object.freeze([...new Set(plan.capabilities)].sort()),
    ...(plan.strategyId ? { strategyId: plan.strategyId } : {})
  });
}

export function validateMoEResponse(response) {
  if (!response || typeof response !== 'object' || Array.isArray(response) || Object.keys(response).some(key => !['knowledgePacket', 'toolRequests'].includes(key)) || !response.knowledgePacket) {
    throw new TypeError('MoE response has invalid shape or missing knowledge packet');
  }
  if (response.toolRequests !== undefined && (!Array.isArray(response.toolRequests) || response.toolRequests.length > 0)) {
    throw new TypeError('Model-generated tool execution is not enabled in this release');
  }
  validateKnowledgePacket(response.knowledgePacket);
  return Object.freeze({ knowledgePacket: response.knowledgePacket });
}

export function validateEditorialResponse(response, expectedClaimIds) {
  if (!response || typeof response !== 'object' || Array.isArray(response) || Object.keys(response).some(key => !['text', 'preservedClaimIds'].includes(key)) || typeof response.text !== 'string' || !Array.isArray(response.preservedClaimIds)) {
    throw new TypeError('Editorial response has an invalid shape');
  }
  const expected = [...expectedClaimIds].sort();
  const actual = [...new Set(response.preservedClaimIds)].sort();
  if (expected.length !== actual.length || expected.some((id, i) => id !== actual[i])) {
    throw new Error('Editorial response did not preserve the complete claim set');
  }
  return Object.freeze({ text: response.text, preservedClaimIds: Object.freeze(actual) });
}
