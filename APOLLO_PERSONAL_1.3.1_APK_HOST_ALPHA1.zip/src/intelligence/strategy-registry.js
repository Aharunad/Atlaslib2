import { StrategyError } from './errors.js';

const DEFINITIONS = [
  {
    id: 'explain_concept', version: 1, label: 'Explain a concept',
    taskTypes: ['explain', 'question'],
    variants: [
      { id: 'guided', sections: ['Overview', 'How it works', 'Important details', 'What remains uncertain'] },
      { id: 'editorial', sections: ['The central idea', 'A closer look', 'Why it matters', 'Limits and uncertainty'] }
    ],
    operators: ['normalize_request', 'rank_claims', 'assign_claims', 'compose_document', 'audit_claim_coverage']
  },
  {
    id: 'editorial_article', version: 1, label: 'Create an editorial article',
    taskTypes: ['article', 'write'],
    variants: [
      { id: 'narrative', sections: ['Introduction', 'Main discussion', 'Context', 'Conclusion'] },
      { id: 'analytical', sections: ['Summary', 'Analysis', 'Evidence and qualifications', 'Conclusion'] }
    ],
    operators: ['normalize_request', 'rank_claims', 'assign_claims', 'compose_document', 'audit_claim_coverage']
  },
  {
    id: 'compare_options', version: 1, label: 'Compare alternatives',
    taskTypes: ['compare'],
    variants: [
      { id: 'balanced', sections: ['Shared ground', 'Key differences', 'Trade-offs', 'Decision factors'] },
      { id: 'decision', sections: ['The options', 'Where each is stronger', 'Costs and limitations', 'Practical conclusion'] }
    ],
    operators: ['normalize_request', 'rank_claims', 'assign_claims', 'compose_document', 'audit_claim_coverage']
  },
  {
    id: 'study_guide', version: 1, label: 'Build a study guide',
    taskTypes: ['study', 'teach'],
    variants: [
      { id: 'learning_path', sections: ['Core ideas', 'Key terms', 'Connections', 'Review points'] },
      { id: 'revision', sections: ['What to understand', 'Essential details', 'Common confusions', 'Quick review'] }
    ],
    operators: ['normalize_request', 'rank_claims', 'assign_claims', 'compose_document', 'audit_claim_coverage']
  },
  {
    id: 'conversation_reply', version: 1, label: 'Compose a conversational answer',
    taskTypes: ['conversation'],
    variants: [
      { id: 'direct', sections: ['Answer', 'Context', 'Caveats'] },
      { id: 'warm', sections: ['The key point', 'A little more context', 'Important qualification'] }
    ],
    operators: ['normalize_request', 'rank_claims', 'assign_claims', 'compose_document', 'audit_claim_coverage']
  }
];

function cloneDefinition(definition) {
  return Object.freeze({
    ...definition,
    taskTypes: Object.freeze([...definition.taskTypes]),
    operators: Object.freeze([...definition.operators]),
    variants: Object.freeze(definition.variants.map(variant => Object.freeze({
      id: variant.id,
      sections: Object.freeze([...variant.sections])
    })))
  });
}

export class StrategyRegistry {
  constructor(definitions = DEFINITIONS) {
    this.definitions = new Map();
    for (const definition of definitions) this.register(definition);
  }

  register(definition) {
    if (!definition || typeof definition.id !== 'string' || !/^[a-z][a-z0-9_]{2,39}$/.test(definition.id)) {
      throw new StrategyError('Invalid strategy identifier');
    }
    if (this.definitions.has(definition.id)) throw new StrategyError(`Strategy already registered: ${definition.id}`);
    if (!Number.isInteger(definition.version) || definition.version < 1) throw new StrategyError('Strategy version must be a positive integer');
    if (typeof definition.label !== 'string' || definition.label.length > 80) throw new StrategyError('Strategy label must be a bounded string');
    if (!Array.isArray(definition.taskTypes) || definition.taskTypes.length < 1 || definition.taskTypes.length > 12 || definition.taskTypes.some(item => typeof item !== 'string' || item.length > 40)) throw new StrategyError('Strategy taskTypes are invalid');
    if (!Array.isArray(definition.operators) || definition.operators.length === 0 || definition.operators.length > 24 || definition.operators.some(item => typeof item !== 'string' || !/^[a-z][a-z0-9_]{2,39}$/.test(item))) throw new StrategyError('Strategy operators are invalid');
    if (!Array.isArray(definition.variants) || definition.variants.length === 0 || definition.variants.length > 8) throw new StrategyError('Strategy must declare 1–8 variants');
    const variantIds = new Set();
    for (const variant of definition.variants) {
      if (!variant || typeof variant.id !== 'string' || !/^[a-z][a-z0-9_]{1,39}$/.test(variant.id) || variantIds.has(variant.id)) throw new StrategyError('Strategy variant ID is invalid or duplicated');
      variantIds.add(variant.id);
      if (!Array.isArray(variant.sections) || variant.sections.length < 1 || variant.sections.length > 12 || variant.sections.some(section => typeof section !== 'string' || !section.trim() || section.length > 100)) throw new StrategyError('Strategy variant sections are invalid');
    }
    this.definitions.set(definition.id, cloneDefinition(definition));
  }

  get(id) {
    const definition = this.definitions.get(id);
    if (!definition) throw new StrategyError(`Unknown strategy: ${String(id)}`);
    return definition;
  }

  findForTask(taskType) {
    for (const definition of this.definitions.values()) {
      if (definition.taskTypes.includes(taskType)) return definition;
    }
    return this.get('conversation_reply');
  }

  list() { return Object.freeze([...this.definitions.values()]); }
}

export const DEFAULT_STRATEGIES = Object.freeze(DEFINITIONS.map(cloneDefinition));
