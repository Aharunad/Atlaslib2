import { sha256Hex, canonicalBytes } from './digest.js';
import { MissingContextError } from './errors.js';

/**
 * Content-addressed context store. Seeds hold references, not hidden copies of
 * the full knowledge payload. A production Android adapter can persist this
 * interface in encrypted app-private storage/Room/SQLite.
 */
export class ContentAddressedStore {
  constructor({ maxBytes = 16 * 1024 * 1024 } = {}) {
    if (!Number.isSafeInteger(maxBytes) || maxBytes <= 0) throw new RangeError('maxBytes must be positive');
    this.maxBytes = maxBytes;
    this.bytes = 0;
    this.entries = new Map();
  }

  async put(value) {
    const digest = await sha256Hex(value);
    const reference = `sha256:${digest}`;
    const size = canonicalBytes(value);
    const existing = this.entries.get(reference);
    if (existing) {
      await this.get(reference);
      return Object.freeze({ reference, digest, size: existing.size, inserted: false });
    }
    if (size > this.maxBytes) throw new RangeError('Content packet exceeds the store byte budget');
    if (this.bytes + size > this.maxBytes) throw new RangeError('Content-addressed store is full; evict or persist content before inserting');
    this.entries.set(reference, { value: structuredClone(value), size });
    this.bytes += size;
    return Object.freeze({ reference, digest, size, inserted: true });
  }

  async get(reference) {
    const entry = this.entries.get(reference);
    if (!entry) throw new MissingContextError(reference);
    const actual = `sha256:${await sha256Hex(entry.value)}`;
    if (actual !== reference) throw new Error(`Content integrity check failed for ${reference}`);
    return structuredClone(entry.value);
  }

  has(reference) { return this.entries.has(reference); }

  async exportSnapshot() {
    const entries = [...this.entries.entries()]
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([reference, entry]) => ({ reference, value: structuredClone(entry.value) }));
    return Object.freeze({
      format: 'APOLLO_CONTEXT_STORE',
      schemaVersion: 1,
      entries
    });
  }

  async restoreSnapshot(snapshot) {
    if (!snapshot || typeof snapshot !== 'object' || Array.isArray(snapshot)
      || Object.keys(snapshot).some(key => !['format', 'schemaVersion', 'entries'].includes(key))
      || snapshot.format !== 'APOLLO_CONTEXT_STORE' || snapshot.schemaVersion !== 1
      || !Array.isArray(snapshot.entries) || snapshot.entries.length > 10000) {
      throw new TypeError('Invalid content-store snapshot');
    }

    const staged = new Map();
    let stagedBytes = 0;
    for (const [index, item] of snapshot.entries.entries()) {
      if (!item || typeof item !== 'object' || Array.isArray(item)
        || Object.keys(item).some(key => !['reference', 'value'].includes(key))
        || typeof item.reference !== 'string' || !/^sha256:[a-f0-9]{64}$/.test(item.reference) || item.value === undefined
        || staged.has(item.reference)) {
        throw new TypeError(`Invalid or duplicated snapshot entry at index ${index}`);
      }
      const digest = `sha256:${await sha256Hex(item.value)}`;
      if (digest !== item.reference) throw new Error(`Snapshot integrity check failed for ${item.reference}`);
      const size = canonicalBytes(item.value);
      stagedBytes += size;
      if (stagedBytes > this.maxBytes) throw new RangeError('Snapshot exceeds the content-store byte budget');
      staged.set(item.reference, { value: structuredClone(item.value), size });
    }

    // Commit only after the entire snapshot has passed validation.
    this.entries = staged;
    this.bytes = stagedBytes;
    return Object.freeze({ restoredEntries: staged.size, bytes: stagedBytes });
  }

  delete(reference) {
    const entry = this.entries.get(reference);
    if (!entry) return false;
    this.entries.delete(reference);
    this.bytes -= entry.size;
    return true;
  }

  clear() { this.entries.clear(); this.bytes = 0; }

  get stats() {
    return Object.freeze({ entries: this.entries.size, bytes: this.bytes, maxBytes: this.maxBytes });
  }
}
