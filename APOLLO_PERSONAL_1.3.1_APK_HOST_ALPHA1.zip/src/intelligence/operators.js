import { StrategyError } from './errors.js';

function cleanText(value) {
  return String(value ?? '').normalize('NFC').replace(/[\t\f\v ]+/g, ' ').replace(/[\r\n]+/g, ' ').trim();
}

function rankClaims(claims) {
  return [...claims].sort((a, b) => (b.priority ?? 50) - (a.priority ?? 50)
    || (b.confidence ?? 0.5) - (a.confidence ?? 0.5)
    || a.id.localeCompare(b.id));
}

function isQualificationSection(heading) {
  return /uncertain|unknown|caveat|limitation|qualification|open question|what remains/i.test(heading);
}

function assignClaims(claims, sections) {
  const assigned = sections.map(section => ({ id: section.id, heading: section.heading, claims: [] }));
  const generalSections = assigned.filter(section => !isQualificationSection(section.heading));
  const qualificationSections = assigned.filter(section => isQualificationSection(section.heading));
  let generalCursor = 0;
  let qualificationCursor = 0;

  for (const claim of claims) {
    let target = -1;
    if (claim.topic) {
      const topic = claim.topic.toLocaleLowerCase();
      target = assigned.findIndex(section => section.heading.toLocaleLowerCase().includes(topic));
    }

    if (target < 0 && ['hypothesis', 'unknown'].includes(claim.kind) && qualificationSections.length) {
      const selected = qualificationSections[qualificationCursor++ % qualificationSections.length];
      target = assigned.findIndex(section => section.id === selected.id);
    }

    if (target < 0 && !['hypothesis', 'unknown'].includes(claim.kind) && generalSections.length) {
      const selected = generalSections[generalCursor++ % generalSections.length];
      target = assigned.findIndex(section => section.id === selected.id);
    }

    if (target < 0) target = 0;
    assigned[target].claims.push(claim);
  }
  return assigned;
}

function composeDocument({ request, sections }) {
  const lines = [`# ${request.title}`, '', request.objective, ''];
  for (const section of sections) {
    if (!section.claims.length) continue;
    lines.push(`## ${section.heading}`, '');
    for (const claim of section.claims) {
      lines.push(cleanText(claim.text));
      if (claim.caveat) lines.push(`\n*Qualification:* ${cleanText(claim.caveat)}`);
      if (claim.sourceRefs.length) lines.push(`\n*Sources:* ${claim.sourceRefs.map(ref => `[${cleanText(ref)}]`).join(' ')}`);
      lines.push('');
    }
  }
  return lines.join('\n').trim() + '\n';
}

function auditClaimCoverage({ claims, sections, text }) {
  const used = sections.flatMap(section => section.claims.map(claim => claim.id));
  const missing = claims.map(claim => claim.id).filter(id => !used.includes(id));
  const duplicate = used.filter((id, index) => used.indexOf(id) !== index);
  const missingSources = claims.filter(claim => claim.kind === 'fact' && claim.sourceRefs.length === 0).map(claim => claim.id);
  const misplacedClaims = sections.flatMap(section => isQualificationSection(section.heading)
    ? section.claims.filter(claim => !['hypothesis', 'unknown'].includes(claim.kind)).map(claim => claim.id)
    : section.claims.filter(claim => ['hypothesis', 'unknown'].includes(claim.kind)).map(claim => claim.id));
  const allTextPresent = claims.every(claim => text.includes(cleanText(claim.text)));
  return Object.freeze({
    claimCount: claims.length,
    representedCount: used.length,
    missingClaimIds: missing,
    duplicateClaimIds: [...new Set(duplicate)],
    factualClaimsWithoutSources: missingSources,
    misplacedClaims,
    allClaimTextPreserved: allTextPresent,
    passed: missing.length === 0 && duplicate.length === 0 && missingSources.length === 0 && misplacedClaims.length === 0 && allTextPresent
  });
}

export const BUILTIN_OPERATORS = Object.freeze({
  normalize_request: ({ request }) => ({ ...request, objective: cleanText(request.objective), title: cleanText(request.title) }),
  rank_claims: ({ claims }) => rankClaims(claims),
  assign_claims: ({ claims, sections }) => assignClaims(claims, sections),
  compose_document: ({ request, sections }) => composeDocument({ request, sections }),
  audit_claim_coverage: ({ claims, sections, text }) => auditClaimCoverage({ claims, sections, text })
});

export class OperatorRegistry {
  constructor(operators = BUILTIN_OPERATORS) {
    this.operators = new Map(Object.entries(operators));
  }

  has(id) { return this.operators.has(id); }

  execute(id, input) {
    const operator = this.operators.get(id);
    if (!operator) throw new StrategyError(`Unregistered operator: ${String(id)}`);
    return operator(input);
  }

  list() { return Object.freeze([...this.operators.keys()].sort()); }
}
