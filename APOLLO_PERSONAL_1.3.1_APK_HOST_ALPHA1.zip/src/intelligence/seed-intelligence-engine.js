import { SeedCache } from '../cache/seed-cache.js';
import { canonicalBytes } from './digest.js';
import { ContentAddressedStore } from './content-addressed-store.js';
import { createKnowledgePacket, validateKnowledgePacket } from './knowledge-packet.js';
import { OperatorRegistry } from './operators.js';
import { ReasoningPlanner } from './reasoning-planner.js';
import { StrategyRegistry } from './strategy-registry.js';
import { createReasoningSeed, validateReasoningRequest, validateReasoningSeed } from './seed-packet.js';
import { MissingContextError, StrategyError } from './errors.js';
import { validateResourceBounds } from './validation.js';
import { MakeTiny2Engine } from './maketiny2.js';

function mergePackets(packets) {
  const claims = [];
  const seen = new Set();
  for (const packet of packets) {
    validateKnowledgePacket(packet);
    for (const claim of packet.claims) {
      if (seen.has(claim.id)) throw new StrategyError(`Duplicate claim ID across context packets: ${claim.id}`);
      seen.add(claim.id);
      claims.push(claim);
    }
  }
  return claims;
}

export class SeedIntelligenceEngine {
  constructor({
    contentStore = new ContentAddressedStore(),
    cache = new SeedCache({ maxBytes: 2 * 1024 * 1024, ttlMs: 6 * 60 * 60 * 1000 }),
    strategies = new StrategyRegistry(),
    operators = new OperatorRegistry(),
    planner = null,
    engineVersion = '0.2.0',
    maxContextClaims = 500,
    maxOutputBytes = 512 * 1024,
    makeTiny = new MakeTiny2Engine()
  } = {}) {
    this.contentStore = contentStore;
    this.cache = cache;
    this.strategies = strategies;
    this.operators = operators;
    this.planner = planner ?? new ReasoningPlanner({ strategies });
    this.engineVersion = engineVersion;
    this.maxContextClaims = maxContextClaims;
    this.maxOutputBytes = maxOutputBytes;
    this.makeTiny = makeTiny;
  }

  createMakeTinyRoot(options) {
    return this.makeTiny.createRoot(options);
  }

  expandMakeTinySeed(seed, options) {
    return this.makeTiny.expand(seed, options);
  }

  countMakeTinyChildren(seed) {
    return this.makeTiny.countChildren(seed);
  }

  deriveMakeTinyChild(seed, index) {
    return this.makeTiny.deriveChild(seed, index);
  }

  expandMakeTinyTree(seed, options) {
    return this.makeTiny.expandTree(seed, options);
  }

  inspectMakeTinyFootprint(seed, generatedChildren) {
    return this.makeTiny.footprint(seed, generatedChildren);
  }

  async compile({ request, knowledgePackets, strategyId, randomSeed, modelPlan, dreamSections } = {}) {
    if (!Array.isArray(knowledgePackets) || knowledgePackets.length < 1 || knowledgePackets.length > 16) {
      throw new TypeError('compile requires 1–16 knowledge packets');
    }
    validateReasoningRequest(request);
    const plan = this.planner.plan({ taskType: request.taskType, requestedStrategy: strategyId });
    const strategy = this.strategies.get(plan.strategyId);
    for (const operatorId of strategy.operators) {
      if (!this.operators.has(operatorId)) throw new StrategyError(`Strategy ${strategy.id} requires missing operator ${operatorId}`);
    }

    const refs = [];
    let totalClaims = 0;
    let totalContextBytes = 0;
    for (const candidate of knowledgePackets) {
      const packet = candidate?.packet ?? candidate;
      const validation = validateKnowledgePacket(packet);
      totalClaims += validation.claimCount;
      if (totalClaims > this.maxContextClaims) throw new RangeError('Knowledge context exceeds the claim budget');
      const stored = await this.contentStore.put(packet);
      refs.push(stored.reference);
      totalContextBytes += stored.size;
    }

    const compiled = await createReasoningSeed({
      request,
      strategy,
      contextRefs: refs,
      randomSeed,
      modelPlan,
      engineVersion: this.engineVersion
    });
    const selectedVariant = strategy.variants.find(item => item.id === compiled.seed.strategy.variantId);
    const effectiveDreamSections = dreamSections ?? selectedVariant.sections;
    if (!Array.isArray(effectiveDreamSections) || effectiveDreamSections.length < 1 || effectiveDreamSections.length > 12 || effectiveDreamSections.some(section => typeof section !== 'string' || !section.trim() || section.length > 100)) {
      throw new TypeError('dreamSections must contain 1–12 bounded section titles');
    }
    const dreamFamily = await this.makeTiny.createRoot({
      recipeId: 'apollo_dream_v1',
      parameters: {
        taskType: request.taskType,
        objective: request.objective.trim(),
        editorialStyle: request.editorialStyle,
        capabilities: [...compiled.seed.modelPlan.capabilities],
        sections: [...effectiveDreamSections],
        voiceEnabled: false,
        visualEnabled: false
      },
      contextRefs: refs,
      generationSeed: compiled.seed.random.value
    });

    return Object.freeze({
      seed: compiled.seed,
      dreamSeed: dreamFamily.seed,
      diagnostics: Object.freeze({
        seedBytes: compiled.bytes,
        dreamSeedBytes: dreamFamily.bytes,
        referencedContextBytes: totalContextBytes,
        contextPacketCount: refs.length,
        contextClaimCount: totalClaims,
        seedIsSelfContained: false,
        dreamSeedIsReproductivePlan: true,
        compressionClaim: false
      })
    });
  }

  async replay(seed, { useCache = true, allowPrecomputedMoEContext = false } = {}) {
    await validateReasoningSeed(seed);
    if (seed.engineVersion !== this.engineVersion) {
      throw new StrategyError(`Seed engine version ${seed.engineVersion} is incompatible with runtime ${this.engineVersion}`);
    }
    if (seed.modelPlan.needsMoE && !allowPrecomputedMoEContext) {
      throw new StrategyError('This seed records MoE delegation intent. This release does not yet execute a MoE model adapter.');
    }
    const strategy = this.strategies.get(seed.strategy.id);
    if (strategy.version !== seed.strategy.version) throw new StrategyError('Strategy version mismatch; replay would not be stable');
    const variant = strategy.variants.find(item => item.id === seed.strategy.variantId);
    if (!variant) throw new StrategyError('Seed references an unavailable strategy variant');
    for (const operatorId of strategy.operators) {
      if (!this.operators.has(operatorId)) throw new StrategyError(`Required operator is unavailable: ${operatorId}`);
    }

    const cacheKey = `apollo:seed-result:v${this.engineVersion}:${seed.seedId}`;
    if (useCache) {
      const cached = typeof this.cache.getAsync === 'function'
        ? await this.cache.getAsync(cacheKey)
        : this.cache.get(cacheKey);
      if (cached) return Object.freeze({ ...cached, cache: Object.freeze({ hit: true }) });
    }

    const packets = [];
    for (const reference of seed.contextRefs) {
      try { packets.push(await this.contentStore.get(reference)); }
      catch (error) {
        if (error instanceof MissingContextError) throw error;
        throw new Error(`Context integrity check failed: ${reference}`, { cause: error });
      }
    }
    const claims = mergePackets(packets);
    if (claims.length > Math.min(this.maxContextClaims, seed.constraints.maxClaims)) {
      throw new RangeError('Seed context exceeds the replay claim budget');
    }

    let state = {
      request: structuredClone(seed.request),
      claims,
      sections: variant.sections.map((heading, index) => ({ id: `section-${index + 1}`, heading, claims: [] })),
      text: '',
      audit: null
    };

    state.request = this.operators.execute('normalize_request', state);
    state.claims = this.operators.execute('rank_claims', state);
    state.sections = this.operators.execute('assign_claims', state);
    state.text = this.operators.execute('compose_document', state);
    state.audit = this.operators.execute('audit_claim_coverage', state);
    if (!state.audit.passed) throw new Error('Editorial assembly failed claim coverage validation');

    const result = {
      seedId: seed.seedId,
      strategy: { id: strategy.id, version: strategy.version, variantId: variant.id },
      request: structuredClone(seed.request),
      document: {
        title: seed.request.title,
        format: 'text/markdown; charset=utf-8',
        text: state.text,
        sections: state.sections.map(section => ({
          id: section.id,
          heading: section.heading,
          claimIds: section.claims.map(claim => claim.id)
        }))
      },
      audit: state.audit,
      provenance: {
        contextRefs: [...seed.contextRefs],
        claimSources: claims.map(claim => ({ id: claim.id, kind: claim.kind, sourceRefs: [...claim.sourceRefs] })),
        proceduralOnly: true,
        modelPlan: structuredClone(seed.modelPlan)
      },
      deterministic: true
    };
    validateResourceBounds(result, this.maxOutputBytes);

    if (useCache) {
      if (typeof this.cache.setAsync === 'function') await this.cache.setAsync(cacheKey, result);
      else this.cache.set(cacheKey, result);
    }
    return Object.freeze({ ...result, cache: Object.freeze({ hit: false }) });
  }

  async inspect(seed) {
    await validateReasoningSeed(seed);
    const referenced = [];
    for (const reference of seed.contextRefs) {
      const packet = await this.contentStore.get(reference);
      referenced.push({ reference, bytes: canonicalBytes(packet), claims: packet.claims.length });
    }
    return Object.freeze({
      seedId: seed.seedId,
      seedBytes: canonicalBytes(seed),
      references: Object.freeze(referenced),
      totalReferencedBytes: referenced.reduce((sum, item) => sum + item.bytes, 0),
      interpretation: 'The seed stores a reusable strategy and references. The referenced knowledge remains separately stored; this is not lossless compression.'
    });
  }

  get stats() {
    return Object.freeze({
      contentStore: typeof this.contentStore.stats === 'function' ? 'async-persistent' : this.contentStore.stats,
      resultCache: typeof this.cache.stats === 'function' ? 'async-persistent' : this.cache.stats,
      strategyCount: this.strategies.list().length,
      operatorCount: this.operators.list().length,
      engineVersion: this.engineVersion
    });
  }

  async getDiagnostics() {
    const [contentStore, resultCache] = await Promise.all([
      typeof this.contentStore.stats === 'function' ? this.contentStore.stats() : this.contentStore.stats,
      typeof this.cache.stats === 'function' ? this.cache.stats() : this.cache.stats
    ]);
    return Object.freeze({ contentStore, resultCache, strategyCount: this.strategies.list().length, operatorCount: this.operators.list().length, engineVersion: this.engineVersion });
  }
}
