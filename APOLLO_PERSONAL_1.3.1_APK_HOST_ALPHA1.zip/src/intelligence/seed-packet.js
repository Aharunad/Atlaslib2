import { sha256Hex, canonicalBytes } from './digest.js';
import { makeSeededRandom, createGenerationSeed } from '../core/seed.js';
import { SeedValidationError } from './errors.js';
import { validateControllerPlan } from './model-adapter-contracts.js';

const TASK_TYPES = new Set(['conversation', 'explain', 'question', 'article', 'write', 'compare', 'study', 'teach']);
const EDITORIAL_STYLES = new Set(['editorial', 'balanced', 'concise']);
const ID = /^[a-zA-Z][a-zA-Z0-9._:-]{0,79}$/;
const REF = /^sha256:[a-f0-9]{64}$/;

function boundedString(value, path, max = 500) {
  if (typeof value !== 'string' || !value.trim() || value.length > max) {
    throw new SeedValidationError('Expected a non-empty bounded string', path);
  }
}

export function validateReasoningRequest(request) {
  if (!request || typeof request !== 'object' || Array.isArray(request)) throw new SeedValidationError('request must be an object', '$.request');
  const allowedRequestKeys = new Set(['taskType', 'objective', 'title', 'audience', 'language', 'editorialStyle']);
  if (Object.keys(request).some(key => !allowedRequestKeys.has(key))) throw new SeedValidationError('Request contains an unapproved property', '$.request');
  if (!TASK_TYPES.has(request.taskType)) throw new SeedValidationError('Unsupported task type', '$.request.taskType');
  boundedString(request.objective, '$.request.objective', 2000);
  boundedString(request.title, '$.request.title', 240);
  if (request.audience !== undefined) boundedString(request.audience, '$.request.audience', 160);
  if (request.language !== undefined) boundedString(request.language, '$.request.language', 24);
  if (!EDITORIAL_STYLES.has(request.editorialStyle)) throw new SeedValidationError('Unsupported editorial style', '$.request.editorialStyle');
}

export async function createReasoningSeed({
  request,
  strategy,
  contextRefs,
  randomSeed = createGenerationSeed(),
  modelPlan = { needsMoE: false, capabilities: [] },
  engineVersion = '0.2.0'
}) {
  validateReasoningRequest(request);
  if (!strategy || typeof strategy.id !== 'string' || !Number.isInteger(strategy.version)) {
    throw new SeedValidationError('A registered strategy definition is required', '$.strategy');
  }
  if (!Array.isArray(contextRefs) || contextRefs.length < 1 || contextRefs.length > 16 || contextRefs.some(ref => !REF.test(ref))) {
    throw new SeedValidationError('contextRefs must contain 1–16 SHA-256 references', '$.contextRefs');
  }
  boundedString(String(randomSeed), '$.random.value', 100);
  let normalizedModelPlan;
  try { normalizedModelPlan = validateControllerPlan(modelPlan); }
  catch (error) { throw new SeedValidationError(error.message, '$.modelPlan'); }

  const random = makeSeededRandom(`${randomSeed}:${strategy.id}:${strategy.version}`);
  const variant = strategy.variants[Math.floor(random() * strategy.variants.length)];
  const payload = {
    format: 'APOLLO_REASONING_SEED',
    schemaVersion: 1,
    engineVersion,
    random: { algorithm: 'mulberry32-v1', value: String(randomSeed) },
    request: {
      taskType: request.taskType,
      objective: request.objective.trim(),
      title: request.title.trim(),
      audience: (request.audience ?? 'curious general reader').trim(),
      language: (request.language ?? 'en').trim(),
      editorialStyle: request.editorialStyle
    },
    strategy: { id: strategy.id, version: strategy.version, variantId: variant.id },
    contextRefs: [...new Set(contextRefs)].sort(),
    modelPlan: {
      needsMoE: normalizedModelPlan.needsMoE,
      capabilities: [...normalizedModelPlan.capabilities]
    },
    constraints: {
      maxClaims: 500,
      maxOutputBytes: 512 * 1024,
      executablePayloads: false,
      networkAccess: false
    }
  };
  const seedId = await sha256Hex(payload);
  const seed = Object.freeze({ ...payload, seedId });
  return Object.freeze({ seed, bytes: canonicalBytes(seed), digest: seedId });
}

export async function validateReasoningSeed(seed) {
  if (!seed || typeof seed !== 'object' || Array.isArray(seed)) throw new SeedValidationError('Seed must be an object');
  const allowedSeedKeys = new Set(['format', 'schemaVersion', 'engineVersion', 'random', 'request', 'strategy', 'contextRefs', 'modelPlan', 'constraints', 'seedId']);
  if (Object.keys(seed).some(key => !allowedSeedKeys.has(key))) throw new SeedValidationError('Seed contains an unapproved property');
  if (seed.format !== 'APOLLO_REASONING_SEED' || seed.schemaVersion !== 1) throw new SeedValidationError('Unsupported reasoning seed format');
  if (typeof seed.engineVersion !== 'string' || seed.engineVersion.length > 40) throw new SeedValidationError('Invalid engine version', '$.engineVersion');
  if (!seed.random || typeof seed.random !== 'object' || Object.keys(seed.random).some(key => !['algorithm', 'value'].includes(key)) || seed.random.algorithm !== 'mulberry32-v1') throw new SeedValidationError('Unsupported deterministic PRNG', '$.random.algorithm');
  boundedString(seed.random.value, '$.random.value', 100);
  validateReasoningRequest(seed.request);
  if (!seed.strategy || typeof seed.strategy !== 'object' || Array.isArray(seed.strategy) || Object.keys(seed.strategy).some(key => !['id', 'version', 'variantId'].includes(key)) || typeof seed.strategy.id !== 'string' || !ID.test(seed.strategy.id) || !Number.isInteger(seed.strategy.version) || typeof seed.strategy.variantId !== 'string' || !/^[a-z][a-z0-9_]{1,39}$/.test(seed.strategy.variantId)) {
    throw new SeedValidationError('Invalid strategy descriptor', '$.strategy');
  }
  if (!Array.isArray(seed.contextRefs) || seed.contextRefs.length < 1 || seed.contextRefs.length > 16 || seed.contextRefs.some(ref => !REF.test(ref)) || new Set(seed.contextRefs).size !== seed.contextRefs.length) {
    throw new SeedValidationError('Invalid context references', '$.contextRefs');
  }
  try { validateControllerPlan(seed.modelPlan); }
  catch (error) { throw new SeedValidationError(error.message, '$.modelPlan'); }
  if (!seed.constraints || Object.keys(seed.constraints).some(key => !['maxClaims', 'maxOutputBytes', 'executablePayloads', 'networkAccess'].includes(key)) || !Number.isInteger(seed.constraints.maxClaims) || seed.constraints.maxClaims < 1 || seed.constraints.maxClaims > 500 || !Number.isInteger(seed.constraints.maxOutputBytes) || seed.constraints.maxOutputBytes < 1024 || seed.constraints.maxOutputBytes > 512 * 1024) {
    throw new SeedValidationError('Invalid resource constraints', '$.constraints');
  }
  if (!seed.constraints || seed.constraints.executablePayloads !== false || seed.constraints.networkAccess !== false) {
    throw new SeedValidationError('Unsafe execution constraints', '$.constraints');
  }
  const { seedId, ...payload } = seed;
  const actual = await sha256Hex(payload);
  if (actual !== seedId) throw new SeedValidationError('Seed digest mismatch', '$.seedId');
  return Object.freeze({ valid: true, bytes: canonicalBytes(seed), seedId });
}

export function exportReasoningSeed(seed) {
  return JSON.stringify(seed);
}

export async function importReasoningSeed(serialized) {
  if (typeof serialized !== 'string' || serialized.length > 32 * 1024) throw new SeedValidationError('Serialized seed is missing or too large');
  let seed;
  try { seed = JSON.parse(serialized); }
  catch { throw new SeedValidationError('Seed is not valid JSON'); }
  await validateReasoningSeed(seed);
  return seed;
}
