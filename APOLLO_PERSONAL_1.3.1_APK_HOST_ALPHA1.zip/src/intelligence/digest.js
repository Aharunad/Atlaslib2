import { canonicalStringify } from '../cache/canonical.js';

/**
 * Canonical SHA-256 for content-addressed knowledge and seed packets.
 * Web Crypto is available in modern browsers and Node 20+ secure contexts.
 * It is an integrity identifier, not an authentication mechanism.
 */
export async function sha256Hex(value) {
  const text = typeof value === 'string' ? value : canonicalStringify(value);
  const bytes = new TextEncoder().encode(text);
  const cryptoApi = globalThis.crypto;
  if (!cryptoApi?.subtle?.digest) {
    throw new Error('Web Crypto SHA-256 is required; no insecure digest fallback is permitted.');
  }
  const digest = await cryptoApi.subtle.digest('SHA-256', bytes);
  return [...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, '0')).join('');
}

export function canonicalBytes(value) {
  return new TextEncoder().encode(canonicalStringify(value)).byteLength;
}
