import { ACTION_IDS, COMPONENT_TYPES } from './constants.js';
import { DreamValidationError } from './errors.js';

const SAFE_ID = /^[a-zA-Z][a-zA-Z0-9._:-]{0,79}$/;
const MAX_TEXT = 8000;
const MAX_NODES = 280;
const MAX_DEPTH = 14;
const ALLOWED_LAYOUTS = new Set(['stack', 'row', 'grid', 'screen']);
const ALLOWED_TONES = new Set(['default', 'muted', 'editorial', 'label', 'title', 'subtle']);
const ALLOWED_VARIANTS = new Set(['plain', 'soft', 'outlined', 'primary', 'ghost']);
const ALLOWED_QUALITIES = new Set(['low', 'balanced', 'high']);

const PROPS_BY_TYPE = Object.freeze({
  screen: new Set(['layout', 'feature']),
  topbar: new Set(['title', 'subtitle', 'trailing']),
  tabs: new Set(['active', 'items']),
  row: new Set(['layout', 'variant']),
  column: new Set(['layout', 'variant']),
  text: new Set(['text', 'tone', 'maxLines']),
  caption: new Set(['text', 'tone', 'maxLines']),
  card: new Set(['variant']),
  button: new Set(['label', 'variant', 'action', 'disabled']),
  divider: new Set([]),
  spacer: new Set([]),
  'fluid-orb': new Set(['seed', 'quality']),
  'chat-composer': new Set(['placeholder', 'action', 'variant', 'disabled']),
  'feature-list': new Set(['items']),
  'book-shelf': new Set(['items']),
  'magazine-feed': new Set(['items']),
  'reader-content': new Set(['items']),
  'status-line': new Set(['text']),
  'suggestion-list': new Set(['items'])
});

function fail(message, path) { throw new DreamValidationError(message, path); }
function validString(value, max, path) {
  if (typeof value !== 'string' || value.length > max) fail('Invalid or oversized string', path);
}

export function validateBlueprint(blueprint) {
  if (!blueprint || typeof blueprint !== 'object' || Array.isArray(blueprint)) fail('Blueprint must be an object', '$');
  if (blueprint.schemaVersion !== 1) fail('Unsupported blueprint schemaVersion', '$.schemaVersion');
  if (typeof blueprint.id !== 'string' || !SAFE_ID.test(blueprint.id)) fail('Invalid blueprint id', '$.id');
  if (typeof blueprint.generationSeed !== 'string' || blueprint.generationSeed.length > 100) fail('Invalid generation seed', '$.generationSeed');
  if (blueprint.theme !== 'atlas-white') fail('Only the approved atlas-white theme is allowed', '$.theme');
  if (!blueprint.tree) fail('Missing component tree', '$.tree');
  if (blueprint.tree.type !== 'screen') fail('Blueprint root must be a screen component', '$.tree.type');
  if (typeof blueprint.engineVersion !== 'string' || blueprint.engineVersion.length > 40) fail('Invalid engine version', '$.engineVersion');
  if (blueprint.metadata !== undefined) {
    if (!blueprint.metadata || typeof blueprint.metadata !== 'object' || Array.isArray(blueprint.metadata)) fail('metadata must be an object', '$.metadata');
    const allowedMetadata = new Set(['generator', 'experience', 'layoutRecipe', 'resourceProfile', 'activeFeature']);
    for (const [key, value] of Object.entries(blueprint.metadata)) {
      if (!allowedMetadata.has(key)) fail(`Unapproved metadata property: ${key}`, `$.metadata.${key}`);
      validString(value, 120, `$.metadata.${key}`);
    }
  }

  let count = 0;
  const ids = new Set();
  function walk(node, path, depth) {
    if (depth > MAX_DEPTH) fail(`Maximum tree depth ${MAX_DEPTH} exceeded`, path);
    if (!node || typeof node !== 'object' || Array.isArray(node)) fail('Component node must be an object', path);
    count++;
    if (count > MAX_NODES) fail(`Maximum component count ${MAX_NODES} exceeded`, path);
    if (!COMPONENT_TYPES.includes(node.type)) fail(`Unregistered component type: ${String(node.type)}`, `${path}.type`);
    if (typeof node.id !== 'string' || !SAFE_ID.test(node.id)) fail('Invalid component id', `${path}.id`);
    if (ids.has(node.id)) fail('Duplicate component id', `${path}.id`);
    ids.add(node.id);
    if (node.props !== undefined && (!node.props || typeof node.props !== 'object' || Array.isArray(node.props))) fail('props must be an object', `${path}.props`);
    const p = node.props ?? {};
    const allowed = PROPS_BY_TYPE[node.type];
    for (const key of Object.keys(p)) if (!allowed.has(key)) fail(`Unapproved property: ${key}`, `${path}.props.${key}`);

    if (p.text !== undefined) validString(p.text, MAX_TEXT, `${path}.props.text`);
    if (p.title !== undefined) validString(p.title, 200, `${path}.props.title`);
    if (p.subtitle !== undefined) validString(p.subtitle, 200, `${path}.props.subtitle`);
    if (p.trailing !== undefined) validString(p.trailing, 200, `${path}.props.trailing`);
    if (p.label !== undefined) validString(p.label, 200, `${path}.props.label`);
    if (p.placeholder !== undefined) validString(p.placeholder, 200, `${path}.props.placeholder`);
    if (p.tone !== undefined && !ALLOWED_TONES.has(p.tone)) fail('Unapproved text tone', `${path}.props.tone`);
    if (p.variant !== undefined && !ALLOWED_VARIANTS.has(p.variant)) fail('Unapproved component variant', `${path}.props.variant`);
    if (p.layout !== undefined && !ALLOWED_LAYOUTS.has(p.layout)) fail('Unapproved layout', `${path}.props.layout`);
    if (p.action !== undefined && !ACTION_IDS.includes(p.action)) fail('Unapproved action id', `${path}.props.action`);
    if (p.seed !== undefined) validString(p.seed, 100, `${path}.props.seed`);
    if (p.feature !== undefined) validString(p.feature, 80, `${path}.props.feature`);
    if (p.active !== undefined) validString(p.active, 40, `${path}.props.active`);
    if (p.quality !== undefined && !ALLOWED_QUALITIES.has(p.quality)) fail('Unapproved generation quality', `${path}.props.quality`);
    if (p.columns !== undefined && (!Number.isInteger(p.columns) || p.columns < 1 || p.columns > 4)) fail('columns must be between 1 and 4', `${path}.props.columns`);
    if (p.maxLines !== undefined && (!Number.isInteger(p.maxLines) || p.maxLines < 1 || p.maxLines > 20)) fail('maxLines must be between 1 and 20', `${path}.props.maxLines`);
    if (p.disabled !== undefined && typeof p.disabled !== 'boolean') fail('disabled must be boolean', `${path}.props.disabled`);

    if (p.items !== undefined) {
      if (!Array.isArray(p.items) || p.items.length > 40) fail('items must be a bounded array', `${path}.props.items`);
      p.items.forEach((item, i) => {
        const itemPath = `${path}.props.items[${i}]`;
        if (node.type === 'tabs') {
          if (!item || typeof item !== 'object' || Array.isArray(item)) fail('Tab item must be an object', itemPath);
          if (Object.keys(item).some(k => !['id', 'label', 'action'].includes(k))) fail('Tab item has an unapproved property', itemPath);
          if (typeof item.id !== 'string' || !SAFE_ID.test(item.id)) fail('Invalid tab id', `${itemPath}.id`);
          validString(item.label, 40, `${itemPath}.label`);
          if (!ACTION_IDS.includes(item.action)) fail('Unapproved tab action', `${itemPath}.action`);
        } else {
          validString(item, 240, itemPath);
        }
      });
      if (node.type === 'tabs' && p.active !== undefined && !p.items.some(item => item.id === p.active)) {
        fail('Active tab must match a declared tab id', `${path}.props.active`);
      }
    }
    if (node.type === 'button' && !p.action) fail('Button requires an approved action', `${path}.props.action`);
    if (node.type === 'chat-composer' && !p.action) fail('Chat composer requires an approved action', `${path}.props.action`);
    if (node.children !== undefined) {
      if (!Array.isArray(node.children)) fail('children must be an array', `${path}.children`);
      node.children.forEach((child, i) => walk(child, `${path}.children[${i}]`, depth + 1));
    }
  }

  walk(blueprint.tree, '$.tree', 0);
  return Object.freeze({ nodeCount: count, maxDepth: MAX_DEPTH });
}
