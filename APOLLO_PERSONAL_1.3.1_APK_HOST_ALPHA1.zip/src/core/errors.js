export class DreamValidationError extends Error {
  constructor(message, path = '$') {
    super(`${message} at ${path}`);
    this.name = 'DreamValidationError';
    this.path = path;
  }
}

export class DreamRenderError extends Error {
  constructor(message) {
    super(message);
    this.name = 'DreamRenderError';
  }
}
