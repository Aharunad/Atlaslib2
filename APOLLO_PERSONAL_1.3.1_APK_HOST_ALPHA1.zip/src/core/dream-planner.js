import { makeSeededRandom, createGenerationSeed } from './seed.js';
import { createBlueprint, node } from './blueprint.js';

const LAYOUT_RECIPES = ['editorial-calm', 'centered-presence', 'quiet-panel'];

function buildApolloHome(seed, profile) {
  const random = makeSeededRandom(seed);
  const recipe = LAYOUT_RECIPES[Math.floor(random() * LAYOUT_RECIPES.length)];
  const orbSeed = `${seed}:apollo-orb`;
  const children = [
    node('topbar', 'apollo-topbar', { title: 'ATLAS', subtitle: 'LIBRARY', trailing: 'PRIVATE INTELLIGENCE' }),
    node('column', 'apollo-main', { layout: 'stack', variant: 'plain' }, [
      node('caption', 'apollo-eyebrow', { text: 'YOUR PERSONAL INTELLIGENCE', tone: 'label' }),
      node('text', 'apollo-title', { text: recipe === 'centered-presence' ? 'Good to see you.' : 'What shall we explore?', tone: 'title', maxLines: 2 }),
      node('caption', 'apollo-intro', { text: 'Thoughtful answers, clear explanations, and room for curiosity.', tone: 'muted', maxLines: 3 }),
      node('fluid-orb', 'apollo-fluid-orb', { seed: orbSeed, quality: profile.orbQuality }),
      node('chat-composer', 'apollo-composer', { placeholder: 'Ask Apollo anything…', action: 'apollo.submit', variant: 'outlined' }),
      node('suggestion-list', 'apollo-suggestions', { items: [
        'Explain something difficult, simply',
        'Help me think through an idea',
        'Create a polished article'
      ]})
    ])
  ];
  return { recipe, tree: node('screen', 'apollo-screen', { layout: 'screen', feature: 'apollo' }, children) };
}


function buildAtlasFeatureScreen(activeFeature, seed, profile) {
  if (activeFeature === 'magazine') {
    return node('screen', 'atlas-magazine-screen', { layout: 'screen', feature: 'magazine' }, [
      node('topbar', 'magazine-topbar', { title: 'ATLAS', subtitle: 'MAGAZINE' }),
      node('column', 'magazine-main', { layout: 'stack' }, [
        node('caption', 'magazine-eyebrow', { text: 'A CONSIDERED VIEW OF THE WORLD', tone: 'label' }),
        node('text', 'magazine-title', { text: 'Stories worth your attention.', tone: 'title', maxLines: 3 }),
        node('caption', 'magazine-intro', { text: 'A personal magazine shaped from the sources you follow.', tone: 'muted' }),
        node('magazine-feed', 'magazine-feed-mount', {})
      ])
    ]);
  }
  if (activeFeature === 'books') {
    return node('screen', 'atlas-books-screen', { layout: 'screen', feature: 'books' }, [
      node('topbar', 'books-topbar', { title: 'ATLAS', subtitle: 'MY BOOKS' }),
      node('column', 'books-main', { layout: 'stack' }, [
        node('caption', 'books-eyebrow', { text: 'YOUR PRIVATE SHELF', tone: 'label' }),
        node('text', 'books-title', { text: 'A quieter way to read.', tone: 'title', maxLines: 2 }),
        node('caption', 'books-intro', { text: 'Bring your books in. Read at your pace. Listen from exactly where you want.', tone: 'muted' }),
        node('button', 'books-import', { label: 'Import a book', action: 'books.import', variant: 'primary' }),
        node('book-shelf', 'book-shelf-mount', {})
      ])
    ]);
  }
  return buildApolloHome(seed, profile).tree;
}

function buildAppNavigation(active = 'apollo') {
  return node('tabs', 'atlas-primary-navigation', { active, items: [
    { id: 'magazine', label: 'Magazine', action: 'navigate.magazine' },
    { id: 'books', label: 'My Books', action: 'navigate.books' },
    { id: 'apollo', label: 'Apollo', action: 'navigate.apollo' }
  ]});
}

export class DreamPlanner {
  constructor({ resourceProfile }) {
    this.resourceProfile = resourceProfile;
  }

  dreamApolloHome({ seed = createGenerationSeed() } = {}) {
    const built = buildApolloHome(seed, this.resourceProfile);
    const tree = node('screen', 'atlas-app-shell', { layout: 'screen' }, [
      ...built.tree.children,
      buildAppNavigation('apollo')
    ]);
    return createBlueprint({
      id: 'atlas-apollo-home',
      generationSeed: String(seed),
      tree,
      metadata: { experience: 'apollo-home', layoutRecipe: built.recipe, resourceProfile: this.resourceProfile.name }
    });
  }

  dreamAtlasShell({ activeFeature = 'apollo', seed = createGenerationSeed() } = {}) {
    if (!['magazine', 'books', 'apollo'].includes(activeFeature)) {
      throw new TypeError(`Unknown Atlas Library feature: ${String(activeFeature)}`);
    }
    const activeScreen = buildAtlasFeatureScreen(activeFeature, seed, this.resourceProfile);
    const tree = node('screen', 'atlas-root-experience', { layout: 'screen' }, [
      ...activeScreen.children,
      buildAppNavigation(activeFeature)
    ]);
    return createBlueprint({
      id: `atlas-${activeFeature}-experience`,
      generationSeed: String(seed),
      tree,
      metadata: { experience: 'atlas-feature-shell', activeFeature, resourceProfile: this.resourceProfile.name }
    });
  }

  dreamTextExperience({ title, intro, sections = [], seed = createGenerationSeed(), feature = 'generated-text' }) {
    const random = makeSeededRandom(seed);
    const useEditorialCards = random() > 0.35;
    const content = [
      node('caption', 'generated-eyebrow', { text: 'APOLLO CREATION', tone: 'label' }),
      node('text', 'generated-title', { text: title, tone: 'title', maxLines: 3 }),
      node('caption', 'generated-intro', { text: intro, tone: 'muted', maxLines: 5 })
    ];
    sections.forEach((section, index) => {
      const body = [
        node('text', `section-${index}-title`, { text: section.heading, tone: 'title', maxLines: 2 }),
        ...(section.paragraphs ?? []).map((paragraph, p) => node('text', `section-${index}-p-${p}`, { text: paragraph, tone: 'editorial' }))
      ];
      content.push(useEditorialCards
        ? node('card', `section-${index}-card`, { variant: 'soft' }, body)
        : node('column', `section-${index}-column`, { layout: 'stack' }, body));
    });
    return createBlueprint({
      id: `apollo-${feature}`,
      generationSeed: String(seed),
      tree: node('screen', 'generated-text-screen', { layout: 'screen', feature }, [
        node('topbar', 'generated-topbar', { title: 'ATLAS', subtitle: 'APOLLO' }),
        node('column', 'generated-content', { layout: 'stack' }, content),
        buildAppNavigation('apollo')
      ]),
      metadata: { experience: feature, resourceProfile: this.resourceProfile.name }
    });
  }
}
