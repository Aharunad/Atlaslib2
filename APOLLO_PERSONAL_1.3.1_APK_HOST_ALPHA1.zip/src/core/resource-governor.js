export const RESOURCE_PROFILES = Object.freeze({
  constrained: Object.freeze({ orbQuality: 'low', animations: true, maxDreamNodes: 90, cacheBytes: 2 * 1024 * 1024, maxConcurrentWorkers: 1 }),
  balanced: Object.freeze({ orbQuality: 'balanced', animations: true, maxDreamNodes: 180, cacheBytes: 8 * 1024 * 1024, maxConcurrentWorkers: 2 }),
  capable: Object.freeze({ orbQuality: 'high', animations: true, maxDreamNodes: 280, cacheBytes: 24 * 1024 * 1024, maxConcurrentWorkers: 3 })
});

export function selectResourceProfile({ memoryClassMb = 4096, totalRamMb = memoryClassMb, reducedMotion = false, lowPower = false } = {}) {
  // `memoryClassMb` is retained as a backward-compatible fallback. Android
  // integrations should pass `totalRamMb` from ActivityManager.MemoryInfo.
  let name = totalRamMb <= 4096 ? 'constrained' : totalRamMb <= 6144 ? 'balanced' : 'capable';
  if (lowPower && name === 'capable') name = 'balanced';
  const profile = RESOURCE_PROFILES[name];
  return Object.freeze({ name, ...profile, animations: profile.animations && !reducedMotion && !lowPower });
}
