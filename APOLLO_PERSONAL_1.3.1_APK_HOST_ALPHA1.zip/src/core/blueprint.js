import { ENGINE_VERSION } from './constants.js';
import { createGenerationSeed } from './seed.js';

export function node(type, id, props = {}, children = []) {
  const result = { type, id, props };
  if (children.length) result.children = children;
  return result;
}

export function createBlueprint({ id, generationSeed = createGenerationSeed(), tree, metadata = {} }) {
  return {
    schemaVersion: 1,
    engineVersion: ENGINE_VERSION,
    id,
    generationSeed,
    theme: 'atlas-white',
    metadata: {
      generator: 'apollo-dream-kernel',
      ...metadata
    },
    tree
  };
}
