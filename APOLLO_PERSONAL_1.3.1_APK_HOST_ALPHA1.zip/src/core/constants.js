export const ENGINE_VERSION = '0.2.0';
export const APP_ID = 'atlas-library';
export const APOLLO_ID = 'apollo';

export const TOKENS = Object.freeze({
  color: Object.freeze({
    paper: '#FFFFFF',
    page: '#F7F8F8',
    ink: '#17191B',
    muted: '#85898D',
    faint: '#A0A3A6',
    line: '#E9EAEB',
    soft: '#F3F4F5',
    navy: '#061324',
    cyan: '#55D7E8',
    teal: '#46BFCB',
    magenta: '#D85DAB',
    coral: '#F06C64',
    violet: '#8D78C8'
  }),
  radius: Object.freeze({ sm: 10, md: 15, lg: 20, xl: 28, pill: 999 }),
  spacing: Object.freeze({ xs: 4, sm: 8, md: 12, lg: 16, xl: 24, xxl: 32 }),
  type: Object.freeze({
    body: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif',
    editorial: 'Georgia, "Times New Roman", serif'
  })
});

export const COMPONENT_TYPES = Object.freeze([
  'screen', 'topbar', 'tabs', 'row', 'column', 'text', 'caption',
  'card', 'button', 'divider', 'spacer', 'fluid-orb', 'chat-composer',
  'feature-list', 'book-shelf', 'magazine-feed', 'reader-content',
  'status-line', 'suggestion-list'
]);

export const ACTION_IDS = Object.freeze([
  'navigate.magazine', 'navigate.books', 'navigate.apollo',
  'apollo.submit', 'apollo.new-chat', 'apollo.voice-toggle',
  'books.import', 'magazine.refresh', 'settings.open'
]);
