import { DreamPlanner } from './dream-planner.js';
import { validateBlueprint } from './blueprint-validator.js';
import { selectResourceProfile } from './resource-governor.js';
import { SeedIntelligenceEngine } from '../intelligence/seed-intelligence-engine.js';
import { ContentAddressedStore } from '../intelligence/content-addressed-store.js';
import { SeedCache } from '../cache/seed-cache.js';

function deepFreeze(value) {
  if (!value || typeof value !== 'object' || Object.isFrozen(value)) return value;
  Object.freeze(value);
  for (const child of Object.values(value)) deepFreeze(child);
  return value;
}

export class DreamKernel {
  constructor({ device = {}, planner = null, seedIntelligence = null } = {}) {
    this.resourceProfile = selectResourceProfile(device);
    this.planner = planner ?? new DreamPlanner({ resourceProfile: this.resourceProfile });
    this.seedIntelligence = seedIntelligence ?? new SeedIntelligenceEngine({
      contentStore: new ContentAddressedStore({ maxBytes: Math.max(4 * 1024 * 1024, this.resourceProfile.cacheBytes * 4) }),
      cache: new SeedCache({ maxBytes: this.resourceProfile.cacheBytes, ttlMs: 6 * 60 * 60 * 1000 })
    });
  }

  compileReasoningSeed(request) {
    return this.seedIntelligence.compile(request);
  }

  replayReasoningSeed(seed, options) {
    return this.seedIntelligence.replay(seed, options);
  }

  createMakeTinyRoot(options) {
    return this.seedIntelligence.createMakeTinyRoot(options);
  }

  expandMakeTinySeed(seed, options) {
    return this.seedIntelligence.expandMakeTinySeed(seed, options);
  }

  countMakeTinyChildren(seed) {
    return this.seedIntelligence.countMakeTinyChildren(seed);
  }

  deriveMakeTinyChild(seed, index) {
    return this.seedIntelligence.deriveMakeTinyChild(seed, index);
  }

  expandMakeTinyTree(seed, options) {
    return this.seedIntelligence.expandMakeTinyTree(seed, options);
  }

  createExperience(request) {
    if (!request || typeof request !== 'object') throw new TypeError('A dream request is required.');
    let blueprint;
    switch (request.kind) {
      case 'apollo-home':
        blueprint = this.planner.dreamApolloHome({ seed: request.seed });
        break;
      case 'atlas-shell':
        blueprint = this.planner.dreamAtlasShell({ activeFeature: request.activeFeature, seed: request.seed });
        break;
      case 'text-experience':
        blueprint = this.planner.dreamTextExperience(request);
        break;
      default:
        throw new TypeError(`Unsupported dream kind: ${String(request.kind)}`);
    }
    const validation = validateBlueprint(blueprint);
    if (validation.nodeCount > this.resourceProfile.maxDreamNodes) {
      throw new RangeError(`Dream exceeds the ${this.resourceProfile.name} device node budget.`);
    }
    deepFreeze(blueprint);
    return Object.freeze({ blueprint, validation, resourceProfile: this.resourceProfile });
  }
}
