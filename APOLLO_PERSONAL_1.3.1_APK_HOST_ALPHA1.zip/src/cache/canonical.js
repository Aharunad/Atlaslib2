export function canonicalStringify(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonicalStringify).join(',')}]`;
  const keys = Object.keys(value).sort();
  return `{${keys.map(key => `${JSON.stringify(key)}:${canonicalStringify(value[key])}`).join(',')}}`;
}

export function estimateUtf8Bytes(value) {
  const text = typeof value === 'string' ? value : canonicalStringify(value);
  return new TextEncoder().encode(text).byteLength;
}
