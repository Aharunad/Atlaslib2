import { estimateUtf8Bytes } from './canonical.js';

export class SeedCache {
  constructor({ maxBytes = 8 * 1024 * 1024, ttlMs = 24 * 60 * 60 * 1000, now = () => Date.now() } = {}) {
    if (!Number.isSafeInteger(maxBytes) || maxBytes <= 0) throw new RangeError('maxBytes must be a positive safe integer');
    this.maxBytes = maxBytes;
    this.ttlMs = ttlMs;
    this.now = now;
    this.entries = new Map();
    this.bytes = 0;
  }

  get(key) {
    const entry = this.entries.get(key);
    if (!entry) return undefined;
    if (entry.expiresAt <= this.now()) { this.#delete(key); return undefined; }
    this.entries.delete(key);
    this.entries.set(key, entry);
    return structuredClone(entry.value);
  }

  set(key, value, ttlMs = this.ttlMs) {
    const size = estimateUtf8Bytes(value);
    if (size > this.maxBytes) return false;
    this.#delete(key);
    while (this.bytes + size > this.maxBytes && this.entries.size) {
      const oldest = this.entries.keys().next().value;
      this.#delete(oldest);
    }
    this.entries.set(key, { value: structuredClone(value), size, expiresAt: this.now() + ttlMs });
    this.bytes += size;
    return true;
  }

  clear() { this.entries.clear(); this.bytes = 0; }
  get stats() { return Object.freeze({ entries: this.entries.size, bytes: this.bytes, maxBytes: this.maxBytes }); }

  #delete(key) {
    const old = this.entries.get(key);
    if (!old) return;
    this.bytes -= old.size;
    this.entries.delete(key);
  }
}
