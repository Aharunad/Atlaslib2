import { makeSeededRandom } from '../core/seed.js';

const PALETTES = [
  ['#D957A7', '#EF7666', '#4ECBDD', '#8E7AD4'],
  ['#C94E99', '#F18472', '#46C5D6', '#A18AD9'],
  ['#E06A9F', '#E56F5C', '#55D9D0', '#8579C8']
];

function polarPath(cx, cy, rx, ry, phase, wobble, points = 9) {
  const coords = [];
  for (let i = 0; i < points; i++) {
    const a = (Math.PI * 2 * i) / points + phase;
    const r = 1 + Math.sin(a * 3 + phase) * wobble + Math.cos(a * 2 - phase) * wobble * 0.55;
    coords.push([cx + Math.cos(a) * rx * r, cy + Math.sin(a) * ry * r]);
  }
  const mid = (a, b) => [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
  const firstMid = mid(coords[coords.length - 1], coords[0]);
  let d = `M ${firstMid[0].toFixed(2)} ${firstMid[1].toFixed(2)}`;
  for (let i = 0; i < coords.length; i++) {
    const current = coords[i];
    const next = coords[(i + 1) % coords.length];
    const m = mid(current, next);
    d += ` Q ${current[0].toFixed(2)} ${current[1].toFixed(2)} ${m[0].toFixed(2)} ${m[1].toFixed(2)}`;
  }
  return `${d} Z`;
}

export function createFluidOrbSpec(seed = 'apollo-fluid-identity', quality = 'balanced') {
  const random = makeSeededRandom(seed);
  const palette = PALETTES[Math.floor(random() * PALETTES.length)];
  const count = quality === 'low' ? 5 : quality === 'high' ? 11 : 8;
  const layers = [];
  for (let i = 0; i < count; i++) {
    const phase = random() * Math.PI * 2;
    const cx = 120 + (random() - 0.5) * 34;
    const cy = 120 + (random() - 0.5) * 34;
    const rx = 62 + random() * 30;
    const ry = 64 + random() * 34;
    layers.push({
      path: polarPath(cx, cy, rx, ry, phase, 0.09 + random() * 0.055, 9 + Math.floor(random() * 3)),
      color: palette[i % palette.length],
      rotation: Math.round(random() * 34 - 17),
      opacity: 0.42 + random() * 0.28,
      width: 3.8 + random() * 4.8,
      delay: (random() * -8).toFixed(2)
    });
  }
  return Object.freeze({ seed: String(seed), palette, layers, quality });
}
