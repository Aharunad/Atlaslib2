import { validateControllerPlan, validateMoEResponse, validateEditorialResponse } from '../intelligence/model-adapter-contracts.js';
import { validateReasoningSeed } from '../intelligence/seed-packet.js';

function validatePrompt(text) {
  if (typeof text !== 'string' || !text.trim() || text.length > 8000) throw new TypeError('Apollo prompt must be 1–8,000 characters');
  return text.trim();
}

/**
 * Model-agnostic orchestration boundary. Real SLM/MoE/editor runtimes are injected
 * later; this service owns session persistence, planning, delegation and seed lifecycle.
 */
function trimHistory(turns, maxTurns, maxChars) {
  const bounded = [...turns].slice(-maxTurns);
  if (!bounded.length) return [];
  const latest = bounded.pop();
  const selected = [];
  let remaining = maxChars;
  for (const turn of bounded.reverse()) {
    const text = String(turn.text ?? '');
    if (text.length > remaining) continue;
    selected.push({ ...turn, text });
    remaining -= text.length;
    if (remaining <= 0) break;
  }
  // Never silently truncate the current user request; it is the actual task.
  return [...selected.reverse(), latest];
}

export class ApolloConversationService {
  constructor({ store, seedEngine, controller, moeChild, editor = null, maxHistoryTurns = 16, maxHistoryChars = 5500 } = {}) {
    if (!store || !seedEngine || !controller || typeof controller.plan !== 'function') throw new TypeError('Apollo conversation service requires store, seedEngine and a controller adapter');
    if (!Number.isInteger(maxHistoryTurns) || maxHistoryTurns < 2 || maxHistoryTurns > 40) throw new RangeError('maxHistoryTurns must be between 2 and 40');
    if (!Number.isInteger(maxHistoryChars) || maxHistoryChars < 1000 || maxHistoryChars > 50000) throw new RangeError('maxHistoryChars must be between 1,000 and 50,000');
    this.store = store;
    this.seedEngine = seedEngine;
    this.controller = controller;
    this.moeChild = moeChild;
    this.editor = editor;
    this.maxHistoryTurns = maxHistoryTurns;
    this.maxHistoryChars = maxHistoryChars;
  }

  async createSession(options = {}) { return this.store.createSession(options); }

  async send({ sessionId, text, randomSeed, signal, onStatus } = {}) {
    const prompt = validatePrompt(text);
    const existing = await this.store.getSession(sessionId, { limit: this.maxHistoryTurns });
    if (!existing) throw new Error(`Apollo session not found: ${sessionId}`);

    await this.store.appendTurn(sessionId, { role: 'user', text: prompt });
    const session = await this.store.getSession(sessionId, { limit: this.maxHistoryTurns });
    const history = trimHistory(session.turns, this.maxHistoryTurns, this.maxHistoryChars);
    onStatus?.('planning');
    const proposedPlan = await this.controller.plan({ latestMessage: prompt, history: structuredClone(history), signal });
    const plan = validateControllerPlan(proposedPlan);

    let modelResponse;
    let delegated = false;
    let degradedMode = false;
    if (plan.needsMoE && this.moeChild && typeof this.moeChild.generate === 'function') {
      onStatus?.('waking_sleeping_giant');
      try {
        modelResponse = validateMoEResponse(await this.moeChild.generate({
          prompt,
          history: structuredClone(history),
          capabilities: [...plan.capabilities],
          resourceMode: 'bounded',
          signal
        }));
        delegated = true;
      } catch (error) {
        if (signal?.aborted) throw error;
        degradedMode = true;
        onStatus?.('controller_fallback');
        if (typeof this.controller.respond !== 'function') throw new Error(`Sleeping Giant failed and Apollo controller cannot answer: ${error.message}`);
        modelResponse = validateMoEResponse(await this.controller.respond({ prompt, history: structuredClone(history), plan: { ...plan, needsMoE: false }, signal }));
      }
    } else {
      // Personal/4 GB profile: preserve conversation availability when the
      // Sleeping Giant is absent, but expose the reduced-capability path.
      degradedMode = plan.needsMoE;
      onStatus?.(degradedMode ? 'controller_fallback' : 'controller_response');
      if (typeof this.controller.respond !== 'function') throw new Error('Apollo controller cannot answer directly in this runtime');
      modelResponse = validateMoEResponse(await this.controller.respond({ prompt, history: structuredClone(history), plan: { ...plan, needsMoE: false }, signal }));
    }

    const request = {
      taskType: 'conversation',
      objective: prompt,
      title: 'Apollo conversation response',
      audience: 'the current conversation participant',
      language: 'en',
      editorialStyle: 'editorial'
    };
    const compiled = await this.seedEngine.compile({
      request,
      knowledgePackets: [modelResponse.knowledgePacket],
      strategyId: plan.strategyId ?? 'conversation_reply',
      randomSeed,
      modelPlan: { ...plan, needsMoE: delegated }
    });

    await this.store.putSeed(compiled.seed, validateReasoningSeed);
    await this.store.putSeed(compiled.dreamSeed, seed => this.seedEngine.makeTiny.validate(seed));

    let derivedChildSeeds = 0;
    if (delegated) {
      // Root child index 1 is the MoE capability plan. Its capability children
      // are derived only for this turn and are not persisted unless a future
      // scheduler explicitly chooses to retain them.
      const moePlanSeed = await this.store.deriveChildSeed(compiled.dreamSeed.seedId, 1, this.seedEngine.makeTiny);
      const capabilityCount = await this.seedEngine.makeTiny.countChildren(moePlanSeed);
      for (let index = 0; index < capabilityCount; index++) {
        await this.store.deriveChildSeed(moePlanSeed, index, this.seedEngine.makeTiny);
        derivedChildSeeds++;
      }
      derivedChildSeeds++;
    }

    // The MoE result has already been validated and its knowledge packet is
    // content-addressed in the seed context. Replay can now assemble from that
    // precomputed context without invoking model code again.
    const assembled = await this.seedEngine.replay(compiled.seed, { allowPrecomputedMoEContext: delegated });
    let answer = assembled.document.text;
    let editorialApplied = false;
    let editorialFallback = false;
    if (this.editor && typeof this.editor.rewrite === 'function') {
      onStatus?.('editorial_refinement');
      const expectedClaimIds = modelResponse.knowledgePacket.claims.map(claim => claim.id);
      try {
        const edited = validateEditorialResponse(await this.editor.rewrite({
          prompt,
          draft: answer,
          knowledgePacket: modelResponse.knowledgePacket,
          expectedClaimIds,
          style: 'editorial',
          signal
        }), expectedClaimIds);
        answer = edited.text;
        editorialApplied = true;
      } catch (error) {
        if (signal?.aborted) throw error;
        // Preserve the verified deterministic assembly if the neural editor
        // is unavailable or fails the claim-preservation contract.
        editorialFallback = true;
        onStatus?.('editorial_fallback');
      }
    }

    await this.store.appendTurn(sessionId, {
      role: 'assistant',
      text: answer,
      seedRefs: [compiled.seed.seedId, compiled.dreamSeed.seedId],
      metadata: {
        delegatedToMoE: delegated,
        capabilities: [...plan.capabilities],
        editorialApplied,
        editorialFallback,
        claimCount: modelResponse.knowledgePacket.claims.length,
        derivedChildSeeds
      }
    });

    onStatus?.('complete');
    return Object.freeze({
      sessionId,
      answer,
      delegatedToMoE: delegated,
      degradedMode,
      capabilities: plan.capabilities,
      editorialApplied,
      editorialFallback,
      reasoningSeedId: compiled.seed.seedId,
      dreamSeedId: compiled.dreamSeed.seedId,
      derivedChildSeeds,
      provenance: assembled.provenance,
      cache: assembled.cache
    });
  }
}
