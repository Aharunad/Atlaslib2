/**
 * Host bridge contract for offline Android speech. A native host must provide
 * qualified ASR/TTS engines and report whether the selected assets are local.
 * This module intentionally does not silently fall back to cloud speech APIs.
 */
export class ApolloVoiceUnavailableError extends Error {
  constructor(message = 'Offline voice is not installed in this host') { super(message); this.name = 'ApolloVoiceUnavailableError'; }
}

function requireLocalProvider(provider, role) {
  if (!provider || provider.offline !== true) throw new ApolloVoiceUnavailableError(`An installed offline ${role} provider is required`);
  return provider;
}

export class ApolloVoiceSession {
  constructor({ recognizer, synthesizer, converse, onState = () => {}, maxUtteranceChars = 8000 } = {}) {
    if (typeof converse !== 'function') throw new TypeError('converse must be a function');
    if (!Number.isInteger(maxUtteranceChars) || maxUtteranceChars < 100 || maxUtteranceChars > 20_000) throw new RangeError('Invalid voice utterance limit');
    this.recognizer = recognizer;
    this.synthesizer = synthesizer;
    this.converse = converse;
    this.onState = onState;
    this.maxUtteranceChars = maxUtteranceChars;
    this.activeController = null;
    this.running = false;
  }

  async speak(text, options = {}) {
    const tts = requireLocalProvider(this.synthesizer, 'TTS');
    if (typeof text !== 'string' || !text.trim() || text.length > this.maxUtteranceChars) throw new TypeError('Speech text is empty or exceeds the configured limit');
    this.onState('speaking');
    try { return await tts.speak(text, options); }
    finally { this.onState('idle'); }
  }

  async listenAndRespond({ sessionId, signal } = {}) {
    if (this.running) throw new Error('A voice turn is already active');
    const asr = requireLocalProvider(this.recognizer, 'ASR');
    const tts = requireLocalProvider(this.synthesizer, 'TTS');
    this.running = true;
    const controller = new AbortController();
    this.activeController = controller;
    const abort = () => controller.abort(signal?.reason);
    signal?.addEventListener('abort', abort, { once: true });
    try {
      this.onState('listening');
      const recognized = await asr.listenOnce({ signal: controller.signal, maxChars: this.maxUtteranceChars });
      const text = typeof recognized === 'string' ? recognized : recognized?.text;
      if (typeof text !== 'string' || !text.trim()) throw new Error('Speech recognition returned no text');
      if (text.length > this.maxUtteranceChars) throw new RangeError('Recognized utterance exceeds the configured limit');
      this.onState('thinking');
      const response = await this.converse({ sessionId, text: text.trim(), signal: controller.signal });
      if (controller.signal.aborted) throw new Error('Voice turn cancelled');
      this.onState('speaking');
      await tts.speak(response.answer, { signal: controller.signal, voiceId: optionsVoice(response) });
      this.onState('idle');
      return Object.freeze({ userText: text.trim(), ...response });
    } catch (error) {
      this.onState('error');
      throw error;
    } finally {
      signal?.removeEventListener('abort', abort);
      this.activeController = null;
      this.running = false;
      if (controller.signal.aborted) this.onState('idle');
    }
  }

  async interrupt() {
    this.activeController?.abort(new Error('Interrupted by user'));
    if (this.synthesizer?.offline === true && typeof this.synthesizer.stop === 'function') await this.synthesizer.stop();
    if (this.recognizer?.offline === true && typeof this.recognizer.stop === 'function') await this.recognizer.stop();
    this.onState('idle');
  }
}

function optionsVoice(response) { return response?.voiceId ?? 'default'; }

export function createAndroidApolloVoiceProviders(host = globalThis.AtlasApolloNative) {
  if (!host || host.apiVersion !== 1) throw new ApolloVoiceUnavailableError('Atlas Android voice bridge v1 is not installed');
  const recognizer = {
    offline: host.asrOffline === true,
    listenOnce: options => host.listenOnce(options),
    stop: () => host.stopListening?.()
  };
  const synthesizer = {
    offline: host.ttsOffline === true,
    speak: (text, options) => host.speak(text, options),
    stop: () => host.stopSpeaking?.()
  };
  return Object.freeze({ recognizer, synthesizer });
}
