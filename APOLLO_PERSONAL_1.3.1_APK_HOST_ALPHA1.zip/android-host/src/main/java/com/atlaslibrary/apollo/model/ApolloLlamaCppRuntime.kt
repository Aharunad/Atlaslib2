package com.atlaslibrary.apollo.model

/**
 * Narrow JNI facade for the pinned llama.cpp CPU baseline.
 * The JavaScript layer never receives native pointers or filesystem paths.
 */
class ApolloLlamaCppRuntime {
    interface TokenListener {
        fun onToken(token: String)
    }

    val available: Boolean get() = Companion.available
    val loadFailure: String? get() = Companion.loadFailure

    fun version(): String {
        check(available) { loadFailure ?: "Apollo native inference library is unavailable" }
        return nativeVersion()
    }

    fun load(modelPath: String, contextTokens: Int, threads: Int, batchTokens: Int): Long {
        check(available) { loadFailure ?: "Apollo native inference library is unavailable" }
        return nativeLoad(modelPath, contextTokens, threads, batchTokens).also {
            check(it > 0L) { "llama.cpp returned an invalid native session" }
        }
    }

    fun modelInfo(session: Long): String {
        check(available) { loadFailure ?: "Apollo native inference library is unavailable" }
        return nativeModelInfo(session)
    }

    fun generate(
        session: Long,
        roles: Array<String>,
        contents: Array<String>,
        maxTokens: Int,
        responseFormat: String,
        temperature: Double,
        listener: TokenListener
    ): String {
        check(available) { loadFailure ?: "Apollo native inference library is unavailable" }
        require(responseFormat.isEmpty() || responseFormat == "json_object") { "Unsupported response format" }
        require(temperature.isFinite() && temperature in 0.0..2.0) { "Temperature must be between 0 and 2" }
        return nativeGenerate(session, roles, contents, maxTokens, responseFormat, temperature, listener)
    }

    fun cancel(session: Long) {
        if (available) nativeCancel(session)
    }

    fun wasCancelled(session: Long): Boolean = available && nativeIsCancelled(session)

    fun unload(session: Long) {
        if (available) nativeUnload(session)
    }

    private external fun nativeVersion(): String
    private external fun nativeLoad(modelPath: String, contextTokens: Int, threads: Int, batchTokens: Int): Long
    private external fun nativeModelInfo(session: Long): String
    private external fun nativeGenerate(session: Long, roles: Array<String>, contents: Array<String>, maxTokens: Int, responseFormat: String, temperature: Double, listener: TokenListener): String
    private external fun nativeCancel(session: Long)
    private external fun nativeIsCancelled(session: Long): Boolean
    private external fun nativeUnload(session: Long)

    companion object {
        @Volatile
        var loadFailure: String? = null
            private set

        @Volatile
        var available: Boolean = false
            private set

        init {
            try {
                System.loadLibrary("apollo_llama_jni")
                available = true
            } catch (error: UnsatisfiedLinkError) {
                loadFailure = error.message ?: "Native llama.cpp library could not be loaded"
            } catch (error: SecurityException) {
                loadFailure = error.message ?: "Native llama.cpp library loading was blocked"
            }
        }
    }
}
