package com.atlaslibrary.apollo.model

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.StatFs
import android.provider.OpenableColumns
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.security.MessageDigest
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicReference

/**
 * Android SAF + private-file intake bridge for Apollo's Sleeping Giant.
 *
 * Construct this in the trusted Atlas Library ComponentActivity before STARTED,
 * after the WebView has been configured with its app-private AssetLoader origin.
 * Model contents are untrusted data. The bridge can load them only through the
 * pinned llama.cpp runtime and only from Apollo's verified private model store.
 */
class ApolloSleepingGiantBridge(
    private val activity: ComponentActivity,
    private val webView: WebView,
    private val trustedOriginHost: String,
    private val maxArtifactBytes: Long = 64L * 1024L * 1024L * 1024L,
    private val minimumFreeBytes: Long = 32L * 1024L * 1024L,
    private val isAssetInUse: (String) -> Boolean = { false }
) : AutoCloseable {

    private val executor = Executors.newSingleThreadExecutor()
    private val generationExecutor = Executors.newSingleThreadExecutor()
    private val pendingPickerRequest = AtomicReference<String?>(null)
    private val llamaRuntime = ApolloLlamaCppRuntime()
    private data class NativeSession(val sessionId: String, val assetId: String, val handle: Long, val modelInfo: JSONObject)
    private val nativeSessions = ConcurrentHashMap<String, NativeSession>()
    private val activeAssetId = AtomicReference<String?>(null)
    private val importInProgress = AtomicReference(false)
    private val modelDirectory = File(activity.filesDir, "apollo/models")

    private val openDocumentLauncher = activity.registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> onDocumentPicked(uri) }

    private val javascriptApi = object {
        @JavascriptInterface
        fun importSleepingGiant(requestId: String) {
            if (!REQUEST_ID.matches(requestId)) {
                dispatchResult(JSONObject().put("requestId", requestId).put("ok", false).put("code", "BAD_REQUEST").put("error", "Invalid model import request."))
                return
            }
            activity.runOnUiThread {
                if (!isTrustedPage()) {
                    dispatchResult(JSONObject().put("requestId", requestId).put("ok", false).put("code", "UNTRUSTED_ORIGIN").put("error", "Model import is available only inside the trusted Atlas Library app."))
                    return@runOnUiThread
                }
                if (!importInProgress.compareAndSet(false, true)) {
                    dispatchResult(JSONObject().put("requestId", requestId).put("ok", false).put("code", "IMPORT_BUSY").put("error", "Another model import is already in progress."))
                    return@runOnUiThread
                }
                pendingPickerRequest.set(requestId)
                try {
                    openDocumentLauncher.launch(arrayOf("*/*"))
                } catch (error: Exception) {
                    pendingPickerRequest.set(null)
                    importInProgress.set(false)
                    dispatchResult(JSONObject().put("requestId", requestId).put("ok", false).put("code", "PICKER_FAILED").put("error", error.message ?: "Android file picker could not be opened."))
                }
            }
        }

        @JavascriptInterface
        fun getDeviceProfile(requestId: String) {
            if (!REQUEST_ID.matches(requestId)) {
                dispatchResult(JSONObject().put("requestId", requestId).put("ok", false).put("code", "BAD_REQUEST").put("error", "Invalid device-profile request."))
                return
            }
            activity.runOnUiThread {
                if (!isTrustedPage()) {
                    dispatchResult(JSONObject().put("requestId", requestId).put("ok", false).put("code", "UNTRUSTED_ORIGIN").put("error", "Device information is available only inside Atlas Library."))
                    return@runOnUiThread
                }
                executor.execute {
                    try {
                        val manager = activity.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                        val memory = ActivityManager.MemoryInfo()
                        manager.getMemoryInfo(memory)
                        if (!modelDirectory.exists()) modelDirectory.mkdirs()
                        val availableStorage = StatFs(modelDirectory.absolutePath).availableBytes
                        val abis = JSONArray().apply { Build.SUPPORTED_ABIS.take(16).forEach { put(it) } }
                        val signature = listOf(Build.MANUFACTURER, Build.MODEL).filter { it.isNotBlank() }.joinToString(" ").take(120)
                        val profile = JSONObject()
                            .put("platform", "android")
                            .put("totalRamBytes", memory.totalMem)
                            .put("availableRamBytes", memory.availMem)
                            .put("lowMemory", memory.lowMemory)
                            .put("lowRamDevice", manager.isLowRamDevice)
                            .put("cpuCores", Runtime.getRuntime().availableProcessors().coerceAtLeast(1))
                            .put("supportedAbis", abis)
                            .put("apiLevel", Build.VERSION.SDK_INT)
                            .put("appMemoryClassMb", manager.memoryClass)
                            .put("availableStorageBytes", availableStorage)
                            .put("deviceSignature", signature)
                        dispatchResult(JSONObject().put("requestId", requestId).put("ok", true).put("profile", profile))
                    } catch (error: Exception) {
                        dispatchResult(JSONObject().put("requestId", requestId).put("ok", false).put("code", "DEVICE_PROFILE_FAILED").put("error", error.message ?: "Android device capabilities could not be read."))
                    }
                }
            }
        }

        @JavascriptInterface
        fun getRuntimeCapabilities(requestId: String) {
            if (!REQUEST_ID.matches(requestId)) {
                dispatchResult(JSONObject().put("requestId", requestId).put("ok", false).put("code", "BAD_REQUEST").put("error", "Invalid runtime capability request."))
                return
            }
            activity.runOnUiThread {
                if (!isTrustedPage()) {
                    dispatchResult(JSONObject().put("requestId", requestId).put("ok", false).put("code", "UNTRUSTED_ORIGIN").put("error", "Runtime information is available only inside Atlas Library."))
                    return@runOnUiThread
                }
                executor.execute {
                    val available = llamaRuntime.available
                    val capabilities = JSONObject()
                        .put("available", available)
                        .put("version", if (available) runCatching { llamaRuntime.version() }.getOrNull() else JSONObject.NULL)
                        .put("formats", if (available) JSONArray().put("gguf") else JSONArray())
                        .put("architectureCandidates", if (available) JSONArray().put("*") else JSONArray())
                        .put("backend", if (available) "cpu" else JSONObject.NULL)
                        .put("gpuOffload", false)
                        .put("reason", if (available) "Pinned llama.cpp CPU runtime is loaded. Each selected model still requires a native load and generation test." else (llamaRuntime.loadFailure ?: "Native llama.cpp library is not present in this host build."))
                    dispatchResult(JSONObject().put("requestId", requestId).put("ok", true).put("runtimeCapabilities", capabilities))
                }
            }
        }

        @JavascriptInterface
        fun loadSleepingGiant(requestId: String, assetId: String, contextTokens: Int, threads: Int, batchTokens: Int) {
            if (!REQUEST_ID.matches(requestId) || !ASSET_ID.matches(assetId)) {
                dispatchResult(JSONObject().put("requestId", requestId).put("ok", false).put("code", "BAD_REQUEST").put("error", "Invalid native model load request."))
                return
            }
            activity.runOnUiThread {
                if (!isTrustedPage()) {
                    dispatchResult(JSONObject().put("requestId", requestId).put("ok", false).put("code", "UNTRUSTED_ORIGIN").put("error", "Model inference is available only inside Atlas Library."))
                    return@runOnUiThread
                }
                executor.execute {
                    try {
                        if (!llamaRuntime.available) throw IllegalStateException(llamaRuntime.loadFailure ?: "Native llama.cpp runtime is not installed.")
                        val current = activeAssetId.get()
                        if (current != null) throw IllegalStateException("A Sleeping Giant is already loaded. Unload it before loading another model.")
                        val modelFile = managedModelFile(assetId)
                        if (!modelFile.isFile || modelFile.length() < MIN_GGUF_BYTES) throw IllegalStateException("The selected private GGUF asset is missing or incomplete.")
                        if (!sha256File(modelFile).startsWith(assetId.removePrefix("sg-"))) throw IllegalStateException("The private GGUF file failed its asset fingerprint check.")
                        if (contextTokens !in 256..131072 || threads !in 1..32 || batchTokens !in 8..512) throw IllegalArgumentException("The adaptive runtime options are outside Apollo's safe limits.")
                        val inspection = GgufHeaderInspector.inspect(modelFile)
                        enforceDeviceMemoryBudget(modelFile.length(), inspection, contextTokens)
                        dispatchProgress(requestId, "loading", modelFile.length(), modelFile.length())
                        val handle = llamaRuntime.load(modelFile.absolutePath, contextTokens, threads, batchTokens)
                        try {
                            val info = JSONObject(llamaRuntime.modelInfo(handle))
                            val sessionId = UUID.randomUUID().toString()
                            val session = NativeSession(sessionId, assetId, handle, info)
                            nativeSessions[sessionId] = session
                            activeAssetId.set(assetId)
                            dispatchResult(JSONObject().put("requestId", requestId).put("ok", true)
                                .put("sessionId", sessionId).put("assetId", assetId).put("modelInfo", info)
                                .put("runtime", JSONObject().put("engine", "llama.cpp").put("version", llamaRuntime.version()).put("backend", "cpu")))
                        } catch (error: Exception) {
                            llamaRuntime.unload(handle)
                            throw error
                        }
                    } catch (error: Exception) {
                        dispatchResult(JSONObject().put("requestId", requestId).put("ok", false).put("code", classifyRuntime(error)).put("error", error.message ?: "Native model load failed."))
                    }
                }
            }
        }

        @JavascriptInterface
        fun generateSleepingGiant(requestId: String, sessionId: String, messagesJson: String, maxTokens: Int, responseFormat: String, temperature: Double) {
            if (!REQUEST_ID.matches(requestId) || !SESSION_ID.matches(sessionId) || messagesJson.length > MAX_CHAT_JSON_CHARS || maxTokens !in 1..8192 || responseFormat !in setOf("", "json_object") || !temperature.isFinite() || temperature !in 0.0..2.0) {
                dispatchResult(JSONObject().put("requestId", requestId).put("ok", false).put("code", "BAD_REQUEST").put("error", "Invalid native generation request."))
                return
            }
            activity.runOnUiThread {
                if (!isTrustedPage()) {
                    dispatchResult(JSONObject().put("requestId", requestId).put("ok", false).put("code", "UNTRUSTED_ORIGIN").put("error", "Native inference is available only inside Atlas Library."))
                    return@runOnUiThread
                }
                val session = nativeSessions[sessionId]
                if (session == null) {
                    dispatchResult(JSONObject().put("requestId", requestId).put("ok", false).put("code", "SESSION_NOT_FOUND").put("error", "Sleeping Giant is not loaded."))
                    return@runOnUiThread
                }
                generationExecutor.execute {
                    try {
                        val messages = JSONArray(messagesJson)
                        if (messages.length() !in 1..32) throw IllegalArgumentException("Chat must contain 1 to 32 messages.")
                        val roles = Array(messages.length()) { index -> messages.getJSONObject(index).getString("role") }
                        val contents = Array(messages.length()) { index -> messages.getJSONObject(index).getString("content") }
                        var totalChars = 0
                        roles.indices.forEach { index ->
                            if (roles[index] !in setOf("system", "user", "assistant")) throw IllegalArgumentException("Unsupported chat role.")
                            if (contents[index].length > 48 * 1024) throw IllegalArgumentException("A chat message exceeds Apollo's 48 KiB limit.")
                            totalChars += contents[index].length
                        }
                        if (totalChars > 128 * 1024) throw IllegalArgumentException("Chat history exceeds Apollo's 128 KiB limit.")
                        dispatchProgress(requestId, "generating", 0L, maxTokens.toLong())
                        val output = llamaRuntime.generate(session.handle, roles, contents, maxTokens, responseFormat, temperature, object : ApolloLlamaCppRuntime.TokenListener {
                            override fun onToken(token: String) {
                                dispatchEvent("atlas-apollo-native-token", JSONObject().put("requestId", requestId).put("sessionId", sessionId).put("token", token))
                            }
                        })
                        val modelInfo = JSONObject(llamaRuntime.modelInfo(session.handle))
                        val metrics = JSONObject()
                            .put("promptTokens", modelInfo.optLong("lastPromptTokens"))
                            .put("generatedTokens", modelInfo.optLong("lastGeneratedTokens"))
                            .put("promptMs", modelInfo.optDouble("lastPromptMs"))
                            .put("generationMs", modelInfo.optDouble("lastGenerationMs"))
                            .put("promptTokensPerSecond", modelInfo.optDouble("lastPromptTokensPerSecond"))
                            .put("generationTokensPerSecond", modelInfo.optDouble("lastGenerationTokensPerSecond"))
                        dispatchResult(JSONObject().put("requestId", requestId).put("ok", true).put("sessionId", sessionId)
                            .put("text", output).put("metrics", metrics).put("cancelled", nativeWasCancelled(session.handle)))
                    } catch (error: Exception) {
                        dispatchResult(JSONObject().put("requestId", requestId).put("ok", false).put("code", classifyRuntime(error)).put("error", error.message ?: "Native generation failed."))
                    }
                }
            }
        }

        @JavascriptInterface
        fun cancelSleepingGiant(sessionId: String) {
            if (!SESSION_ID.matches(sessionId)) return
            nativeSessions[sessionId]?.let { llamaRuntime.cancel(it.handle) }
        }

        @JavascriptInterface
        fun unloadSleepingGiant(requestId: String, sessionId: String) {
            if (!REQUEST_ID.matches(requestId) || !SESSION_ID.matches(sessionId)) {
                dispatchResult(JSONObject().put("requestId", requestId).put("ok", false).put("code", "BAD_REQUEST").put("error", "Invalid native unload request."))
                return
            }
            activity.runOnUiThread {
                if (!isTrustedPage()) {
                    dispatchResult(JSONObject().put("requestId", requestId).put("ok", false).put("code", "UNTRUSTED_ORIGIN").put("error", "Native inference is available only inside Atlas Library."))
                    return@runOnUiThread
                }
                val session = nativeSessions[sessionId]
                if (session == null) {
                    dispatchResult(JSONObject().put("requestId", requestId).put("ok", true).put("unloaded", true))
                    return@runOnUiThread
                }
                llamaRuntime.cancel(session.handle)
                generationExecutor.execute {
                    try {
                        llamaRuntime.unload(session.handle)
                        nativeSessions.remove(sessionId)
                        activeAssetId.compareAndSet(session.assetId, null)
                        dispatchResult(JSONObject().put("requestId", requestId).put("ok", true).put("unloaded", true).put("assetId", session.assetId))
                    } catch (error: Exception) {
                        dispatchResult(JSONObject().put("requestId", requestId).put("ok", false).put("code", "UNLOAD_FAILED").put("error", error.message ?: "Native model unload failed."))
                    }
                }
            }
        }

        @JavascriptInterface
        fun removeSleepingGiant(requestId: String, assetId: String) {
            if (!REQUEST_ID.matches(requestId) || !ASSET_ID.matches(assetId)) {
                dispatchResult(JSONObject().put("requestId", requestId).put("ok", false).put("code", "BAD_REQUEST").put("error", "Invalid model removal request."))
                return
            }
            activity.runOnUiThread {
                if (!isTrustedPage()) {
                    dispatchResult(JSONObject().put("requestId", requestId).put("ok", false).put("code", "UNTRUSTED_ORIGIN").put("error", "Model storage is available only inside Atlas Library."))
                    return@runOnUiThread
                }
                executor.execute {
                    try {
                        if (isAssetInUse(assetId) || nativeSessions.values.any { it.assetId == assetId }) throw IllegalStateException("This model is currently loaded and cannot be removed. Unload it first.")
                        val target = managedModelFile(assetId)
                        if (target.exists() && !target.delete()) throw IllegalStateException("Apollo could not remove its private model copy.")
                        dispatchResult(JSONObject().put("requestId", requestId).put("ok", true).put("assetId", assetId).put("removed", true))
                    } catch (error: Exception) {
                        dispatchResult(JSONObject().put("requestId", requestId).put("ok", false).put("code", "REMOVE_FAILED").put("error", error.message ?: "Model removal failed."))
                    }
                }
            }
        }
    }

    init {
        require(trustedOriginHost.isNotBlank()) { "trustedOriginHost must be configured" }
        require(maxArtifactBytes > 0) { "maxArtifactBytes must be positive" }
        modelDirectory.mkdirs()
        webView.addJavascriptInterface(javascriptApi, "AtlasApolloModelHost")
    }

    private fun isTrustedPage(): Boolean {
        val current = Uri.parse(webView.url ?: return false)
        return current.scheme == "https" && current.host == trustedOriginHost
    }

    private fun onDocumentPicked(uri: Uri?) {
        val requestId = pendingPickerRequest.getAndSet(null) ?: return
        if (uri == null) {
            importInProgress.set(false)
            dispatchResult(JSONObject().put("requestId", requestId).put("ok", false).put("cancelled", true))
            return
        }
        executor.execute {
            var persistedGrant = false
            try {
                activity.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                persistedGrant = true
            } catch (_: SecurityException) {
                // The immediate picker grant may still be usable for this import.
            }
            try {
                val imported = importDocument(uri, requestId)
                dispatchResult(JSONObject().put("requestId", requestId).put("ok", true).put("model", imported))
            } catch (error: Exception) {
                dispatchResult(JSONObject().put("requestId", requestId).put("ok", false).put("code", classify(error)).put("error", error.message ?: "Model import failed."))
            } finally {
                if (persistedGrant) {
                    try { activity.contentResolver.releasePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                }
                importInProgress.set(false)
            }
        }
    }

    private fun importDocument(uri: Uri, requestId: String): JSONObject {
        val metadata = queryDocument(uri)
        val displayName = metadata.first
        val expectedBytes = metadata.second
        preflightGguf(uri)
        if (expectedBytes != null && expectedBytes > maxArtifactBytes) {
            throw IllegalArgumentException("This model is ${humanBytes(expectedBytes)}. Apollo's configured import limit is ${humanBytes(maxArtifactBytes)}.")
        }
        if (!modelDirectory.exists() && !modelDirectory.mkdirs()) throw IllegalStateException("Apollo could not create its private model directory.")
        val availableBytes = StatFs(modelDirectory.absolutePath).availableBytes
        if (expectedBytes != null && availableBytes < expectedBytes + minimumFreeBytes) {
            throw IllegalStateException("Not enough free storage. Apollo needs approximately ${humanBytes(expectedBytes + minimumFreeBytes)} free to make and verify a private copy.")
        }
        val copyBudgetBytes = (availableBytes - minimumFreeBytes).coerceAtLeast(0L)
        if (copyBudgetBytes < MIN_GGUF_BYTES) throw IllegalStateException("Not enough free storage for a private model copy.")

        val temporary = File(modelDirectory, ".import-${System.nanoTime()}.part")
        var bytesCopied = 0L
        val digest = MessageDigest.getInstance("SHA-256")
        dispatchProgress(requestId, "copying", 0L, expectedBytes ?: 0L)
        try {
            val input = activity.contentResolver.openInputStream(uri)
                ?: throw IllegalStateException("Android could not open the selected document.")
            input.use { source ->
                BufferedInputStream(source, BUFFER_BYTES).use { bufferedInput ->
                    FileOutputStream(temporary).use { rawOutput ->
                        BufferedOutputStream(rawOutput, BUFFER_BYTES).use { output ->
                            val buffer = ByteArray(BUFFER_BYTES)
                            while (true) {
                                val count = bufferedInput.read(buffer)
                                if (count < 0) break
                                bytesCopied += count.toLong()
                                if (bytesCopied > maxArtifactBytes) throw IllegalArgumentException("Model exceeds Apollo's ${humanBytes(maxArtifactBytes)} import limit.")
                                if (bytesCopied > copyBudgetBytes) throw IllegalStateException("The model is larger than the available private storage budget. The incomplete copy has been removed.")
                                digest.update(buffer, 0, count)
                                output.write(buffer, 0, count)
                                if (bytesCopied % PROGRESS_INTERVAL < count) {
                                    dispatchProgress(requestId, "copying", bytesCopied, expectedBytes ?: 0L)
                                }
                            }
                            output.flush()
                            rawOutput.fd.sync()
                        }
                    }
                }
            }
            if (expectedBytes != null && expectedBytes > 0L && bytesCopied != expectedBytes) {
                throw IllegalStateException("The selected document changed during import. Expected ${humanBytes(expectedBytes)}, copied ${humanBytes(bytesCopied)}.")
            }
            if (bytesCopied < MIN_GGUF_BYTES) throw IllegalArgumentException("The selected file is too small to be a GGUF model.")

            val sha256 = digest.digest().joinToString("") { "%02x".format(Locale.ROOT, it.toInt() and 0xff) }
            dispatchProgress(requestId, "inspecting", bytesCopied, expectedBytes ?: bytesCopied)
            val inspection = GgufHeaderInspector.inspect(temporary)
            if (inspection.fileBytes != bytesCopied) throw IllegalStateException("GGUF inspection size does not match the copied file.")

            val modelId = "sg-${sha256.take(24)}"
            val finalFile = managedModelFile(modelId)
            var createdNewCopy = false
            if (finalFile.exists()) {
                val existingHash = sha256File(finalFile)
                if (existingHash != sha256) throw IllegalStateException("An existing private model file failed its SHA-256 integrity check.")
                temporary.delete()
            } else {
                if (!temporary.renameTo(finalFile)) throw IllegalStateException("Apollo could not finalize the private model copy.")
                createdNewCopy = true
            }
            dispatchProgress(requestId, "validating", bytesCopied, expectedBytes ?: bytesCopied)
            val storedHash = sha256File(finalFile)
            if (storedHash != sha256) {
                if (createdNewCopy) finalFile.delete()
                throw IllegalStateException("The private model copy failed its post-write SHA-256 integrity check.")
            }
            dispatchProgress(requestId, "complete", bytesCopied, expectedBytes ?: bytesCopied)

            return JSONObject()
                .put("displayName", displayName)
                .put("assetId", modelId)
                .put("sha256", sha256)
                .put("bytes", bytesCopied)
                .put("format", "gguf")
                .put("inspection", inspection.toJson())
                .put("runtimeCapabilities", runtimeCapabilitiesJson())
        } catch (error: Exception) {
            temporary.delete()
            throw error
        }
    }

    private fun preflightGguf(uri: Uri) {
        val prefix = ByteArray(8)
        activity.contentResolver.openInputStream(uri)?.use { input ->
            var offset = 0
            while (offset < prefix.size) {
                val count = input.read(prefix, offset, prefix.size - offset)
                if (count < 0) throw IllegalArgumentException("Selected file is too short to be GGUF.")
                offset += count
            }
        } ?: throw IllegalStateException("Android could not open the selected document.")
        if (String(prefix.copyOfRange(0, 4), Charsets.US_ASCII) != "GGUF") {
            throw IllegalArgumentException("Selected file is not GGUF. Alpha 1 accepts single-file GGUF models only.")
        }
        val version = (prefix[4].toInt() and 0xff) or
            ((prefix[5].toInt() and 0xff) shl 8) or
            ((prefix[6].toInt() and 0xff) shl 16) or
            ((prefix[7].toInt() and 0xff) shl 24)
        if (version !in 2..3) throw IllegalArgumentException("GGUF version $version is not supported by Apollo's current inspector.")
    }

    private fun sha256File(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { raw ->
            BufferedInputStream(raw, BUFFER_BYTES).use { input ->
                val buffer = ByteArray(BUFFER_BYTES)
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    digest.update(buffer, 0, count)
                }
            }
        }
        return digest.digest().joinToString("") { "%02x".format(Locale.ROOT, it.toInt() and 0xff) }
    }

    private fun queryDocument(uri: Uri): Pair<String, Long?> {
        var name = "Sleeping-Giant.gguf"
        var size: Long? = null
        activity.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIndex >= 0) name = cursor.getString(nameIndex)?.take(240)?.ifBlank { name } ?: name
                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex).takeIf { it > 0L }
            }
        }
        return name to size
    }

    private fun managedModelFile(assetId: String): File {
        require(ASSET_ID.matches(assetId)) { "Invalid private model asset ID." }
        val root = modelDirectory.canonicalFile
        val target = File(root, "$assetId.gguf").canonicalFile
        require(target.parentFile == root) { "Model asset path escaped the private model directory." }
        return target
    }

    private fun runtimeCapabilitiesJson(): JSONObject {
        val available = llamaRuntime.available
        return JSONObject()
            .put("available", available)
            .put("version", if (available) runCatching { llamaRuntime.version() }.getOrNull() else JSONObject.NULL)
            .put("formats", if (available) JSONArray().put("gguf") else JSONArray())
            .put("architectureCandidates", if (available) JSONArray().put("*") else JSONArray())
            .put("backend", if (available) "cpu" else JSONObject.NULL)
            .put("gpuOffload", false)
            .put("reason", if (available) "Pinned llama.cpp CPU runtime is present. Exact model load and generation validation are still required." else (llamaRuntime.loadFailure ?: "Native llama.cpp library is not present in this host build."))
    }

    private fun enforceDeviceMemoryBudget(modelBytes: Long, inspection: GgufInspection, contextTokens: Int) {
        val manager = activity.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memory = ActivityManager.MemoryInfo()
        manager.getMemoryInfo(memory)
        val total = memory.totalMem.coerceAtLeast(1L)
        val low = manager.isLowRamDevice || memory.lowMemory || total <= 4L * 1024L * 1024L * 1024L
        val reserve = maxOf(384L * MIB, (total * if (low) 0.16 else 0.12).toLong())
        val availableAfterReserve = (memory.availMem - reserve).coerceAtLeast(0L)
        val deviceShare = (total * if (low) 0.18 else 0.28).toLong()
        val modelBudget = minOf((availableAfterReserve * if (low) 0.55 else 0.65).toLong(), deviceShare)
        val base = (modelBytes * 1.13).toLong().coerceAtLeast(modelBytes)
        val layers = inspection.blockCount ?: throw IllegalArgumentException("GGUF is missing its layer count. Apollo cannot estimate KV memory safely.")
        val heads = inspection.headCountKv ?: inspection.headCount ?: throw IllegalArgumentException("GGUF is missing its attention head count.")
        val key = inspection.keyLength ?: inspection.embeddingLength?.let { emb -> inspection.headCount?.takeIf { it > 0L && emb % it == 0L }?.let { emb / it } }
            ?: throw IllegalArgumentException("GGUF is missing its key dimension.")
        val value = inspection.valueLength ?: key
        val kvBytes = contextTokens.toLong() * layers * heads * (key + value) * 2L
        val scratch = maxOf(64L * MIB, contextTokens.toLong() * (if (low) 24L else 40L) * 1024L)
        val estimate = base + kvBytes + scratch
        if (estimate > modelBudget) {
            throw IllegalArgumentException("This model is above Apollo's conservative memory budget. Estimated ${humanBytes(estimate)} versus ${humanBytes(modelBudget)} available for the model. Choose a smaller model or context.")
        }
    }

    private fun nativeWasCancelled(handle: Long): Boolean = llamaRuntime.wasCancelled(handle)

    private fun classifyRuntime(error: Exception): String = when {
        error is IllegalArgumentException -> "RUNTIME_MODEL_REJECTED"
        error is SecurityException -> "RUNTIME_STORAGE_PERMISSION"
        error.message?.contains("out of memory", ignoreCase = true) == true -> "RUNTIME_OUT_OF_MEMORY"
        else -> "NATIVE_RUNTIME_FAILED"
    }

    private fun classify(error: Exception): String = when (error) {
        is GgufInspectionException -> error.code
        is IllegalArgumentException -> "MODEL_REJECTED"
        is SecurityException -> "STORAGE_PERMISSION"
        else -> "IMPORT_FAILED"
    }

    private fun dispatchProgress(requestId: String, phase: String, copied: Long, total: Long) {
        val detail = JSONObject()
            .put("requestId", requestId)
            .put("phase", phase)
            .put("bytesCopied", copied)
            .put("totalBytes", total)
        dispatchEvent("atlas-apollo-native-progress", detail)
    }

    private fun dispatchResult(result: JSONObject) = dispatchEvent("atlas-apollo-native-result", result)

    private fun dispatchEvent(name: String, detail: JSONObject) {
        val encoded = JSONObject.quote(detail.toString())
        val script = "window.dispatchEvent(new CustomEvent('$name',{detail:JSON.parse($encoded)}));"
        webView.post { webView.evaluateJavascript(script, null) }
    }

    override fun close() {
        nativeSessions.values.forEach { llamaRuntime.cancel(it.handle) }
        generationExecutor.execute {
            nativeSessions.values.forEach { runCatching { llamaRuntime.unload(it.handle) } }
            nativeSessions.clear()
            activeAssetId.set(null)
        }
        generationExecutor.shutdown()
        executor.shutdownNow()
        webView.removeJavascriptInterface("AtlasApolloModelHost")
    }

    companion object {
        private const val BUFFER_BYTES = 1024 * 1024
        private const val PROGRESS_INTERVAL = 16L * 1024L * 1024L
        private const val MIN_GGUF_BYTES = 24L
        private const val MIB = 1024L * 1024L
        private const val MAX_CHAT_JSON_CHARS = 160 * 1024
        private val REQUEST_ID = Regex("^[A-Za-z0-9._-]{3,128}$")
        private val ASSET_ID = Regex("^sg-[a-f0-9]{24}$")
        private val SESSION_ID = Regex("^[0-9a-fA-F-]{36}$")

        private fun humanBytes(value: Long): String {
            var amount = value.toDouble()
            val units = arrayOf("B", "KB", "MB", "GB", "TB")
            var index = 0
            while (amount >= 1024.0 && index < units.lastIndex) { amount /= 1024.0; index++ }
            return String.format(Locale.ROOT, "%.2f %s", amount, units[index])
        }
    }
}

private data class GgufInspection(
    val version: Int,
    val architecture: String,
    val name: String?,
    val tensorCount: Long,
    val fileType: Long?,
    val tokenizerModel: String?,
    val hasChatTemplate: Boolean,
    val contextLength: Long?,
    val blockCount: Long?,
    val embeddingLength: Long?,
    val headCount: Long?,
    val headCountKv: Long?,
    val keyLength: Long?,
    val valueLength: Long?,
    val expertCount: Long?,
    val expertUsedCount: Long?,
    val fileBytes: Long,
    val metadataBytesRead: Long
) {
    val isMoE: Boolean get() = (expertCount ?: 0L) > 0L

    fun toJson(): JSONObject = JSONObject()
        .put("format", "gguf")
        .put("version", version)
        .put("architecture", architecture)
        .put("name", name ?: JSONObject.NULL)
        .put("tensorCount", tensorCount)
        .put("fileType", fileType ?: JSONObject.NULL)
        .put("tokenizerModel", tokenizerModel ?: JSONObject.NULL)
        .put("hasChatTemplate", hasChatTemplate)
        .put("contextLength", contextLength ?: JSONObject.NULL)
        .put("blockCount", blockCount ?: JSONObject.NULL)
        .put("embeddingLength", embeddingLength ?: JSONObject.NULL)
        .put("headCount", headCount ?: JSONObject.NULL)
        .put("headCountKv", headCountKv ?: JSONObject.NULL)
        .put("keyLength", keyLength ?: JSONObject.NULL)
        .put("valueLength", valueLength ?: JSONObject.NULL)
        .put("expertCount", expertCount ?: JSONObject.NULL)
        .put("expertUsedCount", expertUsedCount ?: JSONObject.NULL)
        .put("isMoE", isMoE)
        .put("fileBytes", fileBytes)
        .put("metadataBytesRead", metadataBytesRead)
}

private class GgufInspectionException(message: String, val code: String) : Exception(message)

/** A bounded metadata-only GGUF v2/v3 reader; tensor payloads are never decoded. */
private object GgufHeaderInspector {
    private const val MAX_METADATA_BYTES = 16L * 1024L * 1024L
    private const val MAX_METADATA_ENTRIES = 100_000L
    private const val MAX_STRING_BYTES = 1L * 1024L * 1024L
    private const val MAX_ARRAY_ELEMENTS = 1_000_000L
    private const val MAX_TENSORS = 1_000_000L
    private val fixedWidths = mapOf(0 to 1L, 1 to 1L, 2 to 2L, 3 to 2L, 4 to 4L, 5 to 4L, 6 to 4L, 7 to 1L, 10 to 8L, 11 to 8L, 12 to 8L)

    fun inspect(file: File): GgufInspection = RandomAccessFile(file, "r").use { input ->
        if (input.length() < 24L) throw GgufInspectionException("Selected file is too small to be GGUF.", "GGUF_TRUNCATED")
        val magic = ByteArray(4)
        input.readFully(magic)
        if (String(magic, Charsets.US_ASCII) != "GGUF") throw GgufInspectionException("Selected file is not GGUF (magic header mismatch).", "GGUF_MAGIC")
        val version = readU32(input).toInt()
        if (version !in 2..3) throw GgufInspectionException("GGUF version $version is not supported by this inspector.", "GGUF_VERSION")
        val tensors = readU64(input)
        val metadataCount = readU64(input)
        if (tensors !in 1..MAX_TENSORS) throw GgufInspectionException("GGUF tensor count is outside Apollo's inspection limits.", "GGUF_LIMIT")
        if (metadataCount !in 1..MAX_METADATA_ENTRIES) throw GgufInspectionException("GGUF metadata count is outside Apollo's inspection limits.", "GGUF_LIMIT")
        val metadataEnd = minOf(input.length(), MAX_METADATA_BYTES)
        val metadata = HashMap<String, Any?>()
        repeat(metadataCount.toInt()) {
            val key = readString(input, metadataEnd)
            if (key.isEmpty() || key.length > 65535 || key.any { it.code !in 0x20..0x7e }) {
                throw GgufInspectionException("GGUF metadata key is not valid ASCII.", "GGUF_KEY")
            }
            val type = readU32(input).toInt()
            metadata[key] = readValue(input, type, metadataEnd, 0)
            ensureWithinMetadata(input, metadataEnd)
        }
        val architecture = metadata["general.architecture"] as? String
            ?: throw GgufInspectionException("GGUF has no valid general.architecture field.", "GGUF_ARCHITECTURE")
        if (!architecture.matches(Regex("^[A-Za-z0-9._-]{1,80}$"))) {
            throw GgufInspectionException("GGUF architecture name is invalid.", "GGUF_ARCHITECTURE")
        }
        fun number(suffix: String): Long? = (metadata["$architecture.$suffix"] as? Number)?.toLong()?.takeIf { it > 0L }
        GgufInspection(
            version = version,
            architecture = architecture,
            name = (metadata["general.name"] as? String)?.take(240),
            tensorCount = tensors,
            fileType = (metadata["general.file_type"] as? Number)?.toLong(),
            tokenizerModel = (metadata["tokenizer.ggml.model"] as? String)?.take(120),
            hasChatTemplate = ((metadata["tokenizer.chat_template"] as? String)?.isNotEmpty() == true),
            contextLength = number("context_length")?.coerceAtMost(131072L),
            blockCount = number("block_count")?.coerceAtMost(4096L),
            embeddingLength = number("embedding_length")?.coerceAtMost(1_000_000L),
            headCount = number("attention.head_count")?.coerceAtMost(4096L),
            headCountKv = number("attention.head_count_kv")?.coerceAtMost(4096L),
            keyLength = number("attention.key_length")?.coerceAtMost(65536L),
            valueLength = number("attention.value_length")?.coerceAtMost(65536L),
            expertCount = number("expert_count")?.coerceAtMost(100000L),
            expertUsedCount = number("expert_used_count")?.coerceAtMost(100000L),
            fileBytes = input.length(),
            metadataBytesRead = input.filePointer - 24L
        )
    }

    private fun readValue(input: RandomAccessFile, type: Int, limit: Long, depth: Int): Any? {
        if (depth > 8) throw GgufInspectionException("GGUF metadata nesting is too deep.", "GGUF_LIMIT")
        return when (type) {
            0 -> readU8(input).toLong()
            1 -> input.readByte().toLong()
            2 -> readU16(input).toLong()
            3 -> readI16(input).toLong()
            4 -> readU32(input)
            5 -> readI32(input).toLong()
            6 -> java.lang.Float.intBitsToFloat(readI32(input)).toDouble()
            7 -> {
                val value = readU8(input)
                if (value !in 0..1) throw GgufInspectionException("GGUF boolean metadata is invalid.", "GGUF_VALUE")
                value == 1
            }
            8 -> readString(input, limit)
            9 -> { skipArray(input, limit, depth + 1); null }
            10 -> readU64(input)
            11 -> readI64(input)
            12 -> java.lang.Double.longBitsToDouble(readI64(input))
            else -> throw GgufInspectionException("GGUF metadata type $type is unsupported.", "GGUF_TYPE")
        }
    }

    private fun skipArray(input: RandomAccessFile, limit: Long, depth: Int) {
        if (depth > 8) throw GgufInspectionException("GGUF metadata nesting is too deep.", "GGUF_LIMIT")
        val elementType = readU32(input).toInt()
        val count = readU64(input)
        if (count !in 0..MAX_ARRAY_ELEMENTS) throw GgufInspectionException("GGUF array length is outside Apollo's inspection limits.", "GGUF_LIMIT")
        if (elementType == 8) {
            repeat(count.toInt()) { skipString(input, limit) }
            return
        }
        if (elementType == 9) {
            repeat(count.toInt()) { skipArray(input, limit, depth + 1) }
            return
        }
        val width = fixedWidths[elementType] ?: throw GgufInspectionException("GGUF array type $elementType is unsupported.", "GGUF_TYPE")
        val bytes = try { Math.multiplyExact(count, width) } catch (_: ArithmeticException) {
            throw GgufInspectionException("GGUF array byte length overflowed.", "GGUF_LIMIT")
        }
        seekForward(input, bytes, limit)
    }

    private fun readString(input: RandomAccessFile, limit: Long): String {
        val length = readU64(input)
        if (length !in 0..MAX_STRING_BYTES) throw GgufInspectionException("GGUF string exceeds Apollo's inspection limit.", "GGUF_LIMIT")
        ensureRange(input, length, limit)
        val data = ByteArray(length.toInt())
        input.readFully(data)
        return try {
            Charsets.UTF_8.newDecoder().decode(java.nio.ByteBuffer.wrap(data)).toString()
        } catch (_: Exception) {
            throw GgufInspectionException("GGUF contains invalid UTF-8 metadata.", "GGUF_ENCODING")
        }
    }

    private fun skipString(input: RandomAccessFile, limit: Long) {
        val length = readU64(input)
        if (length !in 0..MAX_STRING_BYTES) throw GgufInspectionException("GGUF string exceeds Apollo's inspection limit.", "GGUF_LIMIT")
        seekForward(input, length, limit)
    }

    private fun readU8(input: RandomAccessFile): Int = input.readUnsignedByte()
    private fun readU16(input: RandomAccessFile): Int = readU8(input) or (readU8(input) shl 8)
    private fun readI16(input: RandomAccessFile): Short = readU16(input).toShort()
    private fun readU32(input: RandomAccessFile): Long = readU8(input).toLong() or (readU8(input).toLong() shl 8) or (readU8(input).toLong() shl 16) or (readU8(input).toLong() shl 24)
    private fun readI32(input: RandomAccessFile): Int = readU32(input).toInt()
    private fun readI64(input: RandomAccessFile): Long {
        var result = 0L
        repeat(8) { result = result or (readU8(input).toLong() shl (8 * it)) }
        return result
    }
    private fun readU64(input: RandomAccessFile): Long {
        val value = readI64(input)
        if (value < 0L) throw GgufInspectionException("GGUF integer exceeds Apollo's safe inspection range.", "GGUF_LIMIT")
        return value
    }
    private fun ensureRange(input: RandomAccessFile, bytes: Long, limit: Long) {
        if (bytes < 0L || input.filePointer > limit - bytes || input.filePointer > input.length() - bytes) {
            throw GgufInspectionException("GGUF metadata is truncated or exceeds the inspection window.", "GGUF_TRUNCATED")
        }
    }
    private fun seekForward(input: RandomAccessFile, bytes: Long, limit: Long) {
        ensureRange(input, bytes, limit)
        input.seek(input.filePointer + bytes)
    }
    private fun ensureWithinMetadata(input: RandomAccessFile, limit: Long) {
        if (input.filePointer > limit) throw GgufInspectionException("GGUF metadata exceeds Apollo's 16 MiB inspection window.", "GGUF_LIMIT")
    }
}
