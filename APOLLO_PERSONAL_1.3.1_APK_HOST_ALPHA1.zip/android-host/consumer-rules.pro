# JNI looks up these method names and the callback interface at runtime.
-keep class com.atlaslibrary.apollo.model.ApolloLlamaCppRuntime { *; }
-keep interface com.atlaslibrary.apollo.model.ApolloLlamaCppRuntime$TokenListener { *; }
-keep class com.atlaslibrary.apollo.model.ApolloSleepingGiantBridge { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

-keepclassmembers class * implements com.atlaslibrary.apollo.model.ApolloLlamaCppRuntime$TokenListener {
    public void onToken(java.lang.String);
}
