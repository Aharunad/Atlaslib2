# Apollo Android host — native Sleeping Giant integration

This directory is a Gradle multi-project build:

- Root project `:` is the reusable Android library containing the GGUF/llama.cpp integration and SAF bridge.
- `:host-app` is a small installable development host that mounts the Apollo web feature in a secure WebView.

The production destination is still integrating the root library into Atlas Library. The host APK is only a test harness for validating Apollo on a real phone.

## Build requirements

- JDK 17
- System Gradle 8.11.1 (there is intentionally no Gradle wrapper in this alpha)
- Android Gradle Plugin 8.9.2 / Kotlin 2.1.20
- Android SDK platform 35 / build tools 35.0.0
- Android NDK 29.0.13113456
- CMake 3.31.6
- ARM64 (`arm64-v8a`)

## Build

The root Android library expects the pinned llama.cpp checkout at:

`android-host/third_party/llama.cpp`

Checkout revision `785322d17f2d51e5185cf996a1f4e46d87640841`, then run from the repository root:

```bash
gradle -p android-host :host-app:assembleDebug --no-daemon --max-workers=2
```

The APK is written to:

`android-host/host-app/build/outputs/apk/debug/host-app-debug.apk`

The host app copies `demo/` and `src/` into its private assets directory using a Gradle `Sync` task, preserving relative module paths. `WebViewAssetLoader` serves them from `https://appassets.androidplatform.net/assets/`. The WebView blocks external origins, file access and mixed content.

The Android document picker is registered in the `ComponentActivity` during `onCreate`, before the Activity reaches STARTED. The native bridge is attached only to the trusted appassets origin.

## Model behavior

The user selects one GGUF file. The native bridge copies it into app-private storage, hashes and verifies it, loads the exact file through llama.cpp, then requires a successful non-empty smoke generation before marking it active. The original selected file is never deleted. GGUF weights are never bundled into the APK.
