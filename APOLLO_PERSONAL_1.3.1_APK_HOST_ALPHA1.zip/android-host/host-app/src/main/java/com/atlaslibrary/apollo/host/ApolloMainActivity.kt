package com.atlaslibrary.apollo.host

import android.graphics.Color
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.ComponentActivity
import androidx.webkit.WebViewAssetLoader
import com.atlaslibrary.apollo.model.ApolloSleepingGiantBridge
import java.io.ByteArrayInputStream

/**
 * Installable development host for the Apollo feature module.
 * The production destination remains mounting the Apollo library inside Atlas Library.
 */
class ApolloMainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private var sleepingGiantBridge: ApolloSleepingGiantBridge? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this).apply {
            setBackgroundColor(Color.WHITE)
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = false
                allowFileAccess = false
                allowContentAccess = false
                allowFileAccessFromFileURLs = false
                allowUniversalAccessFromFileURLs = false
                javaScriptCanOpenWindowsAutomatically = false
                setSupportMultipleWindows(false)
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                loadsImagesAutomatically = true
                safeBrowsingEnabled = true
            }
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView?,
                    request: WebResourceRequest
                ): WebResourceResponse? {
                    val uri = request.url
                    if (uri.scheme == "https" && uri.host == TRUSTED_HOST) {
                        return assetLoader.shouldInterceptRequest(uri) ?: WebResourceResponse(
                            "text/plain", "UTF-8", 404, "Not Found",
                            mapOf("Cache-Control" to "no-store"),
                            ByteArrayInputStream(ByteArray(0))
                        )
                    }
                    return WebResourceResponse(
                        "text/plain", "UTF-8", 403, "Blocked",
                        mapOf("Cache-Control" to "no-store"),
                        ByteArrayInputStream(ByteArray(0))
                    )
                }

                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest
                ): Boolean {
                    val uri = request.url
                    return uri.scheme != "https" || uri.host != TRUSTED_HOST
                }
            }
        }

        // Register the Android document picker bridge during onCreate, before STARTED.
        sleepingGiantBridge = ApolloSleepingGiantBridge(
            activity = this,
            webView = webView,
            trustedOriginHost = TRUSTED_HOST
        )

        setContentView(webView)
        webView.loadUrl(APOLLO_START_URL)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else finish()
            }
        })
    }

    override fun onDestroy() {
        sleepingGiantBridge?.close()
        sleepingGiantBridge = null
        if (::webView.isInitialized) {
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }

    private companion object {
        const val TRUSTED_HOST = "appassets.androidplatform.net"
        const val APOLLO_START_URL = "https://appassets.androidplatform.net/assets/demo/apollo-personal/index.html"
    }
}
