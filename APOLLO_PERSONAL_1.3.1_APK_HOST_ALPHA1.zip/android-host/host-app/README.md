# Apollo Personal test APK host

This is an installable development shell for testing the Apollo feature on a physical Android device. It mounts the existing Apollo web feature through AndroidX WebViewAssetLoader and attaches the native Sleeping Giant bridge from the `android-host` Android library.

The production architecture remains unchanged: Apollo is a feature inside Atlas Library. This standalone APK is a test harness, not a replacement for the Atlas Library application.

The host accepts only its app-private HTTPS-like WebViewAssetLoader origin. External navigation and external subresource requests are blocked. The selected GGUF remains a separate user-provided file and is copied into app-private storage by the native bridge.
