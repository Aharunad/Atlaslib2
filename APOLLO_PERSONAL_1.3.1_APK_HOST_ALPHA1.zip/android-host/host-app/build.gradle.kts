import org.gradle.api.tasks.Sync

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.atlaslibrary.apollo.host"
    compileSdk = 35
    ndkVersion = "29.0.13113456"

    defaultConfig {
        applicationId = "com.atlaslibrary.apollo.personal"
        minSdk = 28
        targetSdk = 35
        versionCode = 13031
        versionName = "1.3.1-alpha1"
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation(project(":"))
    implementation("androidx.webkit:webkit:1.12.1")
}


// Keep the WebView module paths identical to the source tree so relative ES-module
// imports and the service-worker precache resolve under the private appassets origin.
val syncApolloWebAssets by tasks.registering(Sync::class) {
    from(rootProject.projectDir.parentFile.resolve("demo")) { into("demo") }
    from(rootProject.projectDir.parentFile.resolve("src")) { into("src") }
    from(rootProject.projectDir.parentFile.resolve("THIRD_PARTY_NOTICES.md")) {
        rename { "THIRD_PARTY_NOTICES.md" }
    }
    into(layout.projectDirectory.dir("src/main/assets"))
}

tasks.named("preBuild").configure {
    dependsOn(syncApolloWebAssets)
}
