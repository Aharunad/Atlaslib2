#include <jni.h>
#include <llama.h>

#include <algorithm>
#include <chrono>
#include <atomic>
#include <cstdint>
#include <cstring>
#include <cmath>
#include <climits>
#include <stdexcept>
#include <memory>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>

namespace {

struct Session {
    llama_model * model = nullptr;
    llama_context * context = nullptr;
    const llama_vocab * vocab = nullptr;
    uint32_t context_tokens = 0;
    uint32_t batch_tokens = 0;
    std::atomic<uint64_t> last_prompt_tokens{0};
    std::atomic<uint64_t> last_generated_tokens{0};
    std::atomic<int64_t> last_prompt_micros{0};
    std::atomic<int64_t> last_generation_micros{0};
    std::atomic<bool> cancelled{false};
    std::atomic<bool> closing{false};
    std::mutex operation_mutex;

    ~Session() {
        if (context) llama_free(context);
        if (model) llama_model_free(model);
    }
};

bool abort_if_cancelled(void * user_data) {
    const auto * session = static_cast<const Session *>(user_data);
    return session == nullptr || session->cancelled.load(std::memory_order_relaxed);
}

std::once_flag g_backend_once;
std::mutex g_sessions_mutex;
std::unordered_map<jlong, std::shared_ptr<Session>> g_sessions;
std::atomic<jlong> g_next_session{1};
std::atomic<uint32_t> g_sampler_seed{0x41504f4c};

// General JSON grammar used for Apollo's structured controller/editor contracts.
// The higher-level adapters still validate required fields and reject malformed schemas.
constexpr const char * kJsonObjectGrammar = R"GBNF(root   ::= object
value  ::= object | array | string | number | ("true" | "false" | "null") ws

object ::= "{" ws (
            string ":" ws value
    ("," ws string ":" ws value)*
  )? "}" ws

array  ::= "[" ws (
            value
    ("," ws value)*
  )? "]" ws

string ::= "\"" (
    [^"\\\x7F\x00-\x1F] |
    "\\" (["\\bfnrt] | "u" [0-9a-fA-F]{4})
  )* "\"" ws

number ::= ("-"? ([0-9] | [1-9] [0-9]{0,15})) ("." [0-9]+)? ([eE] [-+]? [0-9] [1-9]{0,15})? ws
ws ::= | " " | "\n" [ \t]{0,20}
)GBNF";

void throw_java(JNIEnv * env, const char * class_name, const std::string & message) {
    jclass type = env->FindClass(class_name);
    if (type) env->ThrowNew(type, message.c_str());
}

void throw_state(JNIEnv * env, const std::string & message) {
    throw_java(env, "java/lang/IllegalStateException", message);
}

void append_utf8(std::string & output, uint32_t cp) {
    if (cp <= 0x7f) output.push_back(static_cast<char>(cp));
    else if (cp <= 0x7ff) {
        output.push_back(static_cast<char>(0xc0 | (cp >> 6)));
        output.push_back(static_cast<char>(0x80 | (cp & 0x3f)));
    } else if (cp <= 0xffff) {
        output.push_back(static_cast<char>(0xe0 | (cp >> 12)));
        output.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3f)));
        output.push_back(static_cast<char>(0x80 | (cp & 0x3f)));
    } else {
        output.push_back(static_cast<char>(0xf0 | (cp >> 18)));
        output.push_back(static_cast<char>(0x80 | ((cp >> 12) & 0x3f)));
        output.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3f)));
        output.push_back(static_cast<char>(0x80 | (cp & 0x3f)));
    }
}

std::string java_to_utf8(JNIEnv * env, jstring value) {
    const jsize length = env->GetStringLength(value);
    const jchar * chars = env->GetStringChars(value, nullptr);
    if (!chars) throw std::runtime_error("Java string could not be read");
    std::string output;
    output.reserve(static_cast<size_t>(length) * 3);
    for (jsize i = 0; i < length; ++i) {
        uint32_t cp = chars[i];
        if (cp >= 0xd800 && cp <= 0xdbff && i + 1 < length && chars[i + 1] >= 0xdc00 && chars[i + 1] <= 0xdfff) {
            cp = 0x10000 + ((cp - 0xd800) << 10) + (static_cast<uint32_t>(chars[++i]) - 0xdc00);
        } else if (cp >= 0xd800 && cp <= 0xdfff) {
            cp = 0xfffd;
        }
        append_utf8(output, cp);
    }
    env->ReleaseStringChars(value, chars);
    return output;
}

size_t complete_utf8_prefix(const std::string & input) {
    size_t i = 0;
    while (i < input.size()) {
        const uint8_t first = static_cast<uint8_t>(input[i]);
        size_t width = 0;
        if (first <= 0x7f) width = 1;
        else if (first >= 0xc2 && first <= 0xdf) width = 2;
        else if (first >= 0xe0 && first <= 0xef) width = 3;
        else if (first >= 0xf0 && first <= 0xf4) width = 4;
        else width = 1; // Invalid leading bytes are replaced by the Java conversion helper.
        if (width > 1 && i + width > input.size()) break;
        bool valid = true;
        for (size_t j = 1; j < width; ++j) {
            const uint8_t next = static_cast<uint8_t>(input[i + j]);
            if ((next & 0xc0) != 0x80) { valid = false; break; }
        }
        if (valid && width == 3) {
            const uint8_t second = static_cast<uint8_t>(input[i + 1]);
            if ((first == 0xe0 && second < 0xa0) || (first == 0xed && second >= 0xa0)) valid = false;
        }
        if (valid && width == 4) {
            const uint8_t second = static_cast<uint8_t>(input[i + 1]);
            if ((first == 0xf0 && second < 0x90) || (first == 0xf4 && second > 0x8f)) valid = false;
        }
        if (!valid) width = 1;
        i += width;
    }
    return i;
}

jstring utf8_to_java(JNIEnv * env, const std::string & input) {
    std::vector<jchar> output;
    output.reserve(input.size());
    size_t i = 0;
    while (i < input.size()) {
        const uint8_t first = static_cast<uint8_t>(input[i++]);
        uint32_t cp = 0xfffd;
        size_t continuation = 0;
        if (first <= 0x7f) { cp = first; continuation = 0; }
        else if ((first & 0xe0) == 0xc0) { cp = first & 0x1f; continuation = 1; }
        else if ((first & 0xf0) == 0xe0) { cp = first & 0x0f; continuation = 2; }
        else if ((first & 0xf8) == 0xf0) { cp = first & 0x07; continuation = 3; }
        bool valid = i + continuation <= input.size();
        for (size_t j = 0; valid && j < continuation; ++j) {
            const uint8_t next = static_cast<uint8_t>(input[i++]);
            if ((next & 0xc0) != 0x80) { valid = false; break; }
            cp = (cp << 6) | (next & 0x3f);
        }
        if (!valid || cp > 0x10ffff || (cp >= 0xd800 && cp <= 0xdfff)) cp = 0xfffd;
        if (cp <= 0xffff) output.push_back(static_cast<jchar>(cp));
        else {
            cp -= 0x10000;
            output.push_back(static_cast<jchar>(0xd800 + (cp >> 10)));
            output.push_back(static_cast<jchar>(0xdc00 + (cp & 0x3ff)));
        }
    }
    return env->NewString(output.data(), static_cast<jsize>(output.size()));
}

std::shared_ptr<Session> find_session(jlong id) {
    std::lock_guard<std::mutex> lock(g_sessions_mutex);
    const auto it = g_sessions.find(id);
    return it == g_sessions.end() ? nullptr : it->second;
}

std::string from_java(JNIEnv * env, jstring value, size_t maximum, const char * label) {
    if (!value) throw std::runtime_error(std::string(label) + " is null");
    std::string result = java_to_utf8(env, value);
    if (result.empty() || result.size() > maximum) throw std::runtime_error(std::string(label) + " is empty or exceeds its limit");
    return result;
}

std::vector<llama_chat_message> read_messages(JNIEnv * env, jobjectArray roles, jobjectArray contents,
                                               std::vector<std::string> & role_storage,
                                               std::vector<std::string> & content_storage) {
    if (!roles || !contents) throw std::runtime_error("Chat messages are missing");
    const jsize role_count = env->GetArrayLength(roles);
    const jsize content_count = env->GetArrayLength(contents);
    if (role_count < 1 || role_count > 32 || role_count != content_count) {
        throw std::runtime_error("Chat must contain 1 to 32 matching role/content messages");
    }
    role_storage.reserve(static_cast<size_t>(role_count));
    content_storage.reserve(static_cast<size_t>(content_count));
    size_t total_bytes = 0;
    for (jsize i = 0; i < role_count; ++i) {
        auto role_obj = static_cast<jstring>(env->GetObjectArrayElement(roles, i));
        auto content_obj = static_cast<jstring>(env->GetObjectArrayElement(contents, i));
        std::string role = from_java(env, role_obj, 16, "Message role");
        std::string content = from_java(env, content_obj, 48 * 1024, "Message content");
        if (role != "system" && role != "user" && role != "assistant") {
            throw std::runtime_error("Unsupported chat role");
        }
        total_bytes += role.size() + content.size();
        if (total_bytes > 128 * 1024) throw std::runtime_error("Chat history exceeds the 128 KiB native limit");
        role_storage.emplace_back(std::move(role));
        content_storage.emplace_back(std::move(content));
        env->DeleteLocalRef(role_obj);
        env->DeleteLocalRef(content_obj);
    }
    std::vector<llama_chat_message> messages;
    messages.reserve(static_cast<size_t>(role_count));
    for (jsize i = 0; i < role_count; ++i) {
        messages.push_back({role_storage[static_cast<size_t>(i)].c_str(), content_storage[static_cast<size_t>(i)].c_str()});
    }
    return messages;
}

std::vector<llama_token> tokenize(const llama_vocab * vocab, const std::string & prompt) {
    if (prompt.size() > static_cast<size_t>(INT32_MAX)) throw std::runtime_error("Prompt exceeds tokenizer limits");
    int32_t required = llama_tokenize(vocab, prompt.data(), static_cast<int32_t>(prompt.size()), nullptr, 0, true, false);
    if (required == INT32_MIN) throw std::runtime_error("Prompt token count overflowed");
    if (required >= 0) {
        if (required == 0) throw std::runtime_error("Prompt contains no tokens");
    } else {
        required = -required;
    }
    if (required <= 0 || required > 1'000'000) throw std::runtime_error("Prompt token count is outside runtime limits");
    std::vector<llama_token> tokens(static_cast<size_t>(required));
    const int32_t actual = llama_tokenize(vocab, prompt.data(), static_cast<int32_t>(prompt.size()),
                                          tokens.data(), required, true, false);
    if (actual < 0 || actual > required) throw std::runtime_error("Prompt tokenization failed");
    tokens.resize(static_cast<size_t>(actual));
    return tokens;
}

std::string format_chat(const Session & session, const std::vector<llama_chat_message> & messages) {
    const char * chat_template = llama_model_chat_template(session.model, nullptr);
    if (!chat_template || !*chat_template) {
        std::string fallback;
        for (const auto & message : messages) {
            fallback += message.role;
            fallback += ": ";
            fallback += message.content;
            fallback += "\n";
        }
        fallback += "assistant: ";
        return fallback;
    }
    constexpr int32_t kMaxFormattedPrompt = 512 * 1024;
    std::vector<char> buffer(static_cast<size_t>(kMaxFormattedPrompt));
    const int32_t written = llama_chat_apply_template(chat_template, messages.data(), messages.size(), true,
                                                       buffer.data(), static_cast<int32_t>(buffer.size()));
    if (written < 0 || written >= kMaxFormattedPrompt) throw std::runtime_error("Model chat template failed or exceeded 512 KiB");
    return std::string(buffer.data(), static_cast<size_t>(written));
}

bool decode_prompt(Session & session, const std::vector<llama_token> & tokens) {
    llama_batch batch = llama_batch_init(static_cast<int32_t>(session.batch_tokens), 0, 1);
    if (!batch.token || !batch.pos || !batch.n_seq_id || !batch.seq_id || !batch.logits) {
        llama_batch_free(batch);
        throw std::runtime_error("llama.cpp could not allocate the prompt batch");
    }
    int32_t offset = 0;
    while (offset < static_cast<int32_t>(tokens.size())) {
        const int32_t count = std::min<int32_t>(static_cast<int32_t>(session.batch_tokens),
                                               static_cast<int32_t>(tokens.size()) - offset);
        batch.n_tokens = count;
        for (int32_t i = 0; i < count; ++i) {
            const int32_t index = offset + i;
            batch.token[i] = tokens[static_cast<size_t>(index)];
            batch.pos[i] = index;
            batch.n_seq_id[i] = 1;
            batch.seq_id[i][0] = 0;
            batch.logits[i] = (i == count - 1) ? 1 : 0;
        }
        const int32_t result = llama_decode(session.context, batch);
        if (result != 0) {
            llama_batch_free(batch);
            if (session.cancelled.load(std::memory_order_relaxed)) return false;
            throw std::runtime_error("llama.cpp prompt decode failed with code " + std::to_string(result));
        }
        offset += count;
    }
    llama_batch_free(batch);
    return true;
}

std::string json_escape(const std::string & input) {
    std::string output;
    output.reserve(input.size() + 8);
    for (unsigned char ch : input) {
        switch (ch) {
            case '"': output += "\\\""; break;
            case '\\': output += "\\\\"; break;
            case '\b': output += "\\b"; break;
            case '\f': output += "\\f"; break;
            case '\n': output += "\\n"; break;
            case '\r': output += "\\r"; break;
            case '\t': output += "\\t"; break;
            default:
                if (ch < 0x20) {
                    static const char hex[] = "0123456789abcdef";
                    output += "\\u00";
                    output.push_back(hex[(ch >> 4) & 0x0f]);
                    output.push_back(hex[ch & 0x0f]);
                } else {
                    output.push_back(static_cast<char>(ch));
                }
        }
    }
    return output;
}

std::string token_piece(const llama_vocab * vocab, llama_token token) {
    std::vector<char> buffer(256);
    int32_t size = llama_token_to_piece(vocab, token, buffer.data(), static_cast<int32_t>(buffer.size()), 0, false);
    if (size < 0) {
        const int32_t required = -size;
        if (required <= 0 || required > 64 * 1024) throw std::runtime_error("Token piece exceeds runtime limits");
        buffer.resize(static_cast<size_t>(required));
        size = llama_token_to_piece(vocab, token, buffer.data(), required, 0, false);
    }
    if (size < 0 || size > static_cast<int32_t>(buffer.size())) throw std::runtime_error("Token conversion failed");
    return std::string(buffer.data(), static_cast<size_t>(size));
}

} // namespace

extern "C" JNIEXPORT jstring JNICALL
Java_com_atlaslibrary_apollo_model_ApolloLlamaCppRuntime_nativeVersion(JNIEnv * env, jobject) {
    try {
        std::call_once(g_backend_once, [] { llama_backend_init(); });
        const char * version = llama_version();
        return utf8_to_java(env, version ? version : "unknown");
    } catch (const std::exception & error) {
        throw_state(env, error.what());
        return nullptr;
    }
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_atlaslibrary_apollo_model_ApolloLlamaCppRuntime_nativeLoad(JNIEnv * env, jobject,
                                                                     jstring model_path,
                                                                     jint context_tokens,
                                                                     jint threads,
                                                                     jint batch_tokens) {
    try {
        if (context_tokens < 256 || context_tokens > 131072) throw std::runtime_error("Context must be between 256 and 131072 tokens");
        if (threads < 1 || threads > 32) throw std::runtime_error("CPU thread count must be between 1 and 32");
        if (batch_tokens < 8 || batch_tokens > 512) throw std::runtime_error("Batch size must be between 8 and 512 tokens");
        const std::string path = from_java(env, model_path, 4096, "Private model path");
        std::call_once(g_backend_once, [] { llama_backend_init(); });

        auto session = std::make_shared<Session>();
        llama_model_params model_params = llama_model_default_params();
        model_params.n_gpu_layers = 0; // CPU-only baseline. GPU offload needs a separate device qualification.
        model_params.check_tensors = true;
        session->model = llama_model_load_from_file(path.c_str(), model_params);
        if (!session->model) throw std::runtime_error("llama.cpp could not load this GGUF architecture or tensor layout");

        const int32_t train_context = llama_model_n_ctx_train(session->model);
        if (train_context > 0 && context_tokens > train_context) {
            throw std::runtime_error("Requested context exceeds the model's trained context limit");
        }
        session->context_tokens = static_cast<uint32_t>(context_tokens);
        session->batch_tokens = static_cast<uint32_t>(batch_tokens);
        session->vocab = llama_model_get_vocab(session->model);
        if (!session->vocab) throw std::runtime_error("Model did not expose a tokenizer vocabulary");

        llama_context_params context_params = llama_context_default_params();
        context_params.n_ctx = session->context_tokens;
        context_params.n_batch = session->batch_tokens;
        context_params.n_ubatch = std::min<uint32_t>(session->batch_tokens, 32);
        context_params.n_seq_max = 1;
        context_params.n_threads = threads;
        context_params.n_threads_batch = threads;
        context_params.offload_kqv = false;
        context_params.abort_callback = abort_if_cancelled;
        context_params.abort_callback_data = session.get();
        session->context = llama_init_from_model(session->model, context_params);
        if (!session->context) throw std::runtime_error("llama.cpp could not allocate the inference context");

        const jlong id = g_next_session.fetch_add(1);
        {
            std::lock_guard<std::mutex> lock(g_sessions_mutex);
            g_sessions.emplace(id, std::move(session));
        }
        return id;
    } catch (const std::exception & error) {
        throw_state(env, error.what());
        return 0;
    }
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_atlaslibrary_apollo_model_ApolloLlamaCppRuntime_nativeModelInfo(JNIEnv * env, jobject, jlong id) {
    auto session = find_session(id);
    if (!session) { throw_state(env, "Native model session does not exist"); return nullptr; }
    char description[512] = {};
    llama_model_desc(session->model, description, sizeof(description));
    const uint64_t model_bytes = llama_model_size(session->model);
    const uint64_t params = llama_model_n_params(session->model);
    const uint64_t prompt_tokens = session->last_prompt_tokens.load(std::memory_order_relaxed);
    const uint64_t generated_tokens = session->last_generated_tokens.load(std::memory_order_relaxed);
    const int64_t prompt_us = session->last_prompt_micros.load(std::memory_order_relaxed);
    const int64_t generation_us = session->last_generation_micros.load(std::memory_order_relaxed);
    const double prompt_tps = prompt_us > 0 ? static_cast<double>(prompt_tokens) * 1e6 / prompt_us : 0.0;
    const double generation_tps = generation_us > 0 ? static_cast<double>(generated_tokens) * 1e6 / generation_us : 0.0;
    std::string json = "{\"description\":\"" + json_escape(description) + "\",\"modelBytes\":" +
        std::to_string(model_bytes) + ",\"parameters\":" + std::to_string(params) +
        ",\"contextTokens\":" + std::to_string(llama_n_ctx(session->context)) +
        ",\"layers\":" + std::to_string(llama_model_n_layer(session->model)) +
        ",\"embeddingLength\":" + std::to_string(llama_model_n_embd(session->model)) +
        ",\"kvHeads\":" + std::to_string(llama_model_n_head_kv(session->model)) +
        ",\"backend\":\"cpu\",\"lastPromptTokens\":" + std::to_string(prompt_tokens) +
        ",\"lastGeneratedTokens\":" + std::to_string(generated_tokens) +
        ",\"lastPromptMs\":" + std::to_string(static_cast<double>(prompt_us) / 1000.0) +
        ",\"lastGenerationMs\":" + std::to_string(static_cast<double>(generation_us) / 1000.0) +
        ",\"lastPromptTokensPerSecond\":" + std::to_string(prompt_tps) +
        ",\"lastGenerationTokensPerSecond\":" + std::to_string(generation_tps) + "}";
    return utf8_to_java(env, json);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_atlaslibrary_apollo_model_ApolloLlamaCppRuntime_nativeGenerate(JNIEnv * env, jobject, jlong id,
                                                                         jobjectArray roles,
                                                                         jobjectArray contents,
                                                                         jint max_tokens,
                                                                         jstring response_format,
                                                                         jdouble temperature,
                                                                         jobject token_listener) {
    auto session = find_session(id);
    if (!session) { throw_state(env, "Native model session does not exist"); return nullptr; }
    if (max_tokens < 1 || max_tokens > 8192) { throw_state(env, "Generation limit must be between 1 and 8192 tokens"); return nullptr; }
    if (!std::isfinite(temperature) || temperature < 0.0 || temperature > 2.0) { throw_state(env, "Temperature must be between 0 and 2"); return nullptr; }

    std::string format;
    try {
        if (response_format) format = java_to_utf8(env, response_format);
        if (!format.empty() && format != "json_object") throw std::runtime_error("Only text and json_object response formats are supported by this runtime");
    } catch (const std::exception & error) {
        throw_state(env, error.what());
        return nullptr;
    }

    std::lock_guard<std::mutex> operation(session->operation_mutex);
    if (session->closing.load()) { throw_state(env, "Native model session is closing"); return nullptr; }
    session->cancelled.store(false);
    try {
        std::vector<std::string> role_storage, content_storage;
        auto messages = read_messages(env, roles, contents, role_storage, content_storage);
        auto sampler = std::unique_ptr<llama_sampler, decltype(&llama_sampler_free)>(
            llama_sampler_chain_init(llama_sampler_chain_default_params()), llama_sampler_free);
        if (!sampler) throw std::runtime_error("llama.cpp could not create a sampler chain");
        auto add_sampler = [&](llama_sampler * item) {
            if (!item) throw std::runtime_error("llama.cpp could not initialize a sampler component");
            llama_sampler_chain_add(sampler.get(), item);
        };
        if (format == "json_object") {
            add_sampler(llama_sampler_init_grammar(session->vocab, kJsonObjectGrammar, "root"));
        }
        if (temperature <= 0.001) {
            add_sampler(llama_sampler_init_greedy());
        } else {
            add_sampler(llama_sampler_init_top_k(40));
            add_sampler(llama_sampler_init_top_p(0.9f, 1));
            add_sampler(llama_sampler_init_temp(static_cast<float>(temperature)));
            add_sampler(llama_sampler_init_dist(g_sampler_seed.fetch_add(0x9e3779b9u, std::memory_order_relaxed)));
        }

        const std::string prompt = format_chat(*session, messages);
        const auto tokens = tokenize(session->vocab, prompt);
        if (tokens.size() + static_cast<size_t>(max_tokens) > session->context_tokens) {
            throw std::runtime_error("Prompt plus requested output exceeds the configured context. Reduce chat history or output length.");
        }
        llama_memory_clear(llama_get_memory(session->context), true);
        std::string result;
        const auto prompt_start = std::chrono::steady_clock::now();
        const bool prompt_decoded = decode_prompt(*session, tokens);
        const auto prompt_end = std::chrono::steady_clock::now();
        const int64_t prompt_micros = std::chrono::duration_cast<std::chrono::microseconds>(prompt_end - prompt_start).count();
        session->last_prompt_tokens.store(tokens.size(), std::memory_order_relaxed);
        session->last_prompt_micros.store(prompt_micros, std::memory_order_relaxed);
        session->last_generated_tokens.store(0, std::memory_order_relaxed);
        session->last_generation_micros.store(0, std::memory_order_relaxed);
        if (!prompt_decoded) return utf8_to_java(env, result);

        // Reuse one decode batch for the whole generation. Allocating a llama_batch
        // for every output token creates avoidable heap churn on mobile devices.
        struct BatchDeleter {
            void operator()(llama_batch * batch) const {
                if (batch) {
                    llama_batch_free(*batch);
                    delete batch;
                }
            }
        };
        auto decode_batch = std::unique_ptr<llama_batch, BatchDeleter>(new llama_batch(llama_batch_init(1, 0, 1)));
        if (!decode_batch->token || !decode_batch->pos || !decode_batch->n_seq_id || !decode_batch->seq_id || !decode_batch->logits) {
            throw std::runtime_error("llama.cpp could not allocate a generation batch");
        }

        const auto generation_start = std::chrono::steady_clock::now();
        uint64_t generated_visible_tokens = 0;
        jclass listener_class = token_listener ? env->GetObjectClass(token_listener) : nullptr;
        jmethodID on_token = listener_class ? env->GetMethodID(listener_class, "onToken", "(Ljava/lang/String;)V") : nullptr;
        std::string stream_pending;
        std::string stream_chunk;
        stream_chunk.reserve(128);
        for (jint generated = 0; generated < max_tokens; ++generated) {
            if (session->cancelled.load()) break;
            // llama_sampler_sample applies the chain and accepts the selected token.
            const llama_token token = llama_sampler_sample(sampler.get(), session->context, -1);
            if (token < 0) throw std::runtime_error("llama.cpp sampler returned an invalid token");
            if (llama_vocab_is_eog(session->vocab, token)) break;
            ++generated_visible_tokens;
            const std::string piece = token_piece(session->vocab, token);
            result += piece;
            if (token_listener && on_token && !piece.empty()) {
                stream_pending += piece;
                const size_t ready = complete_utf8_prefix(stream_pending);
                if (ready > 0) {
                    stream_chunk.append(stream_pending, 0, ready);
                    stream_pending.erase(0, ready);
                }
                // Batch small token pieces before crossing JNI and posting to the WebView.
                // This reduces per-token host overhead while keeping output streaming responsive.
                if (stream_chunk.size() >= 64) {
                    jstring token_text = utf8_to_java(env, stream_chunk);
                    env->CallVoidMethod(token_listener, on_token, token_text);
                    env->DeleteLocalRef(token_text);
                    stream_chunk.clear();
                    if (env->ExceptionCheck()) {
                        session->cancelled.store(true);
                        break;
                    }
                }
            }
            if (generated + 1 >= max_tokens) break;
            decode_batch->n_tokens = 1;
            decode_batch->token[0] = token;
            decode_batch->pos[0] = static_cast<llama_pos>(tokens.size() + static_cast<size_t>(generated));
            decode_batch->n_seq_id[0] = 1;
            decode_batch->seq_id[0][0] = 0;
            decode_batch->logits[0] = 1;
            const int32_t decode_result = llama_decode(session->context, *decode_batch);
            if (decode_result != 0) {
                if (session->cancelled.load(std::memory_order_relaxed)) break;
                throw std::runtime_error("llama.cpp generation decode failed with code " + std::to_string(decode_result));
            }
        }
        if (env->ExceptionCheck()) return nullptr;
        if (token_listener && on_token) {
            stream_chunk += stream_pending;
            if (!stream_chunk.empty()) {
                jstring final_chunk = utf8_to_java(env, stream_chunk);
                env->CallVoidMethod(token_listener, on_token, final_chunk);
                env->DeleteLocalRef(final_chunk);
                if (env->ExceptionCheck()) return nullptr;
            }
        }
        const auto generation_end = std::chrono::steady_clock::now();
        const int64_t generation_micros = std::chrono::duration_cast<std::chrono::microseconds>(generation_end - generation_start).count();
        session->last_generated_tokens.store(generated_visible_tokens, std::memory_order_relaxed);
        session->last_generation_micros.store(generation_micros, std::memory_order_relaxed);
        return utf8_to_java(env, result);
    } catch (const std::exception & error) {
        throw_state(env, error.what());
        return nullptr;
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_atlaslibrary_apollo_model_ApolloLlamaCppRuntime_nativeCancel(JNIEnv *, jobject, jlong id) {
    auto session = find_session(id);
    if (session) session->cancelled.store(true);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_atlaslibrary_apollo_model_ApolloLlamaCppRuntime_nativeIsCancelled(JNIEnv *, jobject, jlong id) {
    auto session = find_session(id);
    return session && session->cancelled.load() ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_atlaslibrary_apollo_model_ApolloLlamaCppRuntime_nativeUnload(JNIEnv *, jobject, jlong id) {
    std::shared_ptr<Session> session;
    {
        std::lock_guard<std::mutex> lock(g_sessions_mutex);
        const auto it = g_sessions.find(id);
        if (it == g_sessions.end()) return;
        session = it->second;
        session->closing.store(true);
        session->cancelled.store(true);
        g_sessions.erase(it);
    }
    std::lock_guard<std::mutex> operation(session->operation_mutex);
}
