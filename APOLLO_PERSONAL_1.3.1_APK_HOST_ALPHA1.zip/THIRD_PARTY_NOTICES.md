# Third-party notices

## llama.cpp

Apollo's optional Android native runtime links the open-source `llama.cpp` project from `https://github.com/ggml-org/llama.cpp`.

The build workflow pins revision `785322d17f2d51e5185cf996a1f4e46d87640841` and retrieves the upstream source at build time. The upstream project is distributed under the MIT License. Its `LICENSE` file is included in the checked-out source tree and governs that third-party code.

This Apollo source archive does not vendor llama.cpp source or model weights.


## Arm KleidiAI

The ARM64 Android build enables the optional KleidiAI CPU kernels through the pinned llama.cpp build configuration. That upstream configuration fetches `ARM-software/kleidiai` release `v1.32.0` and verifies its archive with the MD5 integrity value declared by llama.cpp CMake. KleidiAI supplies Apache-2.0 and BSD-3-Clause license texts under its `LICENSES/` directory. The Android test host packages this notice document as a local app asset. Before distributing production binaries, include the exact upstream `Apache-2.0.txt` and `BSD-3-Clause.txt` files from the fetched KleidiAI release alongside the llama.cpp MIT license.
