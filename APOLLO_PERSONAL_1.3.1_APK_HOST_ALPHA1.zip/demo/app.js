import { DreamKernel, DomRenderer } from '../src/index.js';

const kernel = new DreamKernel({
  device: {
    memoryClassMb: 4096,
    reducedMotion: window.matchMedia('(prefers-reduced-motion: reduce)').matches,
    lowPower: false
  }
});

const result = kernel.createExperience({ kind: 'apollo-home', seed: 'apollo-foundation-preview-01' });
const renderer = new DomRenderer({
  root: document.querySelector('#app'),
  animations: result.resourceProfile.animations,
  onAction(action, payload) {
    const event = new CustomEvent('atlas-action', { detail: { action, payload } });
    document.dispatchEvent(event);
  }
});
renderer.render(result.blueprint);

document.addEventListener('atlas-action', event => {
  if (event.detail.action === 'apollo.submit') {
    alert('This is the Dream Kernel visual foundation only. The SLM conversation engine is a later milestone.');
  }
});
