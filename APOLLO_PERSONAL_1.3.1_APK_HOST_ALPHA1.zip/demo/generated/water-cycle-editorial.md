# The Water Cycle

A clear overview of how water moves through the atmosphere, land and oceans.

## Overview

As moist air cools, water vapor condenses into tiny droplets that can form clouds.

*Sources:* [fixture:water-cycle#condensation]

Plants also release water vapor into the atmosphere through transpiration.

*Sources:* [fixture:water-cycle#transpiration]

## How it works

Energy from sunlight causes liquid water at the surface to evaporate into water vapor.

*Sources:* [fixture:water-cycle#evaporation]

Water returns to the surface through precipitation, including rain, snow, sleet and hail.

*Sources:* [fixture:water-cycle#precipitation]

## Important details

Water can collect in lakes and oceans, flow across land, or move through groundwater before cycling again.

*Sources:* [fixture:water-cycle#collection]
