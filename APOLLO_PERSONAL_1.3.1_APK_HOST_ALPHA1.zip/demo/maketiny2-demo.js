import { mkdir, writeFile } from 'node:fs/promises';
import { MakeTiny2Engine, createQuadraticMetaSeed, expandQuadraticMetaSeed, inspectQuadraticChildSeed, generateQuadraticChunk } from '../src/intelligence/maketiny2.js';
import { estimateUtf8Bytes } from '../src/cache/canonical.js';

const engine = new MakeTiny2Engine();
const capabilities = ['science','biology','chemistry','physics','history','mathematics','fact_check','reasoning','causality','context','definitions','examples','terminology','limitations','synthesis','source_review'];
const sections = Array.from({ length: 40 }, (_, i) => `Section ${String(i + 1).padStart(2, '0')}`);
const parameters = {
  taskType: 'article',
  objective: 'Create a richly structured editorial explanation using 16 capability lanes and forty independently generated sections.',
  editorialStyle: 'editorial',
  capabilities,
  sections,
  voiceEnabled: true,
  visualEnabled: false
};
const root = await engine.createRoot({ parameters, generationSeed: 'maketiny-atlas-apollo-demo' });
const tree = await engine.expandTree(root.seed);
const children = tree.nodes.slice(1);
const footprint = await engine.footprint(root.seed, children);

const parentBinary = createQuadraticMetaSeed({ count: 65_536_000n, initial: 7n, firstDifference: 3n, secondDifference: 1n });
const childBinary = await expandQuadraticMetaSeed(parentBinary);
const decoded = await inspectQuadraticChildSeed(childBinary);
const firstChunk = await generateQuadraticChunk(childBinary, { count: 8 });
const view = new DataView(firstChunk.buffer, firstChunk.byteOffset, firstChunk.byteLength);
const firstValues = Array.from({ length: 8 }, (_, index) => Number(view.getBigInt64(index * 8, true)));

const report = {
  release: 'MAKETINY 2.0',
  project: "Apollo's Dream",
  demo: 'parent-seed-to-child-seeds-to-task-plan',
  generatedAt: 'deterministic-fixture',
  apolloFamily: {
    rootSeedId: root.seed.seedId,
    rootSeedBytes: estimateUtf8Bytes(root.seed),
    childSeedCount: children.length,
    generatedChildSeedBytes: footprint.generatedChildSeedBytes,
    totalMaterializedFamilyBytes: footprint.rootSeedBytes + footprint.generatedChildSeedBytes,
    childExpansionFactor: footprint.expansionFactor,
    persistentBytesWhenRegeneratedOnDemand: footprint.persistedBytesIfChildrenAreRegeneratedOnDemand,
    storageAvoidedVsPersistingAll: `${(100 * (1 - footprint.rootSeedBytes / (footprint.rootSeedBytes + footprint.generatedChildSeedBytes))).toFixed(2)}%`,
    roles: [...new Set(tree.nodes.map(node => node.role))]
  },
  nestedQuadraticFixture: {
    parentSeedBytes: parentBinary.byteLength,
    childSeedBytes: childBinary.byteLength,
    seedExpansionFactor: childBinary.byteLength / parentBinary.byteLength,
    representedOutputBytes: Number(decoded.outputBytes),
    representedOutputMiB: Number(decoded.outputBytes) / (1024 * 1024),
    itemCount: Number(decoded.count),
    formula: 'x[n] = 7 + 3n + n(n-1)/2',
    firstEightValues: firstValues,
    fullOutputMaterialized: false,
    historicalScreenshotSeedReproduced: false
  },
  limitations: [
    'This is a representation/family-generation experiment, not a universal compression result.',
    'Knowledge content and model weights remain separate dependencies.',
    'The full 500 MiB quadratic stream was not generated or hashed in this demo.',
    'The historical MAKETINY source and exact historical 118-byte seed were not found in the available Library records.'
  ]
};

await mkdir(new URL('./generated/', import.meta.url), { recursive: true });
await writeFile(new URL('./generated/maketiny2-report.json', import.meta.url), `${JSON.stringify(report, null, 2)}\n`);
await writeFile(new URL('./generated/maketiny2-parent-seed.json', import.meta.url), `${JSON.stringify(root.seed, null, 2)}\n`);
console.log(JSON.stringify(report, null, 2));
