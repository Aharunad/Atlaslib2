import { DreamKernel, createKnowledgePacket, canonicalStringify, ContentAddressedStore, SeedIntelligenceEngine } from '../src/index.js';
import { writeFile, mkdir } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';

const outputDir = resolve('demo/generated');
await mkdir(outputDir, { recursive: true });

const packet = await createKnowledgePacket({
  title: 'Water Cycle — Demonstration Knowledge Fixture',
  metadata: { collection: 'apollo-internal-demo', revision: '1', language: 'en', createdBy: 'test-fixture' },
  claims: [
    { id: 'evaporation', text: 'Energy from sunlight causes liquid water at the surface to evaporate into water vapor.', kind: 'fact', sourceRefs: ['fixture:water-cycle#evaporation'], confidence: 0.99, priority: 95, topic: 'How it works' },
    { id: 'transpiration', text: 'Plants also release water vapor into the atmosphere through transpiration.', kind: 'fact', sourceRefs: ['fixture:water-cycle#transpiration'], confidence: 0.98, priority: 75 },
    { id: 'condensation', text: 'As moist air cools, water vapor condenses into tiny droplets that can form clouds.', kind: 'fact', sourceRefs: ['fixture:water-cycle#condensation'], confidence: 0.99, priority: 90 },
    { id: 'precipitation', text: 'Water returns to the surface through precipitation, including rain, snow, sleet and hail.', kind: 'fact', sourceRefs: ['fixture:water-cycle#precipitation'], confidence: 0.99, priority: 90 },
    { id: 'collection', text: 'Water can collect in lakes and oceans, flow across land, or move through groundwater before cycling again.', kind: 'fact', sourceRefs: ['fixture:water-cycle#collection'], confidence: 0.98, priority: 85 }
  ]
});

const kernel = new DreamKernel({ device: { memoryClassMb: 4096, lowPower: true } });
const compiled = await kernel.compileReasoningSeed({
  request: {
    taskType: 'explain',
    title: 'The Water Cycle',
    objective: 'A clear overview of how water moves through the atmosphere, land and oceans.',
    audience: 'curious general reader',
    editorialStyle: 'editorial',
    language: 'en'
  },
  knowledgePackets: [packet.packet],
  randomSeed: 'apollo-dream-seed-demo-001'
});

const result = await kernel.replayReasoningSeed(compiled.seed, { useCache: false });
const secondReplay = await kernel.replayReasoningSeed(compiled.seed, { useCache: false });
const snapshot = await kernel.seedIntelligence.contentStore.exportSnapshot();
const snapshotStore = new ContentAddressedStore({ maxBytes: 8 * 1024 * 1024 });
const snapshotRestore = await snapshotStore.restoreSnapshot(snapshot);
const replayKernel = new DreamKernel({
  device: { memoryClassMb: 4096, lowPower: true },
  seedIntelligence: new SeedIntelligenceEngine({ contentStore: snapshotStore })
});
const replayAfterRestore = await replayKernel.replayReasoningSeed(compiled.seed, { useCache: false });
const replayIdentical = canonicalStringify(result.document) === canonicalStringify(secondReplay.document)
  && canonicalStringify(result.document) === canonicalStringify(replayAfterRestore.document)
  && canonicalStringify(result.audit) === canonicalStringify(replayAfterRestore.audit);

await writeFile(resolve(outputDir, 'reasoning-seed.json'), JSON.stringify(compiled.seed, null, 2));
await writeFile(resolve(outputDir, 'knowledge-packet.json'), JSON.stringify(packet.packet, null, 2));
await writeFile(resolve(outputDir, 'content-store.snapshot.json'), JSON.stringify(snapshot, null, 2));
await writeFile(resolve(outputDir, 'water-cycle-editorial.md'), result.document.text);
await writeFile(resolve(outputDir, 'run-report.json'), JSON.stringify({
  seedDiagnostics: compiled.diagnostics,
  replayIdentical,
  snapshotRestore,
  snapshotEntryCount: snapshot.entries.length,
  audit: result.audit,
  provenance: result.provenance,
  runtimeStats: kernel.seedIntelligence.stats,
  note: 'This is a deterministic procedural assembly demonstration from a supplied knowledge fixture. It is not neural-model inference, factual-source verification, or compression. The knowledge packet remains separately stored and is required for replay.'
}, null, 2));

console.log(JSON.stringify({
  seedId: compiled.seed.seedId,
  seedBytes: compiled.diagnostics.seedBytes,
  referencedKnowledgeBytes: compiled.diagnostics.referencedContextBytes,
  replayIdentical,
  claims: result.audit.claimCount,
  claimsPreserved: result.audit.representedCount,
  auditPassed: result.audit.passed,
  outputBytes: Buffer.byteLength(result.document.text),
  snapshotEntries: snapshotRestore.restoredEntries,
  replayAfterSnapshotRestoreIdentical: replayIdentical,
  generatedFiles: ['reasoning-seed.json', 'knowledge-packet.json', 'content-store.snapshot.json', 'water-cycle-editorial.md', 'run-report.json']
}, null, 2));
