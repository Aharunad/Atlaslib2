const CACHE = 'atlas-apollo-personal-1.3-llama-cpp-alpha3';
const ASSETS = [
  './',
  './index.html',
  './styles.css',
  './app.js',
  '../../src/runtime/adaptive-model-profile.js',
  './manifest.webmanifest',
  '../apollo-fluid-orb.png',
  '../../src/cache/canonical.js',
  '../../src/cache/seed-cache.js',
  '../../src/conversation/apollo-conversation-service.js',
  '../../src/core/blueprint-validator.js',
  '../../src/core/blueprint.js',
  '../../src/core/constants.js',
  '../../src/core/dream-kernel.js',
  '../../src/core/dream-planner.js',
  '../../src/core/errors.js',
  '../../src/core/resource-governor.js',
  '../../src/core/seed.js',
  '../../src/dream/apollo-dream-service.js',
  '../../src/generators/fluid-orb.js',
  '../../src/index.js',
  '../../src/intelligence/content-addressed-store.js',
  '../../src/intelligence/digest.js',
  '../../src/intelligence/errors.js',
  '../../src/intelligence/knowledge-packet.js',
  '../../src/intelligence/maketiny2.js',
  '../../src/intelligence/model-adapter-contracts.js',
  '../../src/intelligence/operators.js',
  '../../src/intelligence/reasoning-planner.js',
  '../../src/intelligence/seed-intelligence-engine.js',
  '../../src/intelligence/seed-packet.js',
  '../../src/intelligence/strategy-registry.js',
  '../../src/intelligence/validation.js',
  '../../src/persistence/apollo-persistent-store.js',
  '../../src/persistence/create-apollo-runtime.js',
  '../../src/persistence/file-kv-adapter.js',
  '../../src/persistence/kv-adapters.js',
  '../../src/render/dom-renderer.js',
  '../../src/runtime/local-model-adapters.js',
  '../../src/runtime/gguf-inspector.js',
  '../../src/runtime/sleeping-giant-registry.js',
  '../../src/runtime/android-sleeping-giant-bridge.js',
  '../../src/runtime/native-llama-client.js',
  '../../src/runtime/native-runtime-benchmark.js',
  '../../src/runtime/model-residency-manager.js',
  '../../src/runtime/openai-compatible-client.js',
  '../../src/runtime/residency-bound-client.js',
  '../../src/voice/apollo-voice-session.js'
];
self.addEventListener('install', event => event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(ASSETS))));
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE).map(key => caches.delete(key)))));
});
self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin || request.method !== 'GET') return;
  event.respondWith(caches.match(request).then(async cached => {
    if (cached) return cached;
    const response = await fetch(request);
    if (response.ok) {
      const copy = response.clone();
      caches.open(CACHE).then(cache => cache.put(request, copy));
    }
    return response;
  }));
});
