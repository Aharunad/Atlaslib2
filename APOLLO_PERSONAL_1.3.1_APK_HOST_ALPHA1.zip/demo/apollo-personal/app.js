import { createFluidOrbSpec } from '../../src/index.js';
import { createPersistentApolloRuntime } from '../../src/persistence/create-apollo-runtime.js';
import { createLocalApolloAdapters, LocalSlmControllerAdapter, LocalMoEChildAdapter, LocalEditorialAdapter, LocalDreamDirectorAdapter, LocalDreamSectionGenerator } from '../../src/runtime/local-model-adapters.js';
import { NativeLlamaClient } from '../../src/runtime/native-llama-client.js';
import { benchmarkNativeModel } from '../../src/runtime/native-runtime-benchmark.js';
import { LocalOpenAIClient } from '../../src/runtime/openai-compatible-client.js';
import { ApolloDreamService } from '../../src/dream/apollo-dream-service.js';
import { ApolloVoiceSession, createAndroidApolloVoiceProviders } from '../../src/voice/apollo-voice-session.js';
import { SleepingGiantRegistry } from '../../src/runtime/sleeping-giant-registry.js';
import { AndroidSleepingGiantBridge } from '../../src/runtime/android-sleeping-giant-bridge.js';
import { createAdaptiveModelProfile, normalizeAndroidDeviceProfile, formatAdaptiveProfileSummary } from '../../src/runtime/adaptive-model-profile.js';
import { evaluateGgufCompatibility } from '../../src/runtime/gguf-inspector.js';

const $ = id => document.getElementById(id);
const DEFAULTS = Object.freeze({ controllerUrl: 'http://127.0.0.1:8080/v1', controllerModel: 'qwen3-0.6b', localApiKey: '', moeUrl: '', moeModel: 'apollo-moe', contextLimit: 2048 });
let settings = { ...DEFAULTS };
let runtime;
let adapters;
let conversation;
let dreamService;
let activeSessionId = null;
let busy = false;
let lastDream = null;
let voiceSession = null;
let sleepingGiantRegistry = null;
let sleepingGiantBridge = null;
let androidDeviceProfile = null;
let adaptiveModelProfile = null;
let loadedSleepingGiantSession = null;
let nativeRuntimeCapabilities = null;
let nativeControllerActive = false;
let activeNativeClient = null;

function setStatus(text, status = 'idle') {
  $('connectionText').textContent = text;
  $('connectionState').dataset.status = status;
}
function setOrb(state) { $('orbWrap').dataset.state = state; }
function renderOrb(seed = 'apollo-fluid-intelligence-v1') {
  const spec = createFluidOrbSpec(seed, matchMedia('(max-width:520px)').matches ? 'low' : 'balanced');
  const defs = `<defs>
    <radialGradient id="orb-core" cx="38%" cy="31%"><stop offset="0" stop-color="#fff" stop-opacity=".92"/><stop offset=".42" stop-color="#9ce9ed" stop-opacity=".72"/><stop offset="1" stop-color="#d957a7" stop-opacity=".22"/></radialGradient>
    <radialGradient id="orb-glow"><stop offset="0" stop-color="#fff" stop-opacity=".85"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient>
    <filter id="soft"><feGaussianBlur stdDeviation="3"/></filter>
  </defs>`;
  const layers = spec.layers.map((layer, index) => `<path class="orb-layer" d="${layer.path}" fill="${layer.color}" fill-opacity="${layer.opacity}" stroke="${layer.color}" stroke-opacity=".65" stroke-width="${Math.max(1.2, layer.width * .34)}" style="transform:rotate(${layer.rotation}deg);animation-delay:${layer.delay}s"/>`).join('');
  $('apolloOrb').innerHTML = `${defs}<circle class="orb-glow" cx="120" cy="120" r="90"/><circle class="orb-core" cx="120" cy="120" r="69"/>${layers}`;
}

function readSettingsForm() {
  return {
    controllerUrl: $('controllerUrl').value.trim(),
    controllerModel: $('controllerModel').value.trim(),
    localApiKey: $('localApiKey').value,
    moeUrl: $('moeUrl').value.trim(),
    moeModel: $('moeModel').value.trim(),
    contextLimit: Number($('contextLimit').value)
  };
}
function fillSettingsForm() {
  for (const key of Object.keys(DEFAULTS)) $(key).value = settings[key];
}
async function saveSettings() {
  const next = readSettingsForm();
  // Construct clients as validation: only loopback endpoints are allowed.
  new LocalOpenAIClient({ baseUrl: next.controllerUrl, model: next.controllerModel, apiKey: next.localApiKey });
  if (next.moeUrl) new LocalOpenAIClient({ baseUrl: next.moeUrl, model: next.moeModel, apiKey: next.localApiKey });
  const persisted = { ...next };
  delete persisted.localApiKey; // never persist a local inference bearer token in IndexedDB
  await runtime.storageAdapter.put('apollo:settings', persisted);
  settings = next;
  nativeControllerActive = false;
  activeNativeClient = null;
  configureServices();
  $('settingsStatus').textContent = 'Settings saved locally.';
  await probeModels();
}
function configureServices() {
  if (nativeControllerActive && loadedSleepingGiantSession) {
    activeNativeClient = new NativeLlamaClient({
      bridge: sleepingGiantBridge,
      getSession: () => loadedSleepingGiantSession,
      model: loadedSleepingGiantSession.modelName
    });
    const controller = new LocalSlmControllerAdapter({ client: activeNativeClient, modelId: loadedSleepingGiantSession.modelName });
    const moeChild = new LocalMoEChildAdapter({ client: activeNativeClient, modelId: loadedSleepingGiantSession.modelName });
    const editor = new LocalEditorialAdapter({ client: activeNativeClient, modelId: loadedSleepingGiantSession.modelName });
    adapters = Object.freeze({
      controller,
      moeChild,
      editor,
      dreamDirector: new LocalDreamDirectorAdapter({ client: activeNativeClient, modelId: loadedSleepingGiantSession.modelName }),
      dreamSectionGenerator: new LocalDreamSectionGenerator({ generator: moeChild, fallback: controller })
    });
    conversation = runtime.createConversationService({ controller, moeChild, editor, maxHistoryTurns: 16 });
    dreamService = new ApolloDreamService({ store: runtime.store, seedEngine: runtime.kernel.seedIntelligence, director: adapters.dreamDirector, sectionGenerator: adapters.dreamSectionGenerator, editor });
  } else {
    activeNativeClient = null;
    adapters = createLocalApolloAdapters({
      controller: { baseUrl: settings.controllerUrl, model: settings.controllerModel, apiKey: settings.localApiKey },
      ...(settings.moeUrl ? { moe: { baseUrl: settings.moeUrl, model: settings.moeModel, apiKey: settings.localApiKey } } : {}),
      editor: { baseUrl: settings.controllerUrl, model: settings.controllerModel, apiKey: settings.localApiKey }
    });
    const nativeMoE = loadedSleepingGiantSession
      ? new LocalMoEChildAdapter({ client: new NativeLlamaClient({ bridge: sleepingGiantBridge, getSession: () => loadedSleepingGiantSession, model: loadedSleepingGiantSession.modelName }) })
      : null;
    conversation = runtime.createConversationService({ controller: adapters.controller, moeChild: settings.moeUrl ? adapters.moeChild : nativeMoE, editor: adapters.editor, maxHistoryTurns: 16 });
    dreamService = new ApolloDreamService({ store: runtime.store, seedEngine: runtime.kernel.seedIntelligence, director: adapters.dreamDirector, sectionGenerator: adapters.dreamSectionGenerator, editor: adapters.editor });
  }

  try {
    const providers = createAndroidApolloVoiceProviders(globalThis.AtlasApolloNative);
    voiceSession = new ApolloVoiceSession({
      recognizer: providers.recognizer, synthesizer: providers.synthesizer,
      converse: async ({ sessionId, text, signal }) => {
        const result = await conversation.send({ sessionId, text, signal, onStatus: status => setOrb(status === 'complete' ? 'idle' : 'thinking') });
        return { answer: result.answer };
      },
      onState: state => { setOrb(state === 'error' ? 'error' : state); if (state === 'listening') setStatus('Listening on device', 'connected'); }
    });
    $('voiceButton').disabled = false;
    $('voiceButton').title = 'Start one offline voice turn';
  } catch {
    voiceSession = null;
    $('voiceButton').disabled = true;
    $('voiceButton').title = 'Offline Android ASR/TTS host is not installed';
  }
}

async function probeModels({ forceControllerProbe = false } = {}) {
  setStatus('Checking local model…', 'idle');
  $('settingsStatus').textContent = 'Checking local inference capabilities…';

  if (nativeControllerActive && loadedSleepingGiantSession && activeNativeClient && !forceControllerProbe) {
    try {
      const nativeInfo = await activeNativeClient.probe();
      if (!nativeInfo.available) throw new Error('The loaded Sleeping Giant native session is no longer available.');
      setStatus(`Apollo connected · ${loadedSleepingGiantSession.modelName} · native CPU`, 'connected');
      $('settingsStatus').textContent = 'No separate controller server is active. The loaded GGUF is serving as Apollo controller, specialist and editor. All inference remains local.';
      $('sendButton').disabled = false;
      $('createDream').disabled = false;
      $('composerHint').textContent = 'Sleeping Giant is powering Apollo locally';
      return true;
    } catch (error) {
      nativeControllerActive = false;
      activeNativeClient = null;
      configureServices();
      $('settingsStatus').textContent = `${error.message} Checking the configured local controller instead.`;
    }
  }

  try {
    const controllerClient = new LocalOpenAIClient({ baseUrl: settings.controllerUrl, model: settings.controllerModel, apiKey: settings.localApiKey, timeoutMs: 8000 });
    const controllerInfo = await controllerClient.probe();
    if (controllerInfo.models.length && !controllerInfo.models.includes(settings.controllerModel)) throw new Error(`Configured controller model '${settings.controllerModel}' is not advertised by the local server`);
    if (nativeControllerActive) {
      nativeControllerActive = false;
      activeNativeClient = null;
      configureServices();
    }
    let childText = 'Controller connected';
    if (settings.moeUrl) {
      try {
        const childInfo = await new LocalOpenAIClient({ baseUrl: settings.moeUrl, model: settings.moeModel, apiKey: settings.localApiKey, timeoutMs: 8000 }).probe();
        if (childInfo.models.length && !childInfo.models.includes(settings.moeModel)) throw new Error(`Configured Sleeping Giant model '${settings.moeModel}' is not advertised by the local server`);
        childText += ` · Sleeping Giant connected (${childInfo.models.length || 'local'} model)`;
      } catch { childText += ' · Sleeping Giant unavailable; controller fallback active'; }
    } else if (loadedSleepingGiantSession) childText += ` · Sleeping Giant loaded natively (${loadedSleepingGiantSession.modelName})`;
    else childText += ' · Sleeping Giant not configured';
    setStatus(childText, 'connected');
    $('settingsStatus').textContent = `Controller endpoint reachable. Advertised models: ${controllerInfo.models.join(', ') || 'server did not advertise IDs'}. The selected model ID is sent with each request.`;
    $('sendButton').disabled = false;
    $('createDream').disabled = false;
    $('composerHint').textContent = 'Local models only · no cloud inference';
    return true;
  } catch (error) {
    if (loadedSleepingGiantSession) {
      try {
        const candidate = new NativeLlamaClient({ bridge: sleepingGiantBridge, getSession: () => loadedSleepingGiantSession, model: loadedSleepingGiantSession.modelName });
        const nativeInfo = await candidate.probe();
        if (nativeInfo.available) {
          nativeControllerActive = true;
          configureServices();
          setStatus(`Apollo connected · ${loadedSleepingGiantSession.modelName} · native CPU`, 'connected');
          $('settingsStatus').textContent = `Configured controller unavailable (${error.message}). The loaded GGUF is now serving as Apollo's local controller, specialist and editor.`;
          $('sendButton').disabled = false;
          $('createDream').disabled = false;
          $('composerHint').textContent = 'Sleeping Giant is powering Apollo locally';
          return true;
        }
      } catch (nativeError) {
        error = new Error(`${error.message}. Native Sleeping Giant fallback failed: ${nativeError.message}`);
      }
    }
    nativeControllerActive = false;
    activeNativeClient = null;
    setStatus('Local model not connected', 'error');
    $('settingsStatus').textContent = `${error.message}. Apollo will not fabricate an answer when a model is unavailable.`;
    $('sendButton').disabled = true;
    $('createDream').disabled = true;
    $('composerHint').textContent = 'Connect an on-device model to begin.';
    return false;
  }
}

function addMessage(role, text, meta = '') {
  $('welcomeCard')?.remove();
  const wrapper = document.createElement('div');
  wrapper.className = `message ${role}`;
  const bubble = document.createElement('div');
  bubble.className = 'message-bubble';
  bubble.textContent = text;
  wrapper.appendChild(bubble);
  if (meta) {
    const metadata = document.createElement('div');
    metadata.className = 'message-meta';
    metadata.textContent = meta;
    wrapper.appendChild(metadata);
  }
  $('conversation').appendChild(wrapper);
  $('conversation').scrollTop = $('conversation').scrollHeight;
  return wrapper;
}
function statusLabel(status) {
  const map = { planning: 'Planning', waking_sleeping_giant: 'Waking the Sleeping Giant', controller_fallback: 'Using Apollo’s local controller', controller_response: 'Thinking', editorial_refinement: 'Refining the answer', complete: 'Ready' };
  return map[status] ?? 'Thinking';
}
async function ensureSession() {
  if (activeSessionId) return activeSessionId;
  const created = await conversation.createSession({ title: 'Conversation with Apollo' });
  activeSessionId = created.session.id;
  return activeSessionId;
}
async function sendMessage(text) {
  if (busy || !text.trim()) return;
  if (!await probeModels()) return;
  busy = true;
  $('sendButton').disabled = true;
  addMessage('user', text.trim());
  const pending = addMessage('assistant', '');
  pending.querySelector('.message-bubble').textContent = '…';
  setOrb('thinking');
  try {
    const sessionId = await ensureSession();
    const result = await conversation.send({
      sessionId,
      text: text.trim(),
      onStatus: status => {
        pending.querySelector('.message-bubble').textContent = statusLabel(status) + '…';
        setOrb(status === 'waking_sleeping_giant' ? 'thinking' : 'thinking');
      }
    });
    pending.querySelector('.message-bubble').textContent = result.answer;
    const editorialMeta = result.editorialApplied ? 'Editorially refined' : result.editorialFallback ? 'Editorial fallback used' : 'Structured response';
    const meta = `${result.delegatedToMoE ? 'Sleeping Giant assisted' : result.degradedMode ? 'Controller fallback' : 'Apollo controller'} · ${editorialMeta}`;
    pending.querySelector('.message-meta')?.remove();
    const label = document.createElement('div'); label.className = 'message-meta'; label.textContent = meta; pending.appendChild(label);
    await refreshHistory();
  } catch (error) {
    pending.classList.add('message-error');
    pending.querySelector('.message-bubble').textContent = `I couldn't complete that request. ${error.message}`;
  } finally {
    setOrb('idle');
    busy = false;
    $('sendButton').disabled = false;
    $('chatInput').focus();
  }
}

async function createDream() {
  const objective = $('dreamObjective').value.trim();
  if (!objective || busy) return;
  if (!await probeModels()) return;
  busy = true;
  $('createDream').disabled = true;
  $('dreamProgress').classList.remove('hidden');
  $('dreamResult').classList.add('hidden');
  setOrb('thinking');
  try {
    const result = await dreamService.create({
      objective,
      onStatus: status => { $('dreamProgressText').textContent = status.replaceAll('_', ' '); setOrb('thinking'); }
    });
    lastDream = result;
    $('dreamTitle').textContent = result.title;
    $('dreamMeta').textContent = `${result.sections.length} sections · ${result.metrics.claimCount} claims · ${result.metrics.delegatedToMoE ? 'Sleeping Giant used' : 'controller generated'} · ${result.metrics.editorialApplied ? 'editorially refined' : result.metrics.editorialFallback ? 'editorial fallback' : 'structured assembly'}`;
    $('dreamDocument').textContent = result.document;
    $('dreamSeedDetails').textContent = JSON.stringify(result.seeds, null, 2);
    $('dreamResult').classList.remove('hidden');
  } catch (error) {
    $('dreamProgressText').textContent = `Dream stopped: ${error.message}`;
  } finally {
    $('dreamProgress').classList.add('hidden');
    $('createDream').disabled = false;
    setOrb('idle');
    busy = false;
  }
}

async function refreshHistory() {
  const sessions = await runtime.store.listSessions({ limit: 40 });
  const list = $('historyList');
  list.replaceChildren();
  if (!sessions.length) {
    const empty = document.createElement('div'); empty.className = 'empty-state'; empty.textContent = 'Your conversations will appear here.'; list.appendChild(empty); return;
  }
  for (const session of sessions) {
    const button = document.createElement('button'); button.className = 'history-item';
    const text = document.createElement('span');
    const strong = document.createElement('strong'); strong.textContent = session.title;
    const small = document.createElement('small'); small.textContent = new Date(session.updatedAt).toLocaleString();
    text.append(strong, small);
    const icon = document.createElement('span'); icon.textContent = 'Open →'; icon.className = 'text-button';
    button.append(text, icon);
    button.addEventListener('click', async () => {
      activeSessionId = session.id;
      const full = await runtime.store.getSession(session.id, { limit: 40 });
      $('conversation').replaceChildren();
      for (const turn of full.turns) addMessage(turn.role, turn.text, turn.metadata?.delegatedToMoE ? 'Sleeping Giant assisted' : 'Saved locally');
      activateWorkspace('chat');
    });
    list.appendChild(button);
  }
}
function activateWorkspace(name) {
  document.querySelectorAll('.workspace').forEach(item => item.classList.toggle('active', item.id === `${name}Workspace`));
  document.querySelectorAll('.workspace-tab').forEach(item => item.classList.toggle('active', item.dataset.workspace === name));
}

async function runVoiceTurn() {
  if (!voiceSession || busy) return;
  busy = true;
  $('voiceButton').disabled = true;
  try {
    const sessionId = await ensureSession();
    const result = await voiceSession.listenAndRespond({ sessionId });
    addMessage('user', result.userText, 'Voice · processed locally');
    addMessage('assistant', result.answer, 'Apollo voice response');
    await refreshHistory();
  } catch (error) {
    addMessage('assistant', `Voice unavailable: ${error.message}`, 'Local voice status');
  } finally {
    busy = false;
    $('voiceButton').disabled = !voiceSession;
    setOrb('idle');
  }
}


function formatBytes(bytes) {
  if (!Number.isFinite(bytes) || bytes < 0) return 'Unknown size';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let value = bytes;
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) { value /= 1024; unit++; }
  return `${value.toFixed(unit >= 3 ? 2 : unit === 0 ? 0 : 1)} ${units[unit]}`;
}

function compatibilityLabel(status) {
  const labels = {
    needs_runtime: 'Imported · runtime needed',
    load_test_required: 'Native runtime available · load test required',
    runtime_compatible: 'Runtime compatible · load test pending',
    unsupported_format: 'Unsupported runtime format',
    unsupported_architecture: 'Unsupported architecture',
    invalid: 'Invalid model metadata'
  };
  return labels[status] ?? 'Imported';
}

function renderDeviceFit() {
  const target = $('sgDeviceFit');
  const applyButton = $('applyRecommendedContext');
  if (!target || !applyButton) return;
  const selectedModel = currentSelectedSleepingGiant;
  if (!androidDeviceProfile) {
    target.dataset.state = 'unknown';
    target.textContent = sleepingGiantBridge?.deviceProfileAvailable
      ? 'Android device capabilities have not been measured yet. Tap Recheck.'
      : 'Device profiling is available inside the Atlas Library Android host.';
    applyButton.classList.add('hidden');
    return;
  }
  const ramText = `${formatBytes(androidDeviceProfile.totalRamBytes)} RAM · ${formatBytes(androidDeviceProfile.availableRamBytes)} currently available`;
  const cpuText = `${androidDeviceProfile.cpuCores} CPU cores · ${androidDeviceProfile.supportedAbis.join(', ')}`;
  const storageText = androidDeviceProfile.availableStorageBytes == null ? '' : `${formatBytes(androidDeviceProfile.availableStorageBytes)} storage available`;
  if (!selectedModel) {
    target.dataset.state = 'unknown';
    target.textContent = `Device detected: ${androidDeviceProfile.deviceSignature || 'Android device'}. ${ramText}. ${cpuText}. Add a GGUF model to calculate its recommended settings.${storageText ? ` ${storageText}.` : ''}`;
    applyButton.classList.add('hidden');
    return;
  }
  try {
    adaptiveModelProfile = createAdaptiveModelProfile({
      inspection: selectedModel.inspection,
      device: androidDeviceProfile,
      runtimeCapabilities: nativeRuntimeCapabilities ?? selectedModel.runtimeCapabilities ?? null,
      preferredContextTokens: null
    });
  } catch (error) {
    target.dataset.state = 'error';
    target.textContent = `Apollo could not calculate a device profile: ${error.message}`;
    applyButton.classList.add('hidden');
    return;
  }
  const profile = adaptiveModelProfile;
  target.dataset.state = profile.recommendedContextTokens ? 'fit' : 'warning';
  const details = [
    `${ramText}`,
    `${cpuText}`,
    `${formatBytes(profile.memoryBudgetBytes)} conservative model budget`,
    profile.estimatedWorkingSetBytes == null ? null : `${formatBytes(profile.estimatedWorkingSetBytes)} estimated working set`,
    profile.recommendedContextTokens ? `${profile.recommendedContextTokens.toLocaleString()} token context recommended` : null,
    `${profile.cpuThreads} CPU threads · batch ${profile.batchTokens}`,
    storageText || null
  ].filter(Boolean);
  target.replaceChildren();
  const summary = document.createElement('strong');
  summary.textContent = formatAdaptiveProfileSummary(profile);
  const detail = document.createElement('span');
  detail.className = 'sg-device-fit-meta';
  detail.textContent = `${details.join(' · ')}. This is a conservative estimate, not a load guarantee. Native runtime load validation is still required.`;
  target.append(summary, detail);
  applyButton.classList.toggle('hidden', !profile.recommendedContextTokens);
  applyButton.disabled = !profile.recommendedContextTokens;
  applyButton.textContent = profile.recommendedContextTokens
    ? `Use ${profile.recommendedContextTokens.toLocaleString()} token context`
    : 'No safe context recommendation';
}

let currentSelectedSleepingGiant = null;

async function refreshNativeRuntimeCapabilities() {
  try {
    nativeRuntimeCapabilities = await sleepingGiantBridge?.getRuntimeCapabilities();
  } catch (error) {
    nativeRuntimeCapabilities = { available: false, formats: [], architectureCandidates: [], reason: error.message };
  }
  return nativeRuntimeCapabilities;
}

async function refreshAndroidDeviceProfile() {
  const target = $('sgDeviceFit');
  const button = $('refreshDeviceFit');
  if (button) button.disabled = true;
  if (target) { target.dataset.state = 'unknown'; target.textContent = 'Reading Android device capabilities…'; }
  try {
    if (!sleepingGiantBridge?.deviceProfileAvailable) throw new Error('Android device profiling is not connected in this host.');
    androidDeviceProfile = normalizeAndroidDeviceProfile(await sleepingGiantBridge.getDeviceProfile());
    renderDeviceFit();
    return androidDeviceProfile;
  } catch (error) {
    androidDeviceProfile = null;
    adaptiveModelProfile = null;
    if (target) { target.dataset.state = 'unknown'; target.textContent = `${error.message} Apollo will not guess this phone's RAM or claim that a model fits.`; }
    if ($('applyRecommendedContext')) $('applyRecommendedContext').classList.add('hidden');
    return null;
  } finally {
    if (button) button.disabled = false;
  }
}

async function unloadNativeSleepingGiant() {
  if (!loadedSleepingGiantSession) return;
  const current = loadedSleepingGiantSession;
  await sleepingGiantBridge.unloadSleepingGiant(current.sessionId);
  loadedSleepingGiantSession = null;
  nativeControllerActive = false;
  activeNativeClient = null;
  configureServices();
  $('sleepingGiantImportStatus').textContent = 'Sleeping Giant unloaded. Its private model file and registry entry remain installed.';
  $('sleepingGiantImportStatus').dataset.state = 'success';
  await renderSleepingGiants();
  await probeModels();
}

async function loadNativeSleepingGiant(model) {
  if (!sleepingGiantBridge?.runtimeAvailable) throw new Error('The native llama.cpp runtime is not included in this Android host build yet.');
  if (loadedSleepingGiantSession) throw new Error('Unload the currently loaded Sleeping Giant before loading another model.');
  if (!androidDeviceProfile) androidDeviceProfile = await refreshAndroidDeviceProfile();
  if (!androidDeviceProfile) throw new Error('Apollo could not read the device memory and CPU profile.');
  const capabilities = await refreshNativeRuntimeCapabilities();
  if (!capabilities?.available || !capabilities.formats.includes('gguf')) throw new Error(capabilities?.reason || 'No compatible GGUF inference runtime is installed.');
  const profile = createAdaptiveModelProfile({
    inspection: model.inspection,
    device: androidDeviceProfile,
    runtimeCapabilities: capabilities
  });
  adaptiveModelProfile = profile;
  renderDeviceFit();
  if (!profile.runtimeAvailable) throw new Error(profile.reason || 'The native runtime has not listed this model architecture as a candidate.');
  if (!profile.recommendedContextTokens || !profile.llamaCppOptions) throw new Error(profile.reason || 'Apollo cannot recommend a safe context for this device.');
  const options = profile.llamaCppOptions;
  const loaded = await sleepingGiantBridge.loadSleepingGiant(model.assetId, {
    contextTokens: options.contextTokens,
    threads: options.threads,
    batchTokens: options.batchTokens
  });
  loadedSleepingGiantSession = {
    sessionId: loaded.sessionId,
    assetId: model.assetId,
    modelName: model.inspection?.name || model.displayName,
    modelInfo: loaded.modelInfo,
    runtime: loaded.runtime,
    lastMetrics: null
  };
  try {
    const smoke = await sleepingGiantBridge.generateSleepingGiant({
      sessionId: loaded.sessionId,
      messages: [
        { role: 'system', content: 'You are Apollo running a local model smoke test. Reply with one short confirmation.' },
        { role: 'user', content: 'Confirm that local inference is working.' }
      ],
      maxTokens: 32,
      temperature: 0
    });
    if (!smoke.text.trim()) throw new Error('The native model loaded but returned no text during the smoke test.');
  } catch (error) {
    await sleepingGiantBridge.unloadSleepingGiant(loaded.sessionId).catch(() => {});
    loadedSleepingGiantSession = null;
    throw error;
  }
  configureServices();
  await renderSleepingGiants();
  const info = loaded.modelInfo;
  $('sleepingGiantImportStatus').textContent = `Loaded and smoke-tested ${loadedSleepingGiantSession.modelName}. ${loaded.runtime?.engine || 'Native runtime'} ${loaded.runtime?.version || ''} · CPU backend · ${Number(info.contextTokens || options.contextTokens).toLocaleString()} context. Run the model benchmark for a more useful throughput measurement.`;
  $('sleepingGiantImportStatus').dataset.state = 'success';
  await probeModels();
}

async function benchmarkNativeSleepingGiant(model) {
  if (!loadedSleepingGiantSession || loadedSleepingGiantSession.assetId !== model.assetId) {
    throw new Error('Load this Sleeping Giant before benchmarking it.');
  }
  if (busy) throw new Error('Apollo is currently generating a response. Wait for it to finish before benchmarking.');
  const button = document.querySelector(`[data-benchmark-asset="${model.assetId}"]`);
  if (button) { button.disabled = true; button.textContent = 'Benchmarking…'; }
  const status = $('sleepingGiantImportStatus');
  status.textContent = 'Running a local benchmark. Apollo will measure prompt prefill and generated tokens on this phone.';
  status.dataset.state = 'idle';
  try {
    const client = new NativeLlamaClient({
      bridge: sleepingGiantBridge,
      getSession: () => loadedSleepingGiantSession,
      model: loadedSleepingGiantSession.modelName
    });
    const metrics = await benchmarkNativeModel(client);
    loadedSleepingGiantSession.lastMetrics = metrics;
    const promptRate = Number.isFinite(metrics.promptTokensPerSecond) ? `${metrics.promptTokensPerSecond.toFixed(1)} prompt tokens/s` : 'prefill rate unavailable';
    const generationRate = `${metrics.generationTokensPerSecond.toFixed(1)} generated tokens/s`;
    status.textContent = `Benchmark complete · ${loadedSleepingGiantSession.modelName} · ${promptRate} · ${generationRate} · ${metrics.generatedTokens} output tokens. Prompt timing covers native prompt decode. Generation timing includes sampling, token decode and batched streaming callback overhead.`;
    status.dataset.state = 'success';
    await renderSleepingGiants();
    return metrics;
  } catch (error) {
    status.textContent = error.message || 'The local model benchmark failed.';
    status.dataset.state = 'error';
    throw error;
  } finally {
    if (button?.isConnected) { button.disabled = false; button.textContent = 'Benchmark model'; }
  }
}

async function renderSleepingGiants() {
  if (!sleepingGiantRegistry) return;
  const [models, selected] = await Promise.all([sleepingGiantRegistry.list(), sleepingGiantRegistry.getSelected()]);
  currentSelectedSleepingGiant = selected ?? null;
  const badge = $('sleepingGiantBadge');
  const list = $('sleepingGiantInstalled');
  list.replaceChildren();
  if (!models.length) {
    badge.textContent = 'Not installed';
    badge.dataset.state = 'empty';
    const empty = document.createElement('div');
    empty.className = 'sg-empty-installed';
    empty.textContent = 'No model selected yet.';
    list.appendChild(empty);
    renderDeviceFit();
    return;
  }
  badge.textContent = `${models.length} installed`;
  const liveStatuses = models.map(model => evaluateGgufCompatibility(model.inspection, nativeRuntimeCapabilities).status);
  badge.dataset.state = liveStatuses.some(status => status === 'needs_runtime' || status.startsWith('unsupported')) ? 'warning' : 'installed';
  for (const model of models) {
    const item = document.createElement('article');
    item.className = `sg-model-item${selected?.modelId === model.modelId ? ' is-selected' : ''}`;
    const top = document.createElement('div'); top.className = 'sg-model-top';
    const name = document.createElement('div'); name.className = 'sg-model-name';
    name.textContent = model.inspection?.name || model.displayName;
    const state = document.createElement('div'); state.className = 'sg-model-state';
    state.textContent = selected?.modelId === model.modelId ? 'Selected profile' : 'Saved profile';
    top.append(name, state);
    const meta = document.createElement('div'); meta.className = 'sg-model-meta';
    const details = [
      model.inspection?.architecture || 'Unknown architecture',
      formatBytes(model.bytes),
      `${Number(model.inspection?.tensorCount ?? 0).toLocaleString()} tensors`,
      model.inspection?.contextLength ? `${Number(model.inspection.contextLength).toLocaleString()} context` : null,
      model.inspection?.isMoE ? `MoE · ${model.inspection.expertCount} experts${model.inspection.expertUsedCount ? ` / ${model.inspection.expertUsedCount} active` : ''}` : 'Dense / MoE status not declared'
    ].filter(Boolean);
    meta.textContent = details.join(' · ');
    const runtime = document.createElement('div'); runtime.className = 'sg-model-meta';
    const liveCompatibility = evaluateGgufCompatibility(model.inspection, nativeRuntimeCapabilities);
    runtime.textContent = compatibilityLabel(liveCompatibility.status);
    const license = document.createElement('div'); license.className = 'sg-model-meta';
    license.textContent = model.licenseReview === 'user_reviewed'
      ? 'License: marked reviewed by you · not independently verified'
      : 'License: review required before use or distribution';
    const fingerprint = document.createElement('div'); fingerprint.className = 'sg-model-fingerprint';
    fingerprint.textContent = `SHA-256 ${model.sha256}`;
    const actions = document.createElement('div'); actions.className = 'sg-model-actions';
    const isLoaded = loadedSleepingGiantSession?.assetId === model.assetId;
    if (isLoaded) {
      const benchmark = document.createElement('button'); benchmark.type = 'button'; benchmark.textContent = 'Benchmark model';
      benchmark.dataset.benchmarkAsset = model.assetId;
      benchmark.addEventListener('click', async () => {
        benchmark.disabled = true;
        try { await benchmarkNativeSleepingGiant(model); }
        catch { /* benchmark status is rendered by the benchmark function */ }
        finally { if (benchmark.isConnected) benchmark.disabled = false; }
      });
      actions.appendChild(benchmark);
      const metrics = loadedSleepingGiantSession.lastMetrics;
      if (metrics && Number.isFinite(metrics.generationTokensPerSecond) && metrics.generatedTokens > 0) {
        const performance = document.createElement('div'); performance.className = 'sg-model-meta';
        performance.textContent = `Latest measured throughput · ${Number(metrics.promptTokensPerSecond || 0).toFixed(1)} prompt tokens/s · ${metrics.generationTokensPerSecond.toFixed(1)} generated tokens/s · ${metrics.generatedTokens} output tokens`;
        actions.appendChild(performance);
      }
      const unload = document.createElement('button'); unload.type = 'button'; unload.textContent = 'Unload Sleeping Giant';
      unload.addEventListener('click', async () => {
        unload.disabled = true;
        try { await unloadNativeSleepingGiant(); }
        catch (error) { unload.disabled = false; $('sleepingGiantImportStatus').textContent = error.message; $('sleepingGiantImportStatus').dataset.state = 'error'; }
      });
      actions.appendChild(unload);
    } else {
      const load = document.createElement('button'); load.type = 'button'; load.textContent = 'Load for Apollo';
      const runtimeReady = nativeRuntimeCapabilities?.available === true && nativeRuntimeCapabilities?.formats?.includes('gguf');
      const liveCompatibility = evaluateGgufCompatibility(model.inspection, nativeRuntimeCapabilities);
      const compatibleCandidate = liveCompatibility.status === 'runtime_compatible';
      load.disabled = selected?.modelId !== model.modelId || !runtimeReady || !compatibleCandidate || Boolean(loadedSleepingGiantSession);
      load.title = selected?.modelId !== model.modelId ? 'Select this model profile first' : !runtimeReady ? (nativeRuntimeCapabilities?.reason || 'Native llama.cpp runtime is not installed in this host build') : !compatibleCandidate ? liveCompatibility.reason : 'Load and run a local inference smoke test';
      load.addEventListener('click', async () => {
        load.disabled = true;
        $('sleepingGiantImportStatus').textContent = 'Checking model and device compatibility before native load…';
        $('sleepingGiantImportStatus').dataset.state = 'idle';
        try { await loadNativeSleepingGiant(model); }
        catch (error) { $('sleepingGiantImportStatus').textContent = error.message || 'The model could not be loaded.'; $('sleepingGiantImportStatus').dataset.state = 'error'; load.disabled = false; }
      });
      actions.appendChild(load);
    }
    const reviewLicense = document.createElement('button'); reviewLicense.type = 'button';
    reviewLicense.textContent = model.licenseReview === 'user_reviewed' ? 'Undo license review' : 'I reviewed the license';
    reviewLicense.addEventListener('click', async () => {
      await sleepingGiantRegistry.updateLicenseReview(model.modelId, model.licenseReview !== 'user_reviewed');
      await renderSleepingGiants();
    });
    actions.appendChild(reviewLicense);
    if (selected?.modelId !== model.modelId) {
      const select = document.createElement('button'); select.type = 'button'; select.textContent = 'Select profile';
      select.addEventListener('click', async () => {
        await sleepingGiantRegistry.select(model.modelId);
        $('sleepingGiantImportStatus').textContent = 'Sleeping Giant profile selected. Apollo will check native runtime support and device memory before loading it.';
        $('sleepingGiantImportStatus').dataset.state = 'success';
        await renderSleepingGiants();
      });
      actions.appendChild(select);
    }
    const remove = document.createElement('button'); remove.type = 'button'; remove.className = 'danger'; remove.textContent = 'Remove private copy';
    remove.addEventListener('click', async () => {
      const confirmed = window.confirm('Remove Apollo’s private model copy and its profile? The original file in your storage will not be deleted.');
      if (!confirmed) return;
      remove.disabled = true;
      try {
        await sleepingGiantRegistry.remove(model.modelId, { deletePrivateCopy: true });
        $('sleepingGiantImportStatus').textContent = 'Apollo’s private copy and profile were removed. The original file was left untouched.';
        $('sleepingGiantImportStatus').dataset.state = 'success';
        await renderSleepingGiants();
      } catch (error) {
        remove.disabled = false;
        $('sleepingGiantImportStatus').textContent = error.message;
        $('sleepingGiantImportStatus').dataset.state = 'error';
      }
    });
    actions.appendChild(remove);
    item.append(top, meta, runtime, license, fingerprint, actions);
    list.appendChild(item);
  }
  renderDeviceFit();
}

async function addSleepingGiant() {
  const button = $('addSleepingGiant');
  const status = $('sleepingGiantImportStatus');
  if (!sleepingGiantBridge?.available) {
    status.textContent = 'Android storage is not connected in this preview. Open Apollo inside the Atlas Library Android host to choose a GGUF model.';
    status.dataset.state = 'error';
    return;
  }
  button.disabled = true;
  button.querySelector('strong').textContent = 'Preparing model import…';
  status.textContent = 'Opening Android file picker…';
  status.dataset.state = 'idle';
  try {
    const result = await sleepingGiantBridge.importSleepingGiant();
    if (result.cancelled) {
      status.textContent = 'Model selection cancelled.';
      status.dataset.state = 'idle';
      return;
    }
    let model;
    try {
      model = await sleepingGiantRegistry.registerImport(result);
    } catch (registryError) {
      // Do not leave an orphaned private copy if persistent registration fails.
      if (result.model?.assetId) {
        try { await sleepingGiantBridge.removeModelAsset(result.model.assetId); } catch { /* preserve the registration error */ }
      }
      throw registryError;
    }
    await refreshNativeRuntimeCapabilities();
    await renderSleepingGiants();
    status.textContent = `${model.displayName} was copied, fingerprinted and inspected. ${model.compatibility.reason}`;
    status.dataset.state = model.status === 'needs_runtime' ? 'idle' : 'success';
  } catch (error) {
    status.textContent = error.message || 'The model could not be imported.';
    status.dataset.state = 'error';
  } finally {
    button.disabled = false;
    button.querySelector('strong').textContent = 'Add Sleeping Giant';
  }
}

function listenForSleepingGiantProgress() {
  window.addEventListener('atlas-apollo-native-progress', event => {
    const detail = event.detail ?? {};
    const status = $('sleepingGiantImportStatus');
    if (!status || !detail.requestId?.startsWith('sg-import-')) return;
    const copied = Number(detail.bytesCopied ?? 0);
    const total = Number(detail.totalBytes ?? 0);
    const phaseLabels = { copying: 'Copying model into Atlas private storage', inspecting: 'Inspecting GGUF metadata', validating: 'Verifying model fingerprint', complete: 'Finalizing model profile' };
    status.textContent = total > 0
      ? `${phaseLabels[detail.phase] ?? 'Preparing model'} · ${formatBytes(copied)} of ${formatBytes(total)}`
      : (phaseLabels[detail.phase] ?? 'Preparing model…');
    status.dataset.state = 'idle';
  });
}

async function initialize() {
  renderOrb();
  sleepingGiantBridge = new AndroidSleepingGiantBridge();
  await refreshNativeRuntimeCapabilities();
  // Measure the real Android app memory class before choosing Apollo's UI/Dream
  // resource profile. Do not substitute a hard-coded 4 GB device assumption.
  try { androidDeviceProfile = normalizeAndroidDeviceProfile(await sleepingGiantBridge.getDeviceProfile()); } catch { androidDeviceProfile = null; }
  runtime = createPersistentApolloRuntime({
    device: {
      ...(androidDeviceProfile?.totalRamBytes ? { totalRamMb: Math.floor(androidDeviceProfile.totalRamBytes / (1024 * 1024)) } : {}),
      lowPower: androidDeviceProfile?.lowRamDevice === true || androidDeviceProfile?.lowMemory === true,
      reducedMotion: matchMedia('(prefers-reduced-motion: reduce)').matches
    },
    dbName: 'atlas-library-apollo-personal'
  });
  sleepingGiantRegistry = new SleepingGiantRegistry({ adapter: runtime.storageAdapter, nativeHost: sleepingGiantBridge });
  listenForSleepingGiantProgress();
  await renderSleepingGiants();
  settings = { ...DEFAULTS, ...(await runtime.storageAdapter.get('apollo:settings') ?? {}) };
  fillSettingsForm();
  configureServices();
  await probeModels();
  await refreshHistory();
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
    navigator.serviceWorker.register('./sw.js').catch(() => {});
  }
}

$('settingsOpen').addEventListener('click', () => { $('settingsDialog').showModal(); refreshAndroidDeviceProfile(); refreshNativeRuntimeCapabilities().then(renderSleepingGiants); });
$('addSleepingGiant').addEventListener('click', addSleepingGiant);
$('refreshDeviceFit').addEventListener('click', refreshAndroidDeviceProfile);
$('applyRecommendedContext').addEventListener('click', async () => {
  if (!adaptiveModelProfile?.recommendedContextTokens) return;
  const option = [...$('contextLimit').options].find(item => Number(item.value) === adaptiveModelProfile.recommendedContextTokens);
  if (!option) { const item = document.createElement('option'); item.value = String(adaptiveModelProfile.recommendedContextTokens); item.textContent = `${adaptiveModelProfile.recommendedContextTokens.toLocaleString()} tokens · recommended for this device`; $('contextLimit').appendChild(item); }
  $('contextLimit').value = String(adaptiveModelProfile.recommendedContextTokens);
  $('settingsStatus').textContent = `Context set to ${adaptiveModelProfile.recommendedContextTokens.toLocaleString()} tokens for this device. Save settings to keep this choice.`;
});
$('voiceButton').addEventListener('click', runVoiceTurn);
$('saveSettings').addEventListener('click', async () => { try { await saveSettings(); } catch (error) { $('settingsStatus').textContent = error.message; } });
$('checkModels').addEventListener('click', () => probeModels({ forceControllerProbe: true }));
$('chatForm').addEventListener('submit', async event => {
  event.preventDefault(); const text = $('chatInput').value.trim();
  if (!text) return; $('chatInput').value = ''; await sendMessage(text);
});
$('chatInput').addEventListener('input', () => { $('sendButton').disabled = ! $('chatInput').value.trim(); });
$('chatInput').addEventListener('keydown', event => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); $('chatForm').requestSubmit(); } });
$('createDream').addEventListener('click', createDream);
$('refreshHistory').addEventListener('click', refreshHistory);
$('copyDream').addEventListener('click', async () => { if (lastDream) { await navigator.clipboard?.writeText(lastDream.document); $('copyDream').textContent = '✓'; } });
document.querySelectorAll('.workspace-tab').forEach(button => button.addEventListener('click', () => activateWorkspace(button.dataset.workspace)));
document.querySelectorAll('.suggestion').forEach(button => button.addEventListener('click', () => { $('chatInput').value = button.dataset.prompt; $('chatInput').focus(); $('sendButton').disabled = false; }));
document.querySelectorAll('[data-atlas-feature]').forEach(button => button.addEventListener('click', () => {
  const feature = button.dataset.atlasFeature;
  document.dispatchEvent(new CustomEvent('atlas-navigate', { detail: { feature } }));
  if (window.parent !== window) window.parent.postMessage({ type: 'atlas:apollo:navigate', feature }, window.location.origin);
}));

initialize().catch(error => { setStatus(`Apollo initialization failed: ${error.message}`, 'error'); });
