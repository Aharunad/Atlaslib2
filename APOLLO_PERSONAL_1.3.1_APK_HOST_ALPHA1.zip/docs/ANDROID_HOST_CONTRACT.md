# Apollo Android Host Contract v1

## Host responsibilities

The Atlas Library Android host owns native model loading, model asset integrity, OS memory/thermal telemetry, microphone permission, offline ASR/TTS and WebView origin configuration. The JS feature module never reads arbitrary device files or starts arbitrary processes.

## Local inference endpoint

The current JS adapters target OpenAI-compatible loopback endpoints:

- Controller/editor: `http://127.0.0.1:8080/v1`
- Sleeping Giant (optional): `http://127.0.0.1:8081/v1`

Each endpoint must implement:

- `GET /models`
- `POST /chat/completions`
- `messages` with system/user/assistant roles
- JSON-object response mode for structured controller/MoE/editor calls
- Optional Server-Sent Events (`stream: true`) for streamed completions
- `Authorization: Bearer <key>` when a local key is configured

The app rejects non-loopback endpoints. Bind model services to `127.0.0.1`; do not expose an unauthenticated model service to LAN or public interfaces. Disable tools/agent/file-system APIs in the inference server.

For llama.cpp, its server documents `--host`, `--port`, `--cors-origins`, `--api-key`, and the OpenAI-compatible chat completions API. Prefer an exact WebView app origin in CORS configuration; if using a wildcard, keep the server loopback-only and tool execution disabled. Source: https://github.com/ggml-org/llama.cpp/tree/master/tools/server

## Native memory telemetry

The host should supply `totalBytes`, `availableBytes`, `memoryClassMb`, `lowMemory` and thermal status from Android APIs to `ModelResidencyManager`. Never infer free RAM from the device's marketed RAM total.

## Native voice bridge

Expose a JS object `window.AtlasApolloNative` with:

```js
{
  apiVersion: 1,
  asrOffline: true,
  ttsOffline: true,
  listenOnce({ signal, maxChars }): Promise<{ text: string }>,
  stopListening(): Promise<void>,
  speak(text, { signal, voiceId }): Promise<void>,
  stopSpeaking(): Promise<void>
}
```

All ASR/TTS weights must be installed locally before setting the corresponding `*Offline` flag to true. Microphone access must be user-initiated, visible and interruptible. The JS voice coordinator refuses providers that do not explicitly declare offline operation.

## WebView storage

Use an app-private HTTPS-like origin supported by Android WebViewAssetLoader so ES modules, Web Crypto and IndexedDB operate predictably. Keep the origin stable across app upgrades to preserve the IndexedDB database. Avoid `file://` origins for production storage.

## Native model binding

The Android app must use a supported native inference engine and the exact model architecture/quantization. llama.cpp documents an Android Kotlin binding (`examples/llama.android`) using GGUF metadata reader and its `AiChat`/`InferenceEngine` facade. The native source and model files must be built/included in the Android host; this JavaScript release does not include compiled native libraries.

Reference: https://github.com/ggml-org/llama.cpp/blob/master/docs/android.md
