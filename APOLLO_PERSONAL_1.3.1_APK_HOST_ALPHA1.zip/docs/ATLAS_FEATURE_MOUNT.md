# Atlas Library Apollo Feature Mount

Apollo is a separate feature section inside Atlas Library, not a separate APK and not a replacement for Magazine or My Books.

## Feature contract

The Apollo web module lives at `demo/apollo-personal/` and can be hosted by the existing Atlas app shell. It uses the Atlas white design tokens and the approved fluid-intelligence orb.

The feature navigation emits:

- `atlas-navigate` CustomEvent with `{ feature: 'magazine' | 'books' }` when running in the same document.
- For iframe hosting, the host may listen for `postMessage` `{ type: 'atlas:apollo:navigate', feature }` and must validate `event.source`, the known WebView origin and the strict feature allowlist.

The host is responsible for rendering its existing Magazine and My Books modules. Apollo never rewrites those modules.

## Runtime origin

Host the module under a stable, app-private Android WebViewAssetLoader origin. A stable origin is required for IndexedDB persistence and service-worker caching. Do not load the production feature through an ephemeral `file://` origin.

## Persistent store

Apollo uses the existing `createPersistentApolloRuntime()` composition root, app-origin IndexedDB and content-addressed seed/context storage. The API key field is held in memory for the current run and is deliberately excluded from IndexedDB settings persistence.
