# Apollo Personal 1.0.0 — Educational RC1

**Milestone:** Same-day integrated personal edition source candidate  
**Host:** Atlas Library  
**Internal tests:** 112 passed, 0 failed (Node.js test runner)  
**Installable APK:** Not produced in this environment  
**Live pretrained inference:** Not executed; model artifacts/runtime unavailable

## Integrated capabilities

- Atlas-styled Apollo feature module with Conversation, Dream Studio and History.
- Fluid Intelligence orb generated from a compact seed; runtime states map to listening/thinking/speaking/error.
- Persistent IndexedDB conversation and knowledge store using existing v0.5 architecture.
- Loopback-only local inference protocol client for OpenAI-compatible local runtimes.
- Controller SLM, optional Sleeping Giant MoE, editorial and Dream Director adapters.
- On-demand MoE routing and explicit controller fallback when the child model is absent or fails.
- Model residency lease wrapper connected to the existing adaptive resource manager.
- Multi-section Dream text generation, one-section-at-a-time execution, MAKETINY child seeds and verified claim provenance.
- Editorial failure fallback to deterministic claim-preserving assembly.
- Offline ASR/TTS Android host contract; voice turn coordinator requires explicit local providers.
- PWA static shell and source-module precache for app-origin offline startup after first successful install.

## Validation

- 112 automated tests passed, including local loopback HTTP protocol integration.
- All JavaScript files pass Node syntax checks.
- All relative JS imports resolve.
- Service worker static precache paths resolve.
- Tests use deterministic local mock model responses; they validate protocols and orchestration, not pretrained model quality.

## Remaining final-1.0 prerequisites

1. Download and verify a real Qwen3-0.6B GGUF model artifact.
2. Build/package an Android native inference host using a qualified llama.cpp Android binding or compatible runtime.
3. Qualify a real sparse MoE child and its Android expert-loading implementation; MobileMoE-S-QAT remains a research candidate, not a proven Android runtime.
4. Install and integrate actual offline ASR and Kyutai Pocket TTS assets through the native host.
5. Run physical 4 GB Android measurements and blind conversation-quality evaluation.

This source candidate deliberately refuses to generate pretend assistant answers when local model endpoints are missing.
