# Apollo native runtime benchmark status

## What was benchmarked here

The available environment has Node.js and Java/Kotlin compilers, but no Android SDK, Android NDK, physical Android device or local GGUF weights. Therefore a real native inference benchmark could not run here.

A reproducible metadata-only microbenchmark is available:

```bash
npm run adaptive-profile-benchmark
```

Fixture: one synthetic GGUF metadata profile with a 420,000,000-byte file estimate, Qwen3 architecture, 28 layers, 16 attention heads, 8 KV heads, 64-wide K and V dimensions, and 32,768 trained context. Each synthetic device profile uses ARM64. The benchmark performs 500 warmup calls and 5,000 measured calls.

| Synthetic physical RAM | Suggested context | Estimated working set | Budget | Median planner | P95 planner |
|---:|---:|---:|---:|---:|---:|
| 4 GiB | 2,048 | 677 MiB | 737 MiB | 2.77 μs | 6.43 μs |
| 6 GiB | 8,192 | 1,285 MiB | 1,720 MiB | 2.02 μs | 2.39 μs |
| 8 GiB | 8,192 | 1,285 MiB | 2,294 MiB | 2.20 μs | 3.48 μs |
| 12 GiB | 8,192 | 1,285 MiB | 3,441 MiB | 2.18 μs | 2.49 μs |
| 16 GiB | 8,192 | 1,285 MiB | 4,588 MiB | 2.19 μs | 3.18 μs |

The measurements vary with host scheduling and JIT/runtime state. This run measured median planner latency from 2.02 to 2.77 μs and P95 from 2.39 to 6.43 μs. They test that the advisor runs quickly. They do not predict actual model loading, token throughput, phone RAM pressure or thermal behavior.

## What still needs a real device

Run the AAR produced by `.github/workflows/apollo-android-native.yml` inside the parent Atlas Library Android app. Use at least one ARM64 4 GB device and one ARM64 8 GB-or-larger device. For each model, record the SHA-256, quantization, file size, phone/SoC, Android build, thermal state, context, CPU thread count and batch size.

Measure cold-load duration, load peak RSS/PSS, prompt tokens/second, generation tokens/second, steady RSS/PSS, cancellation latency, unload memory release and repeated-run thermal behavior. Run the same model and prompt set on both devices. Do not compare unlike quantizations as if they were the same model.


## In-app native model benchmark

After the Android AAR is built and integrated into the Atlas Library host, load a GGUF model and tap **Benchmark model** in Settings → Apollo → Sleeping Giant. Apollo sends a fixed prompt with greedy sampling and a 96-token output cap. The native runtime returns prompt-token count, generation-token count, prompt decode duration, generation duration, prompt tokens/second and generation tokens/second.

- Prompt throughput times only native prompt decode. It excludes chat formatting and tokenization.
- Generation throughput includes token sampling, token decode and batched streaming callbacks through the host bridge. It is an application-path measurement, not a kernel-only throughput measurement.
- Results are a single run. Use repeated runs after thermal stabilization for comparisons.
- Record model SHA-256, GGUF quantization, file size, device/SoC, physical RAM, Android version, context, CPU threads, batch size, temperature state and benchmark output.
- Do not compare unlike model architectures, quantizations, contexts or prompts as if they were equivalent.
