# Apollo 1.0 Release Gates

This file is the operational checklist used to decide whether a release can advance.

## Gate 0 — v0.4 baseline audit
- [x] Existing kernel/seed/persistence/conversation contract test suite passes (74/74 at v0.4 baseline).
- [x] Limitations documented: no real SLM, MoE, neural editor, ASR/TTS or Android host integration.

## Gate 1 — v0.5 runtime governance
- [ ] Runtime model descriptor schema reviewed.
- [ ] Dynamic memory admission uses live OS telemetry.
- [ ] No active model lease can be evicted.
- [ ] Idle model eviction and cache policy tested.
- [ ] Cancellation and loader-failure recovery tested.
- [ ] Measured model footprint above estimates is rejected safely.
- [ ] Model/license/runtime qualification register reviewed.

## Gate 2 — v0.6 real controller and Apollo chat
- [ ] Real pretrained SLM weights and tokenizer verified by hash.
- [ ] Real Android runtime integrated; no mock adapters in acceptance run.
- [ ] Token streaming, stop, retry and context management work.
- [ ] Conversation survives process restart.
- [ ] Blind prompt set completed and scored.
- [ ] 4 GB profile remains responsive under simulated memory pressure.
- [ ] Apollo UI integrated without altering Magazine/My Books.

## Gate 3 — v0.7 MoE child
- [ ] MoE architecture's own top-k router is used in inference.
- [ ] Android runtime/export path works with actual weights.
- [ ] License is approved for intended distribution.
- [ ] Cold/warm load and active/resident memory recorded.
- [ ] Controller vs controller+MoE blind quality comparison completed.
- [ ] OOM, thermal and unavailable-child fallback tested.

## Gate 4 — v0.8 editorial and procedural Dream
- [ ] Claim ledger preserves facts, inferences, hypotheses, unknowns, caveats and source refs.
- [ ] Neural rewrite semantically preserves required claims.
- [ ] Unsupported additions are identified.
- [ ] Procedural output strategies have deterministic replay tests.
- [ ] Seed/cache benefits measured against storing the full generated artifact.
- [ ] Text outputs can be saved, reopened and reproduced where exact replay is supported.

## Gate 5 — v0.9 voice and host integration
- [ ] Offline ASR tested on target languages.
- [ ] Pocket TTS selected profile runs on device and streams audio.
- [ ] Barge-in/cancel/partial transcripts and audio queue cleanup work.
- [ ] Microphone permission and active listening indicators are correct.
- [ ] Orb state reflects actual pipeline state.
- [ ] Full Magazine/My Books/Apollo regression passes.
- [ ] Two 4 GB-class device families and one 6–8 GB device measured.

## Gate 6 — v0.95 release candidate
- [ ] Clean install, upgrade and model download/resume flows pass.
- [ ] Model artifacts and legal notices verified.
- [ ] Local data export/delete and privacy controls pass.
- [ ] No critical security, data loss, ANR or crash issue remains.
- [ ] Battery, thermals, RAM and storage measured in sustained sessions.
- [ ] Reduced-motion, accessibility and fallback UI pass.

## Gate 7 — v1.0 release
- [ ] Product scope matches the Apollo 1.0 Master Plan.
- [ ] Release notes and dependency manifest complete.
- [ ] All release gates approved.
- [ ] One integrated build is delivered to the user.
