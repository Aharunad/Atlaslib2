# Local Model Setup and Qualification

This release expects an OpenAI-compatible inference service on the same Android device. It accepts only loopback addresses: `127.0.0.1`, `localhost` or `[::1]`.

## Controller candidate

- Model: Qwen3-0.6B Instruct
- GGUF source: https://huggingface.co/ggml-org/Qwen3-0.6B-GGUF
- Candidate artifact: `Qwen3-0.6B-Q4_0.gguf` (approximately 429 MiB)
- Source model license: Apache-2.0; retain the model's license and attribution notices.
- Initial context budget: 2,048 tokens for a 4 GB class profile.

The controller performs conversation routing and direct responses. The same local model can perform the editorial pass to avoid keeping a second SLM resident.

## Local server contract

The local host must expose `/v1/models` and `/v1/chat/completions`. It must support JSON-object response formatting and may support Server-Sent Events for streaming.

For llama.cpp, the server documentation describes Android support, its OpenAI-compatible server, loopback binding, CORS and API-key options:

- Android integration: https://github.com/ggml-org/llama.cpp/blob/master/docs/android.md
- Server: https://github.com/ggml-org/llama.cpp/tree/master/tools/server

The server should bind only to `127.0.0.1`, disable all tools/agent/file operations, and use an API key if the local server supports it. CORS must permit the trusted Atlas WebView origin. Do not bind an unauthenticated local inference API to `0.0.0.0`.

## Sleeping Giant candidate

MobileMoE-S-QAT (1.3B total, 272M active/token, 60 routed experts, top-4) is an interesting research candidate. The model family uses a FAIR NonCommercial license and a custom Transformers implementation. It is not currently accepted as the production Android child: a compatible on-device runtime, expert paging and physical memory/latency measurements are still required.

Source: https://huggingface.co/facebook/MobileMoE-S-QAT

Apollo can operate in controller-only mode when the Sleeping Giant is absent or unavailable. It labels that as a reduced-capability response.

## Voice candidates

- ASR: sherpa-onnx (Apache-2.0, offline Android support): https://github.com/k2-fsa/sherpa-onnx
- TTS: Kyutai Pocket TTS; compare English 18M, 7M and 2M profiles and the Android LiteRT packaging path before selecting a default voice.
- Pocket TTS: https://github.com/kyutai-labs/pocket-tts

Speech assets are not included in this source archive. The native host must set `asrOffline` and `ttsOffline` to true only after the respective model files are installed and verified.
