# Apollo Persistent Memory — Specification v0.4

## Purpose

Provide durable app-private storage for Apollo's content-addressed knowledge, reasoning seeds, MAKETINY parent/child seed lifecycle, conversation sessions and reusable result cache.

## Production adapter

`IndexedDBKVAdapter` is the intended Android WebView/browser adapter. It opens a versioned IndexedDB database (`atlas-library-apollo` by default) with a single `records` object store keyed by string. A single object store allows operations that update a session or multiple cache keys to commit within one IndexedDB read-write transaction.

The database must live under Atlas Library's dedicated app origin. IndexedDB is origin-scoped and subject to platform/browser storage quotas. This adapter does not claim application-level encryption at rest; device sandboxing and optional future encryption are separate controls.

## Internal durable adapter

`FileKVAdapter` is a Node-only test/development adapter. It serializes JSON-compatible records to a temporary file and atomically renames the file after a successful write. It is not the Android production storage implementation and does not provide multi-process locking.

`MemoryKVAdapter` provides atomic in-memory transactions for unit tests.

## Record families

| Prefix | Content | Integrity/lifecycle |
|---|---|---|
| `content:<sha256>` | Canonical knowledge packet | Re-hash and verify on read; deduplicated by digest |
| `seed:<seedId>` | Reasoning seed or MAKETINY seed | Validator required on write/read; child requires stored parent |
| `session:<id>` | Conversation turns and session metadata | Atomic append, revision counter, bounded turns and bytes |
| `cache:<key>` | Reusable deterministic result | TTL, access timestamps, byte-bounded LRU eviction |

## Resource controls

- Content-addressed storage has a total configured payload budget.
- Individual seeds are limited to 64 KiB.
- Session turn count and session byte size are bounded.
- Cache storage is byte-bounded and removes least-recently-used records first.
- Conversation turns are limited to 30,000 characters; metadata and reference lists are bounded.
- Store writes are validated before commit. Failed session updates and adapter transactions leave the previous committed state intact.

## Seed dependency lifecycle

A seed can reference content packets by SHA-256. The persistent store refuses to persist a seed when any referenced packet is missing. A child seed cannot be persisted without its parent. A parent cannot be deleted while persisted child seeds still reference it. Knowledge packets cannot be deleted while any persisted seed references them. Deleting a seed does not automatically delete shared knowledge packets, since other seeds may reference them. Expired cache entries can be pruned explicitly.

The default MAKETINY path is lazy: the parent is persisted, a required child is derived by index, consumed in the current request, and discarded. Child seeds are persisted only when an explicit caller requests persistence.

## Cache integration

`SeedIntelligenceEngine` supports both the existing synchronous in-memory `SeedCache` and asynchronous persistent cache adapters. `ApolloPersistentStore` implements `getAsync`/`setAsync`, allowing deterministic procedural results to survive runtime recreation. Cache keys remain namespaced by engine version and seed ID.

## Limitations

- IndexedDB adapter has not yet been exercised inside the final Android application/WebView. Browser runtime integration is pending.
- Storage quota varies by WebView/device. `QuotaExceededError` must be handled by the app integration layer.
- Persistent content and result cache are not encrypted by this release.
- A physical-device persistence, memory and thermal benchmark has not been run.
