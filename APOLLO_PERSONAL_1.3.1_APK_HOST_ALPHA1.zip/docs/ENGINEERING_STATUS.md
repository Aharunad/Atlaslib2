# Apollo Personal 1.0.0 — Educational RC1 Engineering Status

**Product:** Apollo feature module inside Atlas Library  
**Release:** 1.0.0-educational-rc1  
**State:** Integrated source candidate; final Android/native AI gates remain open.

## Product and experience
- Atlas Library remains three distinct features: Magazine, My Books and Apollo.
- Apollo has a dedicated responsive chat/Dream Studio/history UI.
- Fluid Intelligence orb is procedural and seed-driven; five UI states are represented.
- Magazine/My Books navigation is exposed through host integration events; Apollo does not replace those modules.
- UI uses app-private IndexedDB, no cloud inference and local-only model endpoint settings.

## Intelligence and model integration
- Real OpenAI-compatible loopback client (`/v1/models`, `/v1/chat/completions`).
- SSE delta parsing, cancellation, timeouts, optional local API key and strict loopback-only URL validation.
- Controller SLM adapter: routing plan + structured claim response.
- Optional MoE child adapter: capability-specific structured knowledge packet.
- Editorial adapter: claim-ID preservation contract; safe deterministic fallback if the neural editor fails.
- Sleeping Giant absence/failure triggers controller fallback and explicit `degradedMode` metadata.
- `ResidencyBoundClient` wraps model calls in `ModelResidencyManager` leases.
- Conversation history is bounded by turn count and character budget; the current user request is never clipped.

## Apollo Dreams
- Validated Dream Director plan, 2–8 approved sections.
- Sequential section generation for low-memory devices.
- MAKETINY Dream parent, editorial-plan child and section children are derived on demand.
- Combined knowledge packet is content-addressed and claim provenance is retained.
- Actual MoE use is recorded per section; a failed MoE section can use the controller fallback.
- Editorial neural failure preserves the deterministic generated document instead of deleting the answer.

## Voice
- `ApolloVoiceSession` coordinates offline ASR -> conversation -> offline TTS.
- Android native bridge v1 contract defined.
- The voice feature refuses providers that do not explicitly identify as offline.
- Actual ASR/TTS model assets and Android libraries are not included or executed in this release.

## Internal validation
- Node.js built-in test suite: **112 passed, 0 failed**.
- JavaScript syntax: **52 source/demo/test files checked, all pass**.
- Relative JS imports: **0 missing**.
- Service-worker precache: **41 local assets, 0 missing**.
- Local HTTP E2E: controller plan -> structured response -> editorial adapter -> persistent conversation passed using a local mock server.
- Residency wrapper success/failure lease tests passed.
- Seed replay, integrity, bounded storage, claim audit and MAKETINY tests from previous releases remain in the suite.

## Not demonstrated / final 1.0 gates
- No real pretrained SLM inference; model weights and inference runtime were unavailable in the build environment.
- No real MoE model execution or expert paging benchmark.
- No real neural editorial quality/semantic-equivalence benchmark.
- No Pocket TTS or ASR native model execution.
- No Android APK built: Android SDK, NDK/Gradle toolchain and device were unavailable.
- No physical 4 GB Android memory, latency, battery or thermal test.
- IndexedDB and service-worker behavior has not been exercised inside the final Android WebView host.

## Final release decision
This is a substantial same-day **1.0 Educational RC1 source milestone**, not a claim that the final installed AI is complete. Final Apollo 1.0 requires actual local model artifacts, a compatible Android inference host, native voice integration and physical-device verification. The app explicitly shows a disconnected state when a local model endpoint is absent; it never fabricates live AI capability.


## Sleeping Giant BYOM 1.1.0-alpha.1
- Added user-supplied single-file GGUF import flow in Apollo Settings.
- Added an Android SAF bridge that streams the model into app-private storage, checks available space, computes SHA-256 and verifies the final copy. The original source file is never deleted.
- Added bounded GGUF v2/v3 metadata inspection, persistent model profiles, selection and private-copy removal.
- Added explicit status semantics so an imported file is not presented as inference-ready without a native runtime capability declaration.
- Added license-review acknowledgement state; this is not legal verification.
- Node.js suite: 125 passed, 0 failed.
- Kotlin bridge syntax/type-checked against lightweight Android API stubs; it is not compiled against the Android SDK or installed on a device.
- Still not delivered: Android APK, integrated host build, llama.cpp/ExecuTorch inference, actual tensor-load validation, physical-device memory/thermal benchmarks, and real MoE expert paging.


## Adaptive GGUF profile 1.2.0-alpha.1
- Added Android device capability reporting through `AtlasApolloModelHost.getDeviceProfile(requestId)`.
- Reports physical total/available RAM, Android low-memory flags, CPU count, supported ABIs, app heap class and private storage.
- Extended GGUF metadata inspection with embedding size, attention heads, KV heads and K/V dimensions.
- Added conservative working-set and KV-cache estimates, adaptive context recommendations, CPU thread count and batch size.
- Added Sleeping Giant Settings UI to show device fit and apply a recommended context preference.
- Node.js suite: 136 passed, 0 failed.
- JavaScript syntax: 57 files checked. Relative imports: 148 checked, 0 missing. Service-worker assets: 46 checked, 0 missing.
- Added a regression test that classifies UI resource profiles from total physical RAM, not Android Java heap class.
- Not delivered: Android SDK build, APK, native llama.cpp runtime, real load/generation tests, GPU offload probing or physical-device benchmarks.
- Model fit remains advisory. Native inference must pass load and generation tests before Apollo reports a model ready.


## Apollo 1.3 Native GGUF Alpha 1

- Added pinned llama.cpp JNI source, CPU inference path and a post-load smoke test.
- Added ARM64 Android Gradle AAR target and GitHub Actions build workflow.
- Enabled runtime-detected Arm KleidiAI CPU kernels. GPU backends remain disabled.
- JavaScript tests: 140 passed. Kotlin bridge compiled against lightweight Android API stubs. JNI C++ source passed a syntax check against JNI headers and a minimal llama API stub.
- Not yet verified: real Android NDK link, AAR artifact, parent app integration, phone inference, speed/memory/thermal benchmarks.
- This source package is not an APK. Physical-device qualification remains a release gate.


## Apollo Personal 1.3.0-alpha.3 — Native GGUF Runtime Source

- Preserved BYOM + GGUF + llama.cpp as the primary Sleeping Giant path. SeedLM remains Plan B.
- Added pinned llama.cpp JNI source, an ARM64 Android library module, and a GitHub Actions AAR build workflow.
- Added CPU-only inference, grammar-constrained JSON output, adaptive context/thread/batch settings, token streaming, cancellation, smoke testing and native unload.
- Added controller fallback so a successfully loaded GGUF can serve as Apollo's local controller when the separate controller endpoint is unavailable.
- Added an in-app benchmark action for prompt-prefill and generation tokens/second.
- JavaScript suite: 144 passed, 0 failed. Kotlin compiled against Android/JSON API stubs. C++ passed syntax checks against JNI headers and a minimal llama C-API declaration stub.
- Not delivered or verified: Android NDK link, AAR artifact, parent Android host integration, actual GGUF load, physical-device inference, RAM/PSS, generation speed, cancellation latency, battery or thermal behavior.
- The current artifact is a source alpha, not an APK or a qualified runtime release.
