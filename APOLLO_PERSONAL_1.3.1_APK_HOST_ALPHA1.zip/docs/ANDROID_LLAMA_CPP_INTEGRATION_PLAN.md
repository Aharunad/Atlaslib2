# Apollo native GGUF runtime — implementation and qualification

## Target

Use BYOM as Apollo's model-delivery strategy and llama.cpp as its initial GGUF inference runtime. Keep model weights outside the Atlas Library APK. A validated model identity (`assetId`) is the only model selector exposed to JavaScript.

## Pinned dependency

- Repository: `ggml-org/llama.cpp`
- Revision: `785322d17f2d51e5185cf996a1f4e46d87640841`
- Android target: `arm64-v8a`, Android API 28+
- NDK: `29.0.13113456`
- CMake: `3.31.6`
- Native baseline: CPU only. Arm KleidiAI is enabled for runtime-detected ARM64 kernels. Vulkan/CUDA/Metal/OpenMP/llamafile/OpenSSL are disabled.

The pin and build are defined in `.github/workflows/apollo-android-native.yml` and `android-host/native/CMakeLists.txt`.

## Implemented native path

1. `ApolloSleepingGiantBridge` imports one GGUF through the Android Storage Access Framework.
2. The bridge stores the file under the app-private `filesDir/apollo/models/` directory and verifies SHA-256.
3. It checks an adaptive device/model memory estimate before native loading.
4. `ApolloLlamaCppRuntime` provides the narrow Kotlin JNI facade.
5. `apollo_llama_jni.cpp` owns native model, context and sampler lifetimes behind opaque session IDs.
6. Native code formats messages using the GGUF chat template when available, tokenizes them, decodes the prompt and generates sampled tokens. Structured adapter calls use a GBNF JSON-object grammar. Temperature zero uses greedy sampling.
7. A single native decode batch is reused across output steps to avoid per-token allocation. Native token callbacks are batched into small UTF-8 chunks before they reach the WebView. Cancellation uses `llama_context_params.abort_callback` and an atomic session flag.
8. The feature runs a short smoke prompt. The model becomes active for Sleeping Giant delegation only after non-empty output.
9. Unload cancels the session, waits for the operation mutex and releases sampler, context and model resources.

## Native interface used

The implementation uses the pinned C API: `llama_backend_init`, `llama_model_load_from_file`, `llama_init_from_model`, `llama_tokenize`, `llama_chat_apply_template`, `llama_batch_init`, `llama_decode`, sampler-chain APIs, `llama_token_to_piece`, `llama_memory_clear`, `llama_free` and `llama_model_free`.

The JavaScript application receives neither local filesystem paths nor native pointers. It sends chat content and an opaque session ID through the trusted Android bridge.

## Current restrictions

- One single-file GGUF per import.
- ARM64 Android only.
- CPU-only. No Vulkan backend is packaged or advertised.
- One native Sleeping Giant loaded at a time.
- One generation request at a time.
- Temperature-aware sampling for text generation. Structured controller/editor calls use constrained JSON-object grammar. Temperature zero uses greedy decoding.
- The native runtime advertises a wildcard architecture candidate because its pinned loader is authoritative. This avoids blocking new upstream architecture support. The exact GGUF must still load successfully and pass the generation smoke test.
- Model context, batch size and thread count are bounded before native calls.

## Benchmarks and qualification gates

The Settings → Apollo → Sleeping Giant screen provides a **Benchmark model** action after a successful load. It reports prompt-prefill and generation tokens per second from native timing counters. A benchmark result is valid only when it identifies the model hash, model quantization, Android device/SoC, RAM, OS build, thermal state, context, thread count, batch size and runtime revision.

| Gate | Measurement | Pass condition |
|---|---|---|
| Build | Release AAR contains `libapollo_llama_jni.so` for AArch64 | CI build passes and ELF machine is AArch64 |
| Load | Cold model-load duration and load peak RSS/PSS | No OOM or native crash |
| Smoke | Deterministic short prompt returns non-empty text | Successful native decode |
| Throughput | Prompt tokens/s and generation tokens/s | Record actual measured baseline; no invented target |
| Memory | Peak and steady RSS/PSS, plus model/ctx allocator stats if available | Remains under device policy with headroom |
| Cancellation | Cancel during prompt decode and generation | Native decode returns and session remains unloadable |
| Unload | RSS/PSS and native allocation after unload | Native resources are released; second load succeeds |
| Thermal | Repeated prompt/generation run with temperature/thermal status | No instability or uncontrolled throttling |

## Environment validation performed for this source milestone

- JavaScript suite: 144 tests passed.
- Native C++ JNI translation unit: syntax-checked against the Java 21 JNI headers and a minimal llama C-API declaration stub. This catches C++/JNI syntax errors only. It does not validate ABI or link compatibility with the real llama.cpp source.
- Kotlin JNI facade: compiled with Kotlin/JVM compiler.
- Android Gradle/NDK build: not run because this environment has no Android SDK/NDK and cannot fetch the upstream source checkout directly.
- Physical Android inference and performance benchmarks: not run because no Android device/model weights are attached to this environment.

The GitHub Actions workflow performs the pinned upstream checkout, native ARM64 build and AAR ELF verification. Physical-device benchmarks remain a required release gate.

## Adaptive planner microbenchmark

The reproducible benchmark is `node benchmarks/adaptive-profile-preflight.js`. It uses one synthetic 420,000,000-byte Qwen3-like GGUF metadata profile, 500 warmup runs and 5,000 measured planner calls per synthetic device. It does not load weights or execute inference.

| Synthetic total RAM | Recommended context | Estimated working set | Conservative budget | Median planner | P95 planner |
|---:|---:|---:|---:|---:|---:|
| 4 GiB | 2,048 | 677 MiB | 737 MiB | 2.77 μs | 6.43 μs |
| 6 GiB | 8,192 | 1,285 MiB | 1,720 MiB | 2.02 μs | 2.39 μs |
| 8 GiB | 8,192 | 1,285 MiB | 2,294 MiB | 2.20 μs | 3.48 μs |
| 12 GiB | 8,192 | 1,285 MiB | 3,441 MiB | 2.18 μs | 2.49 μs |
| 16 GiB | 8,192 | 1,285 MiB | 4,588 MiB | 2.19 μs | 3.18 μs |

These results measure only the local metadata planner on the development host. They are not phone memory or inference measurements.

## Next qualification step

Run `.github/workflows/apollo-android-native.yml` in the Atlas Library source repository. If it passes, integrate the produced AAR into the parent Android application, then run the device benchmark matrix. Keep SeedLM as Plan B until its Android decoder beats this GGUF baseline on measured quality, memory, latency and battery.
