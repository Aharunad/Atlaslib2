# Sleeping Giant BYOM — Alpha 1 integration

**Product:** Apollo inside Atlas Library  
**Original intake milestone:** 1.1.0-alpha.1
**Adaptive profile update:** 1.2.0-alpha.1  
**Intake format:** single-file GGUF  
**Model policy:** Bring Your Own Model (BYOM)

## Product decision

Sleeping Giant model weights are not bundled in the Atlas Library application. The user chooses a model from Android storage. Apollo inspects and registers that model as a separate local asset. Model weights remain ordinary model data; MAKETINY seeds and Apollo manifests describe deterministic configuration and task plans, not replacement weights or compression of the model.

## Import pipeline in this milestone

1. The Apollo Settings panel invokes the trusted Android host's model bridge.
2. Android Storage Access Framework opens a user-controlled file picker.
3. The selected file is streamed into `filesDir/apollo/models/` as a temporary private copy. No broad storage permission is requested.
4. The host computes SHA-256 while copying, checks the declared source size, preserves a minimum free-storage reserve, and fsyncs the copied bytes.
5. Apollo reads the final private file back and compares its SHA-256 with the copy-stream digest.
6. A bounded GGUF metadata inspector reads at most 16 MiB of metadata. It extracts architecture, model name, tensor count, quantization/file-type code, tokenizer metadata, chat-template presence, context length, layer count, embedding length, attention head counts, KV head counts, key/value dimensions and MoE expert counts when the file declares them.
7. The JS registry writes an immutable-shaped profile into the existing app-origin IndexedDB store and selects it as the current Sleeping Giant profile.
8. The original file is never deleted. Removing a model deletes only the private Atlas copy and its profile, after explicit user confirmation.

## Compatibility semantics

The registry distinguishes the following states:

- `needs_runtime`: model metadata passed inspection, but no native inference runtime is connected.
- `runtime_compatible`: a connected runtime explicitly advertises the GGUF format and the model architecture. This still requires a load-time test.
- `unsupported_format` / `unsupported_architecture`: the connected runtime does not advertise the required support.
- `invalid`: required GGUF metadata is missing or invalid.

**Alpha 1 intentionally returns `needs_runtime`.** The Android bridge can import, hash and inspect a model, but it does not yet load tensors or run inference. The existing OpenAI-compatible loopback adapter remains a separate route to a local inference service. Registering a Sleeping Giant file does not silently redirect conversation traffic to it.

## GGUF inspection boundary

The GGUF reader accepts versions 2 and 3 in little-endian form and validates the magic header, tensor count, metadata count, strings and bounded metadata arrays. It does not parse tensor payloads, validate every tensor offset, certify model quality, certify architecture support, or load model weights. A SHA-256 fingerprint identifies bytes; it does not establish publisher authenticity or license rights.

Initial support is limited to one GGUF file. Directory-based sharded models, `.safetensors`, automatic conversion and model downloads are deliberately not in this tranche.

## Storage trade-off

The current Android implementation copies the chosen file to app-private storage so a future native runtime can use a stable local file. This costs additional free storage approximately equal to the model size while the original remains in place. Apollo checks available storage and reserves a safety margin before copying, then aborts and deletes an incomplete temporary file if the budget is exceeded. The Settings panel states this before the user starts.

This is a reliability-first choice, not the final storage optimization. A future URI-backed mode may avoid the duplicate copy, but it must be qualified against the selected runtime's file-descriptor and memory-mapping behavior before being presented as inference-ready.

## Security and privacy

- Android native bridge is exposed under the dedicated `AtlasApolloModelHost` name and checks the configured trusted WebView origin.
- The host accepts only request IDs and model asset IDs matching strict allowlists.
- Model content is parsed as bounded data; no model-defined code, commands, network actions or device operations are executed.
- App-managed model paths are derived from a validated SHA-256-based asset ID, never from model metadata or a path supplied by JavaScript.
- Import uses a streaming buffer rather than loading model weights into RAM.
- Original selected documents are not deleted, moved or modified.
- The model registry stores no source URI or raw filesystem path.
- License status remains `pending_user_review` until the user records that they reviewed the model's license. That record is only a user acknowledgement, not legal verification.

## Files added or changed

- `src/runtime/gguf-inspector.js` — bounded JS GGUF metadata reader for fixtures and compatible Blob inputs.
- `src/runtime/sleeping-giant-registry.js` — persistent model profiles, selection and safe removal semantics.
- `src/runtime/android-sleeping-giant-bridge.js` — asynchronous bridge to the Android host.
- `android-host/src/main/java/com/atlaslibrary/apollo/model/ApolloSleepingGiantBridge.kt` — SAF picker, private copy, streaming SHA-256, progress events and native GGUF inspection.
- `demo/apollo-personal/index.html` / `styles.css` / `app.js` — Settings UI, progress, installed-model list, compatibility state and license-review acknowledgement.
- `demo/apollo-personal/sw.js` — cache version and offline assets updated for the new modules.

## Adaptive device profile update (1.2 Alpha 1)

The Android host now exposes a device-profile method. It reports total and available RAM, low-memory flags, CPU core count, ABIs, app heap class and private storage. Apollo estimates model working set and KV-cache cost, then recommends a conservative context size, CPU thread count and batch size. These estimates are advisory. They do not establish that a model can load. The runtime must perform a real load and generation test.

## Remaining gates

1. Merge the Kotlin host bridge into Atlas Library's actual Android `ComponentActivity` and trusted WebView.
2. Build the Android host APK with the existing project Gradle configuration.
3. Connect a pinned llama.cpp or other qualified inference runtime and advertise exact supported GGUF architectures.
4. Load and unload a real test model through `ModelResidencyManager`; record cold-load time, resident memory, peak memory, context/KV cost, generation speed and thermal behavior on the target Android device.
5. Validate larger MoE-specific behavior. Metadata expert counts alone do not prove expert-selective loading or paging.

## Validation in this source workspace

- Node.js test suite: 125 passed, 0 failed.
- The GGUF parser tests use synthetic files; they validate parser behavior, not a production model's tensor integrity or runtime inference.
- Kotlin source is supplied as a host integration component, but this workspace has no Atlas Android host project, Android SDK/Gradle build, or model runtime. The Kotlin bridge was syntax/type-checked against lightweight Android API stubs, but it has not been compiled against a real Android SDK or device-tested here.
