# Apollo Personal 1.0 — Acceptance Matrix

| Capability | Source implementation | Live evidence in this release | Final 1.0 gate |
|---|---|---|---|
| Atlas Apollo UI | Complete feature module | Static syntax and source checks | Integrate inside production Atlas Android host |
| Fluid orb | Seeded procedural SVG renderer | Existing deterministic unit tests | Confirm smooth GPU behavior on 4 GB phone |
| Persistent sessions | IndexedDB-backed store | Existing storage regression tests | Exercise inside stable Android WebView origin |
| Local model transport | OpenAI-compatible loopback client | Mock HTTP protocol tests only | Connect actual Qwen/llama.cpp endpoint |
| Controller SLM | Concrete adapter | Prompt/JSON adapter tests only | Actual pretrained inference and blind evaluation |
| Sleeping Giant MoE | Concrete adapter + explicit fallback | Mock adapter tests only | Actual sparse MoE + qualified runtime and expert loading |
| Editorial engine | Concrete SLM editor adapter | Claim-ID contract tests only | Semantic preservation and quality evaluation |
| Dream Studio | Multi-section Dream compositor | Mock section generation + MAKETINY test | Generate from real models; quality and provenance review |
| Offline ASR | Native voice contract | Contract tests only | Install and execute real offline ASR on Android |
| Pocket TTS | Native voice contract | Contract tests only | Install and execute actual Pocket TTS/Android package |
| 4 GB memory governance | Runtime supervisor | Synthetic live-memory test snapshots | Physical PSS/RSS, KV, ANR, battery and thermal measurements |
| No cloud inference | Loopback-only URL validator | Unit tests reject non-loopback endpoints | Android app host audit and network capture |

## Release status

This release is **Educational RC1 source**, not a final product-complete Apollo 1.0 APK. Final 1.0 requires actual weights/runtime/host integration and device measurements. Model adapter tests do not count as live model inference.
