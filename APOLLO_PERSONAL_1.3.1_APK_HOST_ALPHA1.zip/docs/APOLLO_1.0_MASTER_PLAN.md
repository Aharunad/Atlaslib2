# APOLLO 1.0 — Master Development Programme

**Project:** Apollo's Dream  
**Host application:** Atlas Library  
**Plan revision:** 1.0  
**Baseline:** Apollo's Dream v0.4.0  
**Current engineering release:** v0.5.0 — Runtime Governance Foundation (completed internally on 2026-11-01)  
**Release objective:** A dependable, offline-first conversational intelligence feature integrated as the third section of Atlas Library.

---

## 1. Product outcome

Apollo 1.0 is a personal offline conversational assistant inside Atlas Library. It must feel like one coherent companion while internally orchestrating a small controller SLM, an on-demand larger sparse MoE child, procedural reasoning and text-generation strategies, an editorial validation stage, local conversation memory, offline speech recognition, and natural speech synthesis.

Apollo is **not** a separate APK or a replacement application. Atlas Library remains the host and retains three independent product areas:

1. **Magazine** — RSS discovery and editorial curation.
2. **My Books** — PDF/EPUB import, clean reading and Pocket TTS support.
3. **Apollo** — conversation, intelligence, voice and Dream-generated text experiences.

Apollo must not rewrite or destabilize Magazine or My Books.

## 2. Product and design invariants

- Navigation label is exactly **Apollo**.
- The visual identity is the **fluid intelligence orb**: layered translucent ribbons with cyan, turquoise, magenta, coral and violet accents. Do not use the dotted orbital sphere as Apollo's identity.
- Atlas Library's host chrome remains white, restrained, modern and mobile-first.
- Apollo's intelligence is allowed to be sophisticated; the user-facing interaction must remain simple.
- Text conversation is the first complete capability. Voice follows after text quality and runtime stability.
- Procedural generation and seed-based reuse are preferred when they measurably reduce storage, repeated work, RAM, latency or compute. Never force procedural machinery where a direct representation is smaller, faster or more reliable.
- Seeds are declarative plans/references, not executable code, arbitrary model weights, or self-contained knowledge unless all required information is actually encoded in them.
- Model weights, tokenizers, runtimes and voice assets remain explicit, licensed dependencies.
- All model output is untrusted input. It must pass schema, provenance, resource and safety validation.
- No network access is required for normal conversation after model assets are installed. Optional update/download flows are separate from inference.

## 3. Target device tiers

### Primary: 4 GB RAM Android

The constrained profile is the product floor. The application must remain usable even when the OS reports memory pressure. Apollo may reduce context length, disable prefetch, serialize model stages, evict warm models, lower voice quality or fall back to text-only operation rather than cause an app crash.

### Secondary: 6–8 GB RAM Android

May keep a controller warm while preparing a child model when live telemetry demonstrates safe headroom. Larger context and voice profiles are optional.

### Premium: 8 GB+ Android

May enable more warm caching, larger context windows and higher-quality audio. No premium setting may be required for the core Apollo experience.

**Important:** “4 GB compatible” is not accepted based on model-weight size alone. Acceptance requires measured peak process RSS/PSS, available-memory headroom, KV-cache use, loading spikes, thermal behavior, and a sustained conversation session on physical devices.

## 4. Target architecture

```text
Atlas Library host
  ├─ Magazine (unchanged feature module)
  ├─ My Books (unchanged feature module)
  └─ Apollo feature module
       ├─ Apollo UI + fluid orb state machine
       ├─ Conversation/session service
       ├─ Dream Director
       │    ├─ MAKETINY parent/child seed planner
       │    ├─ procedural strategy registry
       │    └─ resource-aware task planner
       ├─ Compute cascade
       │    ├─ deterministic/procedural operators
       │    ├─ controller SLM
       │    └─ Sleeping Giant MoE child (qualified model only)
       ├─ Claim/evidence ledger
       ├─ Editorial engine + semantic integrity checks
       ├─ Seed/context/result cache
       ├─ Voice turn coordinator
       │    ├─ offline ASR
       │    └─ Pocket TTS
       └─ Model Runtime Supervisor
            ├─ model catalog and license manifest
            ├─ dynamic RAM budget
            ├─ load / lease / unload lifecycle
            └─ cancellation, back-pressure and telemetry
```

The fixed runtime remains trusted. A model or Dream Blueprint may select registered capabilities and composition recipes, but cannot provide executable code, install plugins, invoke arbitrary file/network actions, or bypass resource limits.

## 5. Release schedule and scope

The schedule is gate-driven. v0.5.0 is now completed internally on 2026-11-01. Calendar estimates below start from this baseline and assume regular development sessions plus timely availability of model artifacts and the full Android host source tree. They are planning estimates, not a promise of background work or fixed ship dates. A gate does not close merely because a date passes. The current planning window for 1.0 is late January to February 2027; model compatibility, licensing and physical-device validation can move it.

| Release | Target window | Major delivery | Exit condition |
|---|---:|---|---|
| **v0.4.0** | Baseline | Dream Kernel, Seed Intelligence, MAKETINY 2.0, persistence and conversation contracts | Existing 74-test suite passes; adapters are still deterministic test adapters. |
| **v0.5.0** | Completed 2026-11-01 | Model Runtime Supervisor, resource admission, lifecycle/eviction, model qualification matrix and final 1.0 plan | **Completed:** 89/89 tests pass; runtime lifecycle and failure paths tested; models remain explicitly unconnected. |
| **v0.6.0** | 2–3 weeks | Real controller SLM, streaming chat, cancellation, token/context management, Apollo conversation UI and local model setup/status | Actual pretrained model answers a blind benchmark through the app module; host UI is integrated without changing other Atlas features. |
| **v0.7.0** | 2–4 weeks | Sleeping Giant MoE child, on-demand delegation, compatible runtime, memory-aware expert/model residency, direct-route fallback | Real MoE inference passes the same prompt set; delegation improves quality or capability enough to justify its loading cost; license is cleared for intended distribution. |
| **v0.8.0** | 2–3 weeks | Neural editorial engine, claim ledger, semantic preservation tests, Dream Director and procedural text-generation experiences | Editorial output is measurably clearer without material loss of claims, caveats or provenance; Dream output is repeatable and bounded. |
| **v0.9.0** | 2–4 weeks | Offline ASR + Pocket TTS, natural voice turn-taking, fluid orb runtime states, integrated Atlas feature regression and physical-device optimization | End-to-end voice conversation works offline; 4 GB-class device validation and low-memory fallback pass. |
| **v0.95 RC** | 1–2 weeks | Release hardening, license/privacy/security audit, model asset manifest, recovery, accessibility, crash/performance profiling and migration tests | No known release-blocking issue; clean install and upgrade paths pass; all dependencies have distribution approval. |
| **v1.0.0** | After RC gate | Apollo becomes an optional, stable third Atlas Library section | All 1.0 acceptance criteria below pass; user receives one substantial release, not a stream of partial builds. |

**Expected planning range from the v0.5.0 baseline:** approximately 12–16 weeks of focused engineering, placing the current 1.0 planning target in late January–February 2027. This is conditional on model/runtime integration, licensing and physical-device validation. MoE runtime compatibility is the largest technical uncertainty.

## 6. Detailed milestone requirements

### v0.5.0 — Runtime governance foundation

- Model descriptor schema: model ID, role, revision, tokenizer, weight bytes, base runtime working set, KV bytes/token, maximum context, license, artifact digest, runtime compatibility and cache policy.
- Dynamic memory budget from host-provided `totalMem`, `availableMem`, low-memory and thermal telemetry. Never infer free RAM from the phone's marketed RAM class.
- Model state machine: unloaded → loading → ready → leased → unloading; failure and cancellation states explicit.
- One model load/unload admission path; deduplicate concurrent requests for the same model.
- LRU/priority eviction for idle models; never evict an actively leased model.
- Ephemeral model policy for speech models; warm model policy for the controller where headroom permits.
- Per-request KV/context reservations and strict output/context caps.
- Model runtime adapters remain interfaces until a real backend is qualified.
- Benchmark schemas for cold load, warm load, TTFT, tokens/sec, peak RSS/PSS, context memory, thermal drift, battery and cancellation.

### v0.6.0 — Real controller SLM and conversational Apollo

- Compare at least two small instruct models on the same blind prompt set.
- Initial candidate: Qwen3-0.6B instruct family; use a compatible quantized artifact and confirm the exact license for the selected checkpoint.
- Evaluate ExecuTorch Android, llama.cpp Android and MLC-LLM where the exact model architecture and export format are supported; evaluate vendor acceleration as an optional backend where available.
- Streaming token UI, stop/cancel, retry, context truncation/summarization, conversation persistence, model download/integrity screen and honest model state.
- Small-model responsibility is deliberately narrow: understand intent, decide delegation, handle lightweight conversation and coordinate tools.
- No fabricated “MoE response” when the child is unavailable.

### v0.7.0 — Sleeping Giant MoE

- Qualify an actual sparse MoE checkpoint and its inference/export path.
- Verify experts are selected by the model's own router; Apollo's scheduler may select task capabilities and manage residency, but may not fake expert activation by slicing arbitrary dense-model weights.
- Benchmark cold/warm model loading, active parameters, total weight storage, model-resident RAM, KV cache, expert weight I/O, TTFT and sustained token rate.
- Compare controller-only against controller→MoE on identical prompts.
- MoE is used only when the expected quality/capability benefit outweighs its loading, power and thermal cost.
- A non-commercial research license is not sufficient for a general distributable Atlas Library release unless the app's intended use and distribution are explicitly cleared.

### v0.8.0 — Editorial Intelligence + Dream Creation

- Neural editor converts validated claims into clean editorial prose.
- Claim IDs, source references, epistemic type, caveats and uncertainty remain available through rewrite.
- Structural claim preservation plus semantic comparison; structural ID preservation alone is not proof that meaning survived.
- Procedural content composer creates articles, explanations, comparisons, learning guides and structured reports.
- Dream Director writes blueprints; fixed generators create approved content and layout forms.
- Seeded variation changes presentation/strategy while fixed content facts remain grounded.
- Cache only stable transformations. Version keys include model, tokenizer, runtime, prompt template, generator, context hashes and settings.

### v0.9.0 — Natural voice + complete Atlas integration

- Offline ASR through a qualified Android runtime (sherpa-onnx is the first candidate), with English first and additional languages only after accuracy/latency qualification.
- Pocket TTS qualification compares the October 2026 18.2M/6.9M/1.9M CPU variants against Android LiteRT packages (including the English-only PocketTTS bundle and multilingual package) and other suitable local voices. The highest-quality profile is selected only after listening tests and device benchmarks; smaller profiles are fallbacks. New tiny English checkpoints are not assumed to have an Android-native path until proved.
- Voice activity detection, streaming, interruption/barge-in, silence timeout, audio queue cleanup and graceful fallback.
- Apollo orb states derive from actual runtime events: idle, listening, planning, waiting for child, composing, speaking, low-memory and unavailable.
- User can pause voice and continue in text without losing context.
- Complete regression of Magazine and My Books in the production Atlas Library host.

### v1.0.0 — Release definition

- Offline text conversations through a real controller model.
- Real MoE delegation when the qualified child is installed and supported; robust controller-only fallback otherwise.
- Editorial rewrite with claim/provenance integrity.
- Procedural text experiences driven by Dream Blueprints and MAKETINY seed hierarchy.
- Offline voice input/output with graceful low-resource profiles.
- Persistent, bounded and integrity-checked local sessions/cache.
- Clear local model storage, license, privacy and deletion controls.
- No arbitrary model-generated code execution or unrestricted tool access.
- Atlas Library Magazine and My Books remain unchanged in their feature contracts.

## 7. Apollo 1.0 acceptance gates

### Product
- Navigation label is **Apollo**.
- Fluid orb matches the approved reference; reduced-motion and low-power modes exist.
- Text chat and voice feel like one continuous conversation.
- No forced user interaction with model files, Termux or command-line tools.

### Intelligence quality
- At least 300 blind prompts spanning general conversation, explanation, reasoning, factual uncertainty, multi-turn follow-up, editorial transformation and unsupported requests.
- Compare controller-only, controller+MoE and full pipeline.
- Human preference and rubric-based accuracy/completeness scoring.
- Explicit abstention where source/context is insufficient.
- No broad “GPT/Gemini parity” claim without external benchmark evidence.

### Performance
- Physical devices from at least two 4 GB-class Android families, plus one 6–8 GB reference device.
- Record clean-start and warm-start TTFT, decode throughput, peak PSS/RSS, model load/unload time, KV memory, CPU/GPU/NPU usage, battery/thermal drift and crash/ANR rate.
- OS low-memory signal must cause safe degradation, not process death.
- The runtime supervisor must never evict an active model lease.
- Do not set fixed token/s or latency claims until measurements exist on the target device matrix.

### Reliability and privacy
- Full offline test after model assets are downloaded.
- Model checksums and signed/verified manifest for distributed artifacts.
- App-private storage, clear/delete controls, retention policy and optional encryption at rest.
- No executable payloads in Dream Seeds or knowledge packets.
- No background microphone use without an explicit active listening session and visible state.
- Conversation state survives restart and handles interrupted generation without corrupting the transcript.

### Licensing
- Maintain a manifest of model, tokenizer, voice and runtime licenses.
- No non-commercial-only model in a generally distributed release without legal permission/clearance.
- Include notices and attribution required by each asset.

## 8. Measurement protocol

All A/B/C comparisons use the same prompts, sampling settings where applicable, context budget and device state. Capture raw output and metadata. Separate:

- model weights on disk,
- application/runtime size,
- active resident memory,
- KV/context memory,
- cached knowledge and generated text,
- transient seeds/manifests,
- voice model assets.

Seed-size savings must never be reported as model-weight compression or total application compression. A seed saves storage only for the data actually reconstructible from its recipe and already-installed generator; it does not create unknown learned information.

## 9. Release and communication discipline

- Internally test every integrated milestone.
- User receives notifications only at major milestone completion or a real blocker requiring a decision.
- No install/test request for small incremental builds.
- First user-facing test build is targeted for the complete v0.9.0 integrated milestone, subject to the physical-device validation plan.
- Do not claim a release, benchmark, model integration or hardware result that was not actually executed.
