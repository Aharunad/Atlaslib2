# Apollo Model and Runtime Qualification Register

**Status:** Candidate register, not a production lock.  
**Last reviewed:** 2026-11-01.

## Controller SLM candidates

| Candidate | Why considered | Known evidence | Qualification decision |
|---|---|---|---|
| Qwen3-0.6B Instruct family | Small controller size; multilingual; capable of intent, routing and light conversation | Qwen3 0.6B family has Apache-2.0 base checkpoint; Qualcomm publishes device-specific optimized Android results for Qwen3-0.6B on Snapdragon platforms | **Primary candidate for v0.6 evaluation**, after checking exact instruct checkpoint license, tokenizer/chat template, supported runtime and target-device memory. |
| Alternative 0.3B–1B instruct SLM | Needed as a fallback if controller memory, output format or language quality is poor | Must be shortlisted and evaluated using the same benchmark, not selected by parameter count alone | Keep open until v0.6 blind evaluation. |

## MoE child candidates

| Candidate | Why considered | Known evidence | Qualification decision |
|---|---|---|---|
| Meta MobileMoE-S-QAT | 1.3B total, 272M active/token, 60 routed experts, top-4; projected INT4 weight memory 0.68 GB; mobile-first | Model card reports 0.71 GB packaged checkpoint; custom `model_type: mobilemoe`, requires `trust_remote_code=True`; architecture is not yet upstream Transformers; license is FAIR NonCommercial | **Research candidate only. Do not ship by default** unless intended distribution is cleared and an Android-compatible runtime/export path is demonstrated. |
| Alternative sparse MoE with distribution-compatible license | Preserve the Sleeping Giant design without non-commercial restriction | Must demonstrate actual token-level sparse routing, supported Android backend, total disk footprint, active/resident memory, and usable quality | **Required production search track.** Do not substitute dense weight slicing and call it MoE. |

## Runtime candidates

| Runtime | Strength | Risks / gate |
|---|---|---|
| ExecuTorch Android AAR | Java/Kotlin integration; Android CPU/XNNPACK and optional hardware backends; LLM APIs | Verify exact SLM and custom MoE export support, model kernels, streaming callback behavior and quantization on supported ABI. |
| llama.cpp Android | GGUF ecosystem, native Android integration, broad CPU compatibility and supported model families | Exact model architecture must be supported; custom MobileMoE architecture cannot be assumed to load. |
| MLC-LLM Android | Compiled per-model runtime and Android demo/build path | Requires model conversion and target-device compilation; custom sparse architecture compatibility must be proven. |
| Qualcomm AI Hub / Genie/QAIRT | Published optimized Qwen3-0.6B paths and measured Qualcomm hardware performance | Hardware-specific; do not make it the only backend for the general Android fleet. Confirm current product/runtime support before integration. |

## Voice candidates

### TTS

Kyutai Pocket TTS is the preferred model family to benchmark, but the Android deployment path must be selected by measured audio quality, artifact size and runtime fit.

- **Quality candidate:** Kyutai's October 2026 `english_18m_2026-10` (18.2M parameters including decoder). Its published one-thread CPU speed is approximately 9.9× real time. It is the first candidate for listening-quality evaluation, but the model-specific Android packaging path still needs proof.
- **Smaller neural candidates:** 6.9M and 1.9M English variants. Published CPU speeds are approximately 12.6× and 25× real time respectively; the 1.9M variant is experimental and should not be selected without listening tests.
- **Android-ready comparison:** Google's LiteRT Audio/TTS documentation lists PocketTTS 100M bundles, including an English-only bundle around 163 MB and a multilingual bundle around 760 MB, both CPU-run; it also lists Kokoro-82M around 295 MB with GPU delegate and nine locales. A community Pocket-TTS-LiteRT implementation reports Android GPU use, but it must be treated as a separate community runtime and validated independently.
- The release choice is the best measured model that meets 4 GB memory, latency and language requirements—not automatically the smallest parameter count.

### ASR

`sherpa-onnx` is the first offline Android speech-recognition integration candidate. Its official project supports ARM64 Android, streaming/non-streaming ASR, VAD and Java/Kotlin APIs. Select the actual model separately; the runtime's Apache-2.0 code license does not automatically apply to model weights. Evaluate partial transcripts, endpointing, VAD, noise robustness and cancellation. English is first; French and Arabic require separate accuracy/latency gates.

## Model selection policy

No model is selected solely because it has fewer parameters or a high vendor benchmark. Selection requires:

1. Verified license and attribution obligations.
2. Exact checkpoint and tokenizer hashes.
3. Android runtime compatibility.
4. Real target-device cold/warm latency and memory measurement.
5. Blind conversational quality evaluation.
6. Model lifecycle, cancellation and low-memory recovery tests.
7. Clear fallback behavior when the model is unsupported or absent.
