# Apollo's Dream — Product Constitution

## Product identity
- Product name: **Apollo**.
- Parent application: **Atlas Library**.
- Navigation label: **Apollo** (never “APK Apollo”).
- Visual identity: fluid intelligence orb with translucent, interwoven ribbons in magenta, coral, cyan and violet.
- Host application style: white, clean, modern, restrained typography, subtle dividers and quiet surfaces.

## Atlas Library structure
1. Magazine: RSS collection and editorial curation.
2. My Books: PDF/EPUB reading experience and Pocket TTS.
3. Apollo: personal conversational intelligence.

Apollo is an independent feature module inside Atlas Library. It must not replace or destabilize the Magazine or My Books features.

## Apollo capability direction
- Small controller SLM designed for 4 GB RAM Android devices.
- Larger sparse MoE child, used on demand where supported.
- Structured information exchange between child and controller/editor.
- Editorial-quality text generation.
- Offline speech recognition and natural speech synthesis.
- Procedural experience generation from validated blueprints.
- Bounded, versioned, integrity-checked local cache.

## “Miracle Code” definition
The name for the central generative architecture is **Dream Kernel**. It converts a high-level intent and approved capability set into a versioned Dream Blueprint, validates it against strict constraints, and compiles it into a component tree rendered by a fixed runtime.

The magic is in coordinated composition, not arbitrary code execution. The kernel may choose among registered generation strategies, but it cannot invent executable code, load untrusted plugins, or bypass the renderer's component/action allowlists.

## Non-negotiable principles
- Offline-first.
- Measure actual storage, RAM, latency, energy and output quality.
- Do not claim broad intelligence parity without blind evaluation.
- Model weights remain real assets; seeds do not recreate arbitrary learned weights without the information or training process.
- Preserve factual meaning and uncertainty through editorial transformation.
- Dynamic UI must remain accessible, responsive and bounded.
- Never change Atlas Library's existing product structure without explicit approval.
