# Apollo's Dream — Locked Release Roadmap

The authoritative release sequence, detailed scope, schedule estimates and acceptance criteria are maintained in [`APOLLO_1.0_MASTER_PLAN.md`](./APOLLO_1.0_MASTER_PLAN.md). Do not fork an alternate roadmap.

| Release | Name | Status |
|---|---|---|
| v0.4.0 | Persistent Seed Memory + Conversation Contracts | Completed internally; deterministic test adapters only |
| v0.5.0 | Runtime Governance + Miracle Insights 1.0 | Implemented; 88/88 tests passing |
| v0.6.0 | Real Controller SLM + Apollo Conversation | Next major milestone |
| v0.7.0 | Sleeping Giant MoE | Model/license/runtime qualification required |
| v0.8.0 | Editorial Intelligence + Procedural Dream Creation | Planned |
| v0.9.0 | Offline Voice + Full Atlas Host Integration | Planned |
| v0.95 | Release Candidate Hardening | Planned |
| v1.0.0 | Apollo Stable Release | Target after all release gates pass |
| v1.1.0-alpha.1 | Sleeping Giant BYOM | Source milestone completed; native runtime pending |
| v1.2.0-alpha.1 | Adaptive GGUF Device Profiles | Source milestone completed; Android host build pending |
| v1.3.0-alpha.1 | Native GGUF JNI foundation | Source implementation completed; NDK link and device qualification pending |
| v1.3.0-alpha.2 | Adaptive native model profile | Device/model settings and native runtime handoff added |
| v1.3.0-alpha.3 | Native GGUF runtime + benchmark | Source candidate complete; CI AAR and physical-device qualification pending |

## Non-negotiable release policy

- No small user-facing builds.
- No milestone is marked complete without the stated acceptance tests and measurements.
- No model is called integrated until real model weights execute on the target runtime.
- No 4 GB compatibility claim without physical-device measurements.
- Do not destabilize Atlas Library Magazine or My Books.
