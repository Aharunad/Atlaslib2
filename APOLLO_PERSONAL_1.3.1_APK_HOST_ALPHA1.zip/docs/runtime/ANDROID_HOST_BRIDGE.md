# Android Host Bridge Contract

Apollo's JavaScript/TypeScript kernel does not guess Android memory or audio state. The native Atlas Library host injects narrow, typed services.

## Required for model inference

```ts
interface ApolloDeviceTelemetry {
  getMemorySnapshot(): Promise<{
    totalBytes: number;
    availableBytes: number;
    memoryClassMb: number;
    lowMemory: boolean;
    thermalStatus: 'nominal' | 'light' | 'moderate' | 'severe' | 'critical';
  }>;
  onMemoryPressure?(callback: () => void): () => void;
}

interface ApolloNativeModelLoader {
  load(modelId: string, options: {
    contextTokens: number;
    estimatedBytes: number;
    signal?: AbortSignal;
  }): Promise<{ residentBytes?: number; nativeSessionId: string }>;
  unload(modelId: string, handle: { nativeSessionId: string }): Promise<void>;
}
```

The Android implementation must source memory data from Android OS telemetry. It must not report total physical RAM as available RAM. `onMemoryPressure` triggers `ModelResidencyManager.handleMemoryPressure()`.

## Required for microphone and playback (v0.9)

- Request microphone permission only when the user starts voice interaction.
- Expose explicit start/stop capture events and partial/final transcripts.
- Provide a visible capture state to Apollo's orb state machine.
- Audio playback must support cancel/flush for barge-in.
- Do not retain raw microphone recordings unless the user explicitly saves them.

## Model asset storage

- Store model assets in app-private storage.
- Verify SHA-256 before load and after download/resume.
- Persist an immutable model manifest with license and runtime metadata.
- Use atomic download-to-temp then rename on successful verification.
- Never load an arbitrary path supplied by a model response or Dream Seed.


## Device capability profile (1.2 Alpha)

The current Kotlin host exposes `AtlasApolloModelHost.getDeviceProfile(requestId)`. The response includes total RAM, currently available RAM, low-memory state, low-RAM-device state, CPU core count, supported ABIs, Android API level, app heap class, available private storage and a device label.

Apollo keeps `totalRamBytes` and `appMemoryClassMb` separate. Android documents `availMem` as an estimate that can include reclaimable memory. Apollo therefore reserves headroom and treats the result as advisory, not as guaranteed allocatable RAM. See the [ActivityManager.MemoryInfo reference](https://developer.android.com/reference/android/app/ActivityManager.MemoryInfo).

The JS adaptive planner uses GGUF layer/head metadata to estimate KV-cache cost. It returns proposed context, CPU thread and batch settings for the native load call. The pinned llama.cpp JNI source currently loads on CPU for ARM64, validates the selected model and performs a generation smoke test. The source package has not yet passed the Android NDK build or physical-device qualification.
