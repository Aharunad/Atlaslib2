# Model Runtime Supervisor — v0.5.0

## Purpose

Coordinate on-device model residency without binding Apollo to a single inference runtime. The supervisor controls when a model may be loaded, how much memory is reserved for its weights/runtime/KV cache, how leases are released, and which idle model can be evicted.

## Host boundary

The Android/WebView host supplies two trusted adapters:

### Memory telemetry

`getMemorySnapshot()` returns:

```json
{
  "totalBytes": 4294967296,
  "availableBytes": 1610612736,
  "memoryClassMb": 4096,
  "lowMemory": false,
  "thermalStatus": "nominal"
}
```

`availableBytes` must come from live OS telemetry, not `totalBytes - modelWeights`. The host maps Android `ActivityManager.MemoryInfo`, memory class, `onTrimMemory`/low-memory events and thermal APIs into this neutral schema.

### Native model loader

- `load(modelId, { descriptor, contextTokens, estimatedBytes, signal })` loads the exact verified model revision and returns a handle. The handle may report `residentBytes` measured by the backend.
- `unload(modelId, handle)` releases native resources, mapped pages, KV buffers and backend sessions.
- Inference is performed outside the supervisor using the acquired lease's handle.

The supervisor does not download models, choose model files from untrusted paths, or run inference itself.

## Descriptor fields

Each registered descriptor contains:

- `id`, `role` (`controller`, `moe`, `editor`, `asr`, `tts`)
- `baseWorkingSetBytes` (weights + runtime baseline; measured on target runtime where possible)
- `kvBytesPerToken` (for text models; 0 for non-token/KV models)
- `maxContextTokens`
- `cachePolicy` (`warm` or `ephemeral`)
- `evictionPriority` (lower values are evicted first)

A production model manifest must additionally bind artifact digest, tokenizer digest, model revision, runtime version, quantization, license identifier and the source used to obtain the artifact.

## Admission algorithm

1. Read live OS memory and thermal state.
2. Compute an AI working-set budget using the device profile, system reserve and usable fraction.
3. Estimate this request's base model memory plus requested KV reservation.
4. Reject immediately if the request exceeds the current budget.
5. If necessary, evict idle warm models in ascending eviction priority and least-recently-used order.
6. Never evict a model with an active lease.
7. Load the model; compare any measured runtime footprint against the reservation.
8. Unload and reject if measured footprint cannot fit.
9. Return a lease; release the per-session KV reservation when the operation ends.
10. Ephemeral models (initially ASR/TTS profiles) unload after release. Warm models may remain resident until pressure or a higher-priority task needs memory.

## Guarantees and limitations

- Admission uses live available memory; total marketed RAM is not treated as available RAM.
- Active leases are never evicted.
- Low-memory and severe-thermal states close admission.
- Concurrent load/unload/admission operations are serialized to avoid duplicate loads and overcommit.
- Inference itself is not serialized by this class; the runtime adapter must enforce its own safe concurrency rules.
- Byte estimates are only estimates until the Android backend reports measured PSS/RSS or allocator telemetry.
- The v0.5 module is backend-neutral. It does not yet load ExecuTorch, llama.cpp, MLC or a MoE model.
