# Apollo Seed Intelligence v0.2.0 — Internal Test Record

- Runtime: Node.js 22.16.0
- Command: `npm test`
- Result: **40 passed, 0 failed**
- JavaScript syntax checks: all source and demo modules passed `node --check`.
- End-to-end demo: passed.

## Covered behavior

- Existing Dream Kernel deterministic replay and allowlist validation.
- Content-addressed knowledge packet identity and integrity.
- Seed compilation, digest validation, export and import.
- Strategy selection and seeded editorial variation.
- Same-seed, same-context byte-identical replay.
- Missing-context failure.
- Duplicate claim rejection across context packets.
- Result-cache reuse and bounded storage.
- Claim coverage, factual provenance and uncertainty placement.
- Controller, MoE and editorial adapter contract validation.
- Output and context bounds.
- Atomic context-store snapshot export/restore and tamper rejection.
- Main DreamKernel API integration.

## End-to-end demo record

- Seed manifest: 772 bytes.
- Referenced knowledge packet: 1,328 canonical bytes.
- Five claims included and preserved.
- Editorial document: 829 bytes.
- Same seed replay: byte-identical.
- Context snapshot restored in a fresh runtime instance: passed.
- Replay after snapshot restore: byte-identical.

These measurements describe a small procedural fixture. They are not an AI quality score, device-performance benchmark or compression ratio. The seed does not replace the separately stored knowledge packet.
