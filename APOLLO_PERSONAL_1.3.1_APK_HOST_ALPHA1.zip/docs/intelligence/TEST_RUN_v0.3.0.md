
> apollos-dream-kernel@0.3.0 test
> node --test tests/*.test.js

TAP version 13
# Subtest: same generation seed creates byte-stable blueprint
ok 1 - same generation seed creates byte-stable blueprint
  ---
  duration_ms: 10.307456
  type: 'test'
  ...
# Subtest: different generation seeds can produce different layout choices
ok 2 - different generation seeds can produce different layout choices
  ---
  duration_ms: 2.250575
  type: 'test'
  ...
# Subtest: fluid orb is deterministic for a saved seed
ok 3 - fluid orb is deterministic for a saved seed
  ---
  duration_ms: 2.483536
  type: 'test'
  ...
# Subtest: blueprint validator rejects unregistered component types
ok 4 - blueprint validator rejects unregistered component types
  ---
  duration_ms: 0.864581
  type: 'test'
  ...
# Subtest: blueprint validator rejects arbitrary actions
ok 5 - blueprint validator rejects arbitrary actions
  ---
  duration_ms: 0.777757
  type: 'test'
  ...
# Subtest: constrained profile reduces animation, tree and cache budgets
ok 6 - constrained profile reduces animation, tree and cache budgets
  ---
  duration_ms: 0.386874
  type: 'test'
  ...
# Subtest: seed cache enforces a byte cap and evicts least recently used entries
ok 7 - seed cache enforces a byte cap and evicts least recently used entries
  ---
  duration_ms: 1.496435
  type: 'test'
  ...
# Subtest: unknown dream kinds are rejected
ok 8 - unknown dream kinds are rejected
  ---
  duration_ms: 1.116971
  type: 'test'
  ...
# Subtest: text experience compiles into an allowlisted component tree
ok 9 - text experience compiles into an allowlisted component tree
  ---
  duration_ms: 6.977524
  type: 'test'
  ...
# Subtest: fluid orb blueprint stores a seed instead of expanded path geometry
ok 10 - fluid orb blueprint stores a seed instead of expanded path geometry
  ---
  duration_ms: 1.272278
  type: 'test'
  ...
# Subtest: validator rejects unknown properties from generated plans
ok 11 - validator rejects unknown properties from generated plans
  ---
  duration_ms: 1.898633
  type: 'test'
  ...
# Subtest: validator rejects unapproved tabs and unsafe URLs
ok 12 - validator rejects unapproved tabs and unsafe URLs
  ---
  duration_ms: 1.947163
  type: 'test'
  ...
# Subtest: compiled blueprint is deeply immutable after validation
ok 13 - compiled blueprint is deeply immutable after validation
  ---
  duration_ms: 2.225523
  type: 'test'
  ...
# Subtest: validator rejects duplicate component identities
ok 14 - validator rejects duplicate component identities
  ---
  duration_ms: 2.33979
  type: 'test'
  ...
# Subtest: Atlas shell can procedurally compose all three independent features
ok 15 - Atlas shell can procedurally compose all three independent features
  ---
  duration_ms: 0.524531
  type: 'test'
  ...
# Subtest: Atlas shell rejects an unknown feature instead of silently replacing app navigation
ok 16 - Atlas shell rejects an unknown feature instead of silently replacing app navigation
  ---
  duration_ms: 6.483298
  type: 'test'
  ...
# Subtest: validator rejects unknown metadata and non-screen roots
ok 17 - validator rejects unknown metadata and non-screen roots
  ---
  duration_ms: 0.513967
  type: 'test'
  ...
# Subtest: MAKETINY 2.0 recipe registry is fixed and versioned
ok 18 - MAKETINY 2.0 recipe registry is fixed and versioned
  ---
  duration_ms: 2.714714
  type: 'test'
  ...
# Subtest: same parent seed and generation state produce the same family seed
ok 19 - same parent seed and generation state produce the same family seed
  ---
  duration_ms: 17.73695
  type: 'test'
  ...
# Subtest: parent seed procedurally creates compact child seeds for Apollo stages
ok 20 - parent seed procedurally creates compact child seeds for Apollo stages
  ---
  duration_ms: 9.503663
  type: 'test'
  ...
# Subtest: recursive expansion creates nested knowledge, expert and editorial task seeds
ok 21 - recursive expansion creates nested knowledge, expert and editorial task seeds
  ---
  duration_ms: 29.877364
  type: 'test'
  ...
# Subtest: same parent replay produces byte-identical children
ok 22 - same parent replay produces byte-identical children
  ---
  duration_ms: 4.902183
  type: 'test'
  ...
# Subtest: different root generation seeds produce different child generation states
ok 23 - different root generation seeds produce different child generation states
  ---
  duration_ms: 17.853722
  type: 'test'
  ...
# Subtest: parent seed context references flow to child seeds without duplicating source content
ok 24 - parent seed context references flow to child seeds without duplicating source content
  ---
  duration_ms: 9.841686
  type: 'test'
  ...
# Subtest: resource limits stop excessive child generation
ok 25 - resource limits stop excessive child generation
  ---
  duration_ms: 3.208918
  type: 'test'
  ...
# Subtest: tampered parent seed is rejected
ok 26 - tampered parent seed is rejected
  ---
  duration_ms: 3.822129
  type: 'test'
  ...
# Subtest: seed cannot select unregistered generator code
ok 27 - seed cannot select unregistered generator code
  ---
  duration_ms: 3.049179
  type: 'test'
  ...
# Subtest: footprint distinguishes transient child generation from persisted storage
ok 28 - footprint distinguishes transient child generation from persisted storage
  ---
  duration_ms: 28.036255
  type: 'test'
  ...
# Subtest: MAKETINY parent binary seed expands into a larger 118-byte child seed
ok 29 - MAKETINY parent binary seed expands into a larger 118-byte child seed
  ---
  duration_ms: 5.879426
  type: 'test'
  ...
# Subtest: 118-byte child seed deterministically generates the quadratic sequence
ok 30 - 118-byte child seed deterministically generates the quadratic sequence
  ---
  duration_ms: 18.974057
  type: 'test'
  ...
# Subtest: quadratic parent seed detects tampering
ok 31 - quadratic parent seed detects tampering
  ---
  duration_ms: 0.380823
  type: 'test'
  ...
# Subtest: quadratic child seed detects tampering
ok 32 - quadratic child seed detects tampering
  ---
  duration_ms: 2.865419
  type: 'test'
  ...
# Subtest: quadratic generator enforces bounded chunk materialization
ok 33 - quadratic generator enforces bounded chunk materialization
  ---
  duration_ms: 6.485355
  type: 'test'
  ...
# Subtest: DreamKernel exposes MAKETINY family generation as a first-class Apollo service
ok 34 - DreamKernel exposes MAKETINY family generation as a first-class Apollo service
  ---
  duration_ms: 63.505252
  type: 'test'
  ...
# Subtest: knowledge packet is content-addressed and immutable by reference
ok 35 - knowledge packet is content-addressed and immutable by reference
  ---
  duration_ms: 37.141368
  type: 'test'
  ...
# Subtest: seed compiles to a compact strategy reference without embedding knowledge claims
ok 36 - seed compiles to a compact strategy reference without embedding knowledge claims
  ---
  duration_ms: 13.206219
  type: 'test'
  ...
# Subtest: same seed and same context replay byte-identically
ok 37 - same seed and same context replay byte-identically
  ---
  duration_ms: 23.487459
  type: 'test'
  ...
# Subtest: same input with different generation seeds can select different editorial variants
ok 38 - same input with different generation seeds can select different editorial variants
  ---
  duration_ms: 139.988707
  type: 'test'
  ...
# Subtest: seed export/import validates its digest
ok 39 - seed export/import validates its digest
  ---
  duration_ms: 20.851678
  type: 'test'
  ...
# Subtest: seed alone cannot recreate a missing knowledge packet
ok 40 - seed alone cannot recreate a missing knowledge packet
  ---
  duration_ms: 12.085255
  type: 'test'
  ...
# Subtest: content store detects tampered stored content
ok 41 - content store detects tampered stored content
  ---
  duration_ms: 2.294359
  type: 'test'
  ...
# Subtest: replay cache returns a hit without changing the result
ok 42 - replay cache returns a hit without changing the result
  ---
  duration_ms: 10.924672
  type: 'test'
  ...
# Subtest: multi-packet context is merged with duplicate claim protection
ok 43 - multi-packet context is merged with duplicate claim protection
  ---
  duration_ms: 4.781657
  type: 'test'
  ...
# Subtest: duplicate claim IDs across packets are rejected
ok 44 - duplicate claim IDs across packets are rejected
  ---
  duration_ms: 20.675126
  type: 'test'
  ...
# Subtest: strategy selection supports the compare task and rejects unknown strategies
ok 45 - strategy selection supports the compare task and rejects unknown strategies
  ---
  duration_ms: 9.516702
  type: 'test'
  ...
# Subtest: model adapter contracts reject arbitrary capabilities and tool execution
ok 46 - model adapter contracts reject arbitrary capabilities and tool execution
  ---
  duration_ms: 2.596966
  type: 'test'
  ...
# Subtest: result output is limited by configured byte budget
ok 47 - result output is limited by configured byte budget
  ---
  duration_ms: 4.399367
  type: 'test'
  ...
# Subtest: cache has bounded capacity and remains namespaced by seed and engine version
ok 48 - cache has bounded capacity and remains namespaced by seed and engine version
  ---
  duration_ms: 4.762979
  type: 'test'
  ...
# Subtest: DreamKernel exposes the seed intelligence layer through the main kernel
ok 49 - DreamKernel exposes the seed intelligence layer through the main kernel
  ---
  duration_ms: 4.521935
  type: 'test'
  ...
# Subtest: invalid task is rejected before context is persisted
ok 50 - invalid task is rejected before context is persisted
  ---
  duration_ms: 0.938816
  type: 'test'
  ...
# Subtest: MoE delegation intent cannot be replayed without a real adapter
ok 51 - MoE delegation intent cannot be replayed without a real adapter
  ---
  duration_ms: 4.422875
  type: 'test'
  ...
# Subtest: seed rejects unknown fields and duplicate context references
ok 52 - seed rejects unknown fields and duplicate context references
  ---
  duration_ms: 5.647897
  type: 'test'
  ...
# Subtest: factual claims are never placed under an uncertainty heading
ok 53 - factual claims are never placed under an uncertainty heading
  ---
  duration_ms: 16.461222
  type: 'test'
  ...
# Subtest: factual claims without provenance fail the editorial audit
ok 54 - factual claims without provenance fail the editorial audit
  ---
  duration_ms: 10.312678
  type: 'test'
  ...
# Subtest: model adapter contracts reject unknown extra fields
ok 55 - model adapter contracts reject unknown extra fields
  ---
  duration_ms: 0.2259
  type: 'test'
  ...
# Subtest: content-store snapshot restores verified knowledge across engine instances
ok 56 - content-store snapshot restores verified knowledge across engine instances
  ---
  duration_ms: 5.292728
  type: 'test'
  ...
# Subtest: content-store snapshot restore is atomic and rejects tampering
ok 57 - content-store snapshot restore is atomic and rejects tampering
  ---
  duration_ms: 3.896365
  type: 'test'
  ...
# Subtest: reasoning compilation also emits a MAKETINY parent Dream seed
ok 58 - reasoning compilation also emits a MAKETINY parent Dream seed
  ---
  duration_ms: 5.427986
  type: 'test'
  ...
1..58
# tests 58
# suites 0
# pass 58
# fail 0
# cancelled 0
# skipped 0
# todo 0
# duration_ms 957.410373
