# MAKETINY 2.0 — Internal Benchmark Report

## Result A: Reproductive Apollo Dream seed family

A deterministic parent seed describing one writing task, 16 capability lanes, 40 editorial sections and voice planning was expanded through the registered recipe hierarchy.

| Measurement | Result |
|---|---:|
| Parent seed | 1,472 bytes |
| Derived child seeds | 77 |
| Aggregate derived child seed bytes | 53,006 bytes |
| Fully materialized family | 54,478 bytes |
| Child expansion factor | 36.01x relative to parent |
| Persistent bytes with on-demand child derivation | 1,472 bytes |
| Storage avoided vs persisting root + all children | 97.30% |

Interpretation: the parent seed retains shared task parameters and reproducible generation state. Child seeds can be generated when a stage is scheduled rather than persisted as separate manifests. This reduces the storage needed for the **workflow seed family**. It does not reduce the size of the referenced knowledge packets, generated final text, SLM/MoE weights or TTS weights.

## Result B: Nested parent-seed -> child-seed -> data fixture

| Measurement | Result |
|---|---:|
| Parent seed | 44 bytes |
| Child seed | 118 bytes |
| Seed expansion factor | 2.68x |
| Data output described by child | 524,288,000 bytes (500 MiB) |
| Sequence items | 65,536,000 int64 values |
| First eight values | 7, 10, 14, 19, 25, 32, 40, 49 |
| Parent corruption check | CRC-32 |
| Child integrity check | SHA-256 digest |
| Full 500 MiB output materialized | No |

The child describes the recurrence `x[n] = 7 + 3n + n(n-1)/2`, matching the formula visible in the supplied screenshot. The fixture validates seed expansion, the 500 MiB output-length calculation and a generated sample. It does not reproduce the original historical seed bytes, and it does not independently verify the entire 500 MiB file hash.

## What the result tells us

1. A compact parent can generate larger child seed descriptors when the child structure is algorithmically defined.
2. A reusable parent can replace repeated materialized workflow manifests when child seeds are only needed on demand.
3. Parent/child generation can be recursive and deterministic, which fits Apollo's multi-stage Dream plans.
4. The seed generator registry must be present in the application; a seed is not executable code.
5. Arbitrary high-entropy child seeds cannot be shrunk to a tiny parent unless their missing information is stored elsewhere or recreated from a known compact rule.

## Apollo use cases

- One Dream parent -> knowledge retrieval child plans.
- One Dream parent -> capability-specific MoE request seeds.
- One editorial parent -> per-section generation seeds.
- One voice parent -> per-segment synthesis plans (later phase).
- One visual parent -> procedural asset plans (later phase).

The next optimization is to make child derivation lazy by index/path so Apollo can request only the one knowledge, expert or editorial subtask it needs, without expanding the complete family tree.
