# Apollo Reasoning Strategy Catalog v0.2

| Strategy ID | Intended task | Available variants |
|---|---|---|
| `explain_concept` | Explain or answer a conceptual question | Guided; Editorial |
| `editorial_article` | Build an article from supplied claims | Narrative; Analytical |
| `compare_options` | Compare alternatives | Balanced; Decision |
| `study_guide` | Organize learning content | Learning path; Revision |
| `conversation_reply` | Compose a conversational answer | Direct; Warm |

Every strategy is versioned and declares a fixed operator sequence. Seeds refer to strategy IDs and versions, never to executable operations.

## Variation policy

A deterministic pseudorandom generator selects an approved strategy variant from the saved generation seed. The same seed and strategy version select the same variant. A new seed may select another variant.

Randomness changes the arrangement and presentation. It must not change supplied facts, invent sources, or silently modify claim meaning.

## Adding a strategy

A new strategy requires:

1. A stable ID and incremented version when behavior changes.
2. An explicit task mapping.
3. A bounded set of editorial variants.
4. A list of already registered operator IDs.
5. Replay, provenance and regression tests.
6. A documented migration policy for old seeds.

No seed may register a strategy itself.
