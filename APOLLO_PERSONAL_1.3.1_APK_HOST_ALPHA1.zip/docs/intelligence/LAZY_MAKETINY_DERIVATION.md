# MAKETINY Lazy Child Derivation — v0.4

## Change

MAKETINY recipes now expose `childCount(parameters)` and `childAt(parameters, index)` for built-in Apollo recipes. The engine exposes:

- `countChildren(parentSeed)`
- `deriveChild(parentSeed, index)`
- `expand(parentSeed, { offset, limit })`

`deriveChild` computes only the selected child descriptor and seals that child seed. It does not construct sibling seed objects. `expand` is retained as a paged compatibility API and uses single-child derivation internally.

## Reproducibility

Child generation state remains derived from the parent generation state, parent digest, child index and child role. The same parent seed/runtime/recipe version/index therefore yields the same child seed. Different parent seeds produce different child generation states.

## Safety

- Recipes remain registered trusted application code.
- Seed payloads contain no executable operators.
- Child depth, count, byte size and total tree nodes remain bounded.
- Parent digest, child index, role and parent linkage are validated.
- Persisted child seeds require a persisted parent; ephemeral children can be derived and discarded.

## Benchmark interpretation

The v0.4 benchmark expands one parent with 16 capabilities, 64 editorial sections, voice and visual plans. It materializes 104 seed nodes for a reference comparison (one parent plus 103 derived children). The parent seed is 2,650 bytes and the derived child seed objects total 80,234 bytes. Persisting only the parent avoids storing those transient child manifests: 96.803% less seed-manifest storage than persisting the complete materialized tree.

This is a storage-footprint result for deterministic workflow manifests. It does not compress the underlying knowledge packet, generated article text, model weights or arbitrary user files.
