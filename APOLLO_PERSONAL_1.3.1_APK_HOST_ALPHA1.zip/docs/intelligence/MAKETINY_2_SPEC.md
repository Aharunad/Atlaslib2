# MAKETINY 2.0 — Reproductive Seed Procedural Generation

**Status:** Integrated prototype in Apollo's Dream v0.3.0  
**Purpose:** A compact parent seed procedurally derives larger child-seed manifests and nested task seeds on demand.

## 1. Concept

MAKETINY 2.0 formalizes a parent/child seed hierarchy:

`Parent seed -> child seed(s) -> task/output`

The parent stores a versioned recipe identifier, bounded parameters, generation state and references to required knowledge. A trusted, installed generator expands that description into child seeds. Child seeds can themselves invoke another registered recipe, subject to a strict depth and node budget.

The seed contains no executable code. It selects from a registry of generator recipes compiled into the application.

## 2. Screenshot-derived reference case

The supplied historical screenshot reports a 118-byte seed representing a 524,288,000-byte sequence of quadratic integer data:

`x[n] = 7 + 3n + n(n-1)/2`

It reports matching source and regenerated SHA-256 values and describes recurrence discovery for 16-, 32- and 64-bit integer sequences. This is evidence for a highly structured, known mathematical family; it is not evidence that arbitrary data or arbitrary seeds can be compressed by the same ratio.

The historical MAKETINY source implementation and its exact 118-byte seed were not found in the accessible Library artifacts. Therefore this release is a new, explicit reimplementation based on the user's description and screenshot, not a restoration of the historical code.

## 3. Nested binary fixture

The new fixture uses:

- 44-byte parent seed: `MT2P`, version, allowlisted recipe ID, requested child size and four 64-bit recurrence parameters.
- 118-byte child seed: `MT2C`, version, recipe ID, int64 width, little-endian flag, item count, initial value, first and second differences, output byte length, generator fingerprint, marker and SHA-256 checksum.
- Child decoder: generates bounded chunks of little-endian signed 64-bit integers using the recurrence.

For the screenshot-scale descriptor:

- Items: 65,536,000
- Bytes described: 524,288,000 (500 MiB)
- Parent descriptor: 44 bytes including CRC-32
- Child seed: 118 bytes
- Parent-to-child seed expansion: 2.68x

This prototype verifies the parent-to-child expansion, the child's parameter integrity, the expected 500 MiB output length and the first generated values. It does **not** regenerate or independently hash the entire 500 MiB output in this release, and it does not reproduce the original historical seed bytes or source hash from the screenshot.

## 4. Apollo Dream family recipe

`apollo_dream_v1` can derive child seeds for:

- Knowledge plan
- MoE capability plan
- Editorial plan
- Voice plan (when enabled)
- Visual plan (future option; disabled in the initial demo)

Child recipes further derive knowledge-query seeds, one child per requested MoE capability, editorial-section seeds, and a voice-render plan. All children retain parent linkage and content references; they do not duplicate the full original knowledge packet.

## 5. Internal footprint experiment

A fixed Apollo Dream parent seed (1,472 canonical JSON bytes) describing 16 capability lanes, 40 editorial sections, voice enabled and one objective produced 77 child seeds totaling 53,006 bytes.

- Parent seed: 1,472 bytes
- Derived child seed material: 53,006 bytes
- Materialized family total: 54,478 bytes
- Child expansion factor relative to parent: 36.01x
- Persistent footprint if children are regenerated on demand: 1,472 bytes
- Storage avoided compared with persisting root plus all generated child seeds: 97.30%

This is a **seed-family metadata persistence comparison**. It is not a compression ratio for knowledge, model weights, source documents or arbitrary user data. The root seed already contains the shared parameters from which the child seeds are derived. Child seeds must be regenerated when needed, and the compatible generator registry must be installed.

## 6. Correctness and limits

- Identical parent seed + same recipe version + same inputs => identical children.
- A different generation state can produce different child generation keys.
- Seed digests are checked before expansion.
- Unknown recipe IDs are rejected.
- Seeds cannot carry code, shell commands, arbitrary plugin locations or network instructions.
- Maximum nesting depth: 4.
- Maximum child seeds per recipe expansion: 128.
- Maximum expanded tree nodes: 512.
- Maximum seed bytes: 64 KiB.
- Chunk materialization is bounded; the quadratic fixture does not allocate the whole output at once.

## 7. What MAKETINY 2.0 does not claim

- It does not compress arbitrary high-entropy child seeds.
- A pseudorandom generator cannot reproduce an unknown random child seed without its entropy/source information.
- Parent-to-child expansion does not create new factual knowledge or trained neural weights.
- It does not shrink an LLM's learned parameters or automatically reduce MoE inference FLOPs.
- The 97.30% figure is specific to avoiding persistence of this derived seed family; it does not describe the complete Apollo app footprint.

## 8. Apollo integration points

MAKETINY 2.0 is exposed through `SeedIntelligenceEngine` and `DreamKernel`:

- `createMakeTinyRoot(options)`
- `expandMakeTinySeed(seed, options)`
- `expandMakeTinyTree(seed, options)`
- `inspectMakeTinyFootprint(seed, children)`

It is intended to support Dream Blueprints, reasoning workflows, delegated MoE tasks, editorial sections, voice plans and procedural experience manifests.

## v0.4 lazy derivation

Built-in trusted recipes now expose child counts and direct indexed child descriptors. The engine can derive a single child seed by index without materializing sibling seed objects. Paged `expand()` remains available and uses the indexed derivation path internally. The same parent digest, saved generation state, recipe version and child index produce the same child. The persistent Atlas store can retain a parent and regenerate children on demand; persisted children require their parent to exist.

This reduces the amount of workflow-manifest data that needs to be persisted. It does not reduce the storage required for referenced knowledge, generated text or neural model assets.
