# Apollo Model Adapter Contracts v0.4

## Controller SLM

The controller exposes two operations:

- `plan({ latestMessage, history })` returns a validated plan with `needsMoE`, registered capabilities and an optional registered strategy ID.
- `respond({ prompt, history, plan })` returns a structured knowledge packet for requests it can answer directly.

## MoE child

`generate({ prompt, history, capabilities, resourceMode })` returns a structured knowledge packet. It cannot request arbitrary tool execution. The application scheduler may request capabilities and manage model residency; the sparse model router selects experts according to its own architecture.

## Editorial adapter

`rewrite({ prompt, draft, knowledgePacket, expectedClaimIds, style })` returns `{ text, preservedClaimIds }`. The adapter rejects output that omits or duplicates expected claim IDs. This is only a structural integrity check; later releases need semantic comparison for claim meaning, caveats and source relationships.

## Replay and provenance

A model-stage record should contain model and revision, tokenizer, quantization, runtime/backend, sampling configuration, prompt template version, resource profile and model-supported generation seed. Neural output is not assumed deterministic unless measured for the complete stack.

## Current implementation status

The v0.4 conversation orchestrator is implemented and tested using deterministic injected adapters. No pretrained SLM, MoE expert runtime or neural editor is connected.
