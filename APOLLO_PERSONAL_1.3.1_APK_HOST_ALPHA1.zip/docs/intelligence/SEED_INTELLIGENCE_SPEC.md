# Apollo Seed Intelligence Layer — Specification v0.2

## Purpose

Provide Apollo with a compact, versioned way to remember and replay validated reasoning workflows without embedding executable code or duplicating the full knowledge payload in every workflow.

This layer is shared by Dream Blueprints, future controller-SLM plans, MoE delegation manifests, editorial transformations and procedural content generation.

## Core objects

### 1. Knowledge Packet

A declarative collection of claims. Each claim has a stable ID, text, epistemic kind (`fact`, `inference`, `hypothesis`, `definition`, `unknown`), source references and optional confidence, priority, topic and caveat.

Packets are content-addressed with SHA-256. The content store verifies the digest each time a packet is retrieved. Source references are provenance labels; this layer does not independently verify the external source itself.

### 2. Reasoning Seed

A compact manifest containing:

- Format and schema versions.
- Engine version.
- Deterministic PRNG algorithm and saved generation value.
- Normalized task descriptor and editorial mode.
- Registered strategy ID and version.
- Selected strategy variant.
- SHA-256 references to separately stored knowledge packets.
- A bounded model-delegation intent descriptor.
- Output, claim-count and execution constraints.
- A digest over the complete canonical seed payload.

A seed is not self-contained knowledge. If a referenced knowledge packet is absent, replay fails explicitly. The seed is not an encryption key, a signature, or a compression format.

### 3. Strategy Registry

Only strategies compiled into the trusted application can be invoked. A seed can name a registered strategy and version; it cannot include source code, closures, shell commands, arbitrary plugin paths or custom operators.

Initial strategies:

- `explain_concept`
- `editorial_article`
- `compare_options`
- `study_guide`
- `conversation_reply`

Each strategy lists allowlisted operator IDs and versioned editorial variants.

### 4. Operator Registry

Operators are trusted application code. The seed can select a registered strategy but cannot install or modify operators.

Current operators normalize request strings, rank claims, assign claims to editorial sections, compose a Markdown document and audit claim coverage.

The current composition stage is deterministic assembly, not neural paraphrasing. A future editor SLM will be attached through the model-adapter contract and must preserve claim IDs and their provenance.

### 5. Content-Addressed Store and Result Cache

The content store holds knowledge packets separately from seeds. The result cache stores completed deterministic outputs under an engine-versioned key. The existing LRU/TTL cache enforces a byte budget.

The v0.2 store is in-memory. Production Android storage should implement the same `put/get/has/delete/stats` port using app-private persistent storage, with a transactional write strategy and optional encryption at rest.

## Replay guarantees

Given the same:

- seed bytes,
- engine version,
- registered strategy version,
- operator implementation version,
- knowledge packet references and bytes,

this release produces a byte-stable Markdown assembly.

This guarantee currently applies to procedural operators only. Neural inference can vary by runtime, hardware, quantization, backend and sampling parameters. Future model-driven executions must record model/tokenizer/runtime fingerprints and preserve the model output as a content-addressed artifact if exact replay is required.

## Security and safety boundaries

- No executable payloads in seeds.
- No network access is initiated by the seed engine.
- No model-generated tool execution.
- Unknown strategies, operators, fields and capabilities are rejected.
- Context is digest-checked on retrieval.
- Output and context sizes are bounded.
- A digest detects modification; it does not authenticate authorship.

## What this layer does not claim

- It does not compress the referenced knowledge packet.
- It does not create knowledge from a seed alone.
- It does not implement the controller SLM or MoE inference.
- It does not perform neural editorial rewriting.
- It does not verify external citations against the web.
