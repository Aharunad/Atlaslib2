# Dream Kernel and Seed Intelligence — Technical Specification v0.2.0

## MIRACLE Core name
The project nickname **MIRACLE Core** means **Modular Intent-driven, Reproducible, Adaptive, Constraint-validated, Layered Experience generation**. It is a name for the complete engineering kernel, not a claim of one magical algorithm.

## Purpose
Dream Kernel is the fixed, trusted runtime that enables Apollo to generate complete app experiences from declarative plans (“Dream Blueprints”). It is the foundation for procedurally composing the app's layouts, screen structures, content presentation and interaction flows.

## Three layers

### 1. Dream Director (future SLM/MoE-assisted planner)
- Accepts a user or system goal.
- Selects from registered capabilities and generation recipes.
- Emits a JSON-compatible Dream Blueprint.
- Cannot emit executable JavaScript, HTML, shell commands, native code or arbitrary CSS.

The initial v0.1 implementation uses deterministic planning rules and seeded layout recipes. The SLM integration will be introduced after the schema and renderer are stable.

### 2. Dream Kernel (current implementation)
- Validates schema and version.
- Enforces component/action allowlists.
- Enforces node count and depth limits.
- Selects a resource profile.
- Applies deterministic seeded variation.
- Produces an immutable render plan.

### 3. Dream Renderer (current implementation)
- Renders only registered components.
- Uses DOM APIs and textContent; never injects model output as raw HTML.
- Routes interactions through approved action identifiers.
- Honors reduced-motion and low-resource profiles.

## Blueprint contract
A blueprint includes:
- `schemaVersion`
- `engineVersion`
- `id`
- `generationSeed`
- `theme`
- `metadata`
- `tree`

The renderer accepts only `atlas-white`. The fluid orb uses a saved non-cryptographic seed for reproducible visual variation. This seed must never be treated as a security secret or encryption key.

## Procedural strategy selection
- A fixed registry contains approved layout recipes and generation methods.
- The planner selects among them using a deterministic seeded PRNG.
- Same seed + same engine version + same inputs must yield the same blueprint.
- New seed can yield a different composition within the same design system.
- Persist seed and blueprint manifest for exact recreation.

## Resource governor
- 4 GB class devices use constrained profile by default.
- Reduced-motion setting disables fluid animation.
- Constrained profile reduces orb layer count, maximum component nodes, cache size and concurrent workers.
- Inference/model residency is managed separately from UI generation.

## Safety model
- No executable model-generated content.
- No arbitrary script/plugin loading.
- No model-controlled filesystem or network access.
- Strict allowed action IDs.
- Strict component registry.
- Output bounds for text, tree size and depth.
- Future AI-generated plans are untrusted input and must pass validation before rendering.

## Important boundary
Dream Kernel can procedurally compose the user experience and create structured content. It does not procedurally create a trained LLM's learned weights or a high-quality TTS model from nothing. Those assets remain installed model files. The kernel orchestrates their use and can reduce repeated work through caching, routing, quantization and reuse.


## Seed Intelligence Layer v0.2.0

The Dream Kernel now exposes `compileReasoningSeed()` and `replayReasoningSeed()` through the main kernel.

The Seed Intelligence Layer separates:

- A compact, versioned reasoning seed describing the task, selected registered strategy, deterministic variation seed, model-delegation intent and context references.
- Content-addressed knowledge packets stored separately and validated with SHA-256 on retrieval.
- Fixed, trusted strategy and operator registries. Seeds may select registered operations but cannot contain executable code or register new operations.
- A bounded LRU/TTL result cache, context claim limits and output-size limits.

The current procedural operators produce a deterministic editorial assembly from supplied claims. They do not perform neural reasoning or natural-language paraphrasing. The model-adapter contracts are boundaries for later SLM/MoE/editor integration; no pretrained model is connected in v0.2.0.

A seed is not a self-contained knowledge archive or a compression algorithm. Exact replay requires the separately stored context packets and compatible strategy/operator versions. Neural stages will require model, tokenizer, quantization and runtime fingerprints before deterministic replay can be claimed.
