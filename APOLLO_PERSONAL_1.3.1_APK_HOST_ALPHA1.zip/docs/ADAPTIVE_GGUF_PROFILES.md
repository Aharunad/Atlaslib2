# Adaptive GGUF device profiles

Apollo keeps the BYOM model-selection workflow. It also measures the current Android device and recommends a conservative runtime configuration for the selected GGUF model.

## Device information

The Android host reports:

- Total and currently available physical RAM.
- Android low-memory and low-RAM flags.
- CPU core count and supported ABIs.
- Android API level and app Java heap class.
- Available storage in Apollo's private model directory.

The app heap class is not physical RAM. Apollo records both values separately.

## Model information

The bounded GGUF inspector reads architecture, file size, tensor count, context length, layer count, embedding length, attention head counts, key/value head dimensions, tokenizer and MoE metadata.

## Planner behavior

The adaptive planner estimates a conservative model working set from model file size, runtime overhead, KV-cache size and context scratch space. It reserves memory for Android, Atlas Library, WebView and other applications. It then chooses the largest context from a fixed candidate set that fits its budget.

It also proposes a CPU thread count and token batch size. GPU offload stays disabled in the current CPU-only llama.cpp build. Later GPU backends must pass a separate device and memory qualification.

## Compatibility states

- `unsupported_abi`: no ARM64 runtime target is available for this device profile.
- `needs_more_metadata`: the GGUF lacks enough attention metadata for a KV-cache estimate.
- `likely_too_large`: the model exceeds the conservative memory budget.
- `runtime_required`: the estimate fits, but no compatible GGUF runtime advertises the architecture.
- `load_test_required`: the runtime advertises the architecture and the estimate fits. A real load test is still required.

No estimate is a guarantee. Android may reclaim memory or terminate a process. Only a native runtime load test and generation test can qualify a model for use.

## Device changes

Apollo queries the Android host at launch and when the user opens or refreshes Sleeping Giant settings. It recalculates recommendations against the currently selected model. The model itself is not automatically upgraded. The user selects a replacement model from storage.

## Test coverage

Node tests cover device-profile validation, KV-cache scaling, constrained-device recommendations, oversized-model rejection, missing metadata and the rule that an estimate never marks a model as inference-ready.

## Runtime settings handoff

When a context estimate fits, the planner returns a proposed `llamaCppOptions` object with context tokens, CPU threads, batch and micro-batch sizes, mmap preference, F16 KV-cache types and zero GPU layers. The native loader checks the actual model context and memory allocations. It can reject a profile that the estimate allowed. Apollo does not apply GPU offload in this CPU-only build.
