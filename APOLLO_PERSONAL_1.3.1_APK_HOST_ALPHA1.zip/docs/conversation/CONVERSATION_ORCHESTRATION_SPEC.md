# Apollo Conversation Orchestration — Specification v0.4

## Purpose

Provide the persistent conversation state and model-adapter orchestration contract for Apollo before real on-device model runtimes are connected.

## Request flow

1. Validate and persist the user turn.
2. Ask the controller adapter to produce a bounded plan.
3. Validate the plan against registered capabilities.
4. If `needsMoE` is true, invoke the injected MoE child adapter. Otherwise invoke the controller's direct-response adapter.
5. Validate the returned knowledge packet. Model-generated tool requests are rejected.
6. Store the packet in the persistent content-addressed store.
7. Compile a reasoning seed and MAKETINY parent Dream seed referencing that packet.
8. Persist the reasoning seed and parent Dream seed.
9. Derive only the required child task seeds by index. Child seeds are transient unless explicitly persisted.
10. Deterministically assemble an editorial draft from the verified precomputed knowledge context.
11. Optionally invoke the editorial adapter. Its response must preserve the full claim-ID set.
12. Persist the assistant turn and references to the reasoning/Dream seeds.

## Adapter contracts

### Controller

- `plan({ latestMessage, history })` returns `needsMoE`, a bounded capability list and an optional registered strategy ID.
- For requests not delegated to MoE, `respond({ prompt, history, plan })` returns a validated knowledge packet.

### MoE child

- `generate({ prompt, history, capabilities, resourceMode })` returns a structured knowledge packet.
- The adapter may not request shell, filesystem, arbitrary network or other model-generated tool execution.

### Editorial model

- `rewrite({ prompt, draft, knowledgePacket, expectedClaimIds, style })` returns `{ text, preservedClaimIds }`.
- All expected claim IDs must be present. This is a structural completeness check, not semantic proof; semantic evaluation remains a later phase.

## Failure behavior

- A missing model adapter fails explicitly; the service does not silently invent a model answer.
- If model output fails schema checks, no assistant success turn is stored.
- The user turn remains in the session, allowing the application to display a retry state.
- A validated MoE packet may be replayed through deterministic editorial assembly using `allowPrecomputedMoEContext`; this does not re-run or impersonate the MoE model.

## Current status

The orchestration service is implemented and tested with injected deterministic test adapters. No pretrained SLM, MoE inference runtime or neural editorial model is connected in this release. This is a backend conversation contract and integration layer, not yet the live Apollo chat feature in Atlas Library.
