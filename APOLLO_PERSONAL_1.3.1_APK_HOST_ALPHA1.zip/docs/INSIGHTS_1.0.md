# APOLLO — MIRACLE INSIGHTS 1.0

These are the engineering principles that make Apollo feel like one coherent intelligence while keeping the implementation measurable, bounded and maintainable. “Miracle Insight” is the project's name for an architectural insight; it is not a claim that information theory or model computation can be bypassed.

## INSIGHT 01 — Reproductive Dream Graph

**Idea:** Persist a compact parent Dream Seed and derive only the child task seed needed at the current stage.

**Implementation:** MAKETINY 2.0's registered, versioned recipes; indexed lazy child derivation; parent digest, child index and role linkage; bounded depth/node count; content-addressed context references.

**Payoff:** Avoid persisting hundreds of repetitive child task manifests. Preserve deterministic replay without storing siblings that are never used.

**Limit:** Does not compress the referenced knowledge, final text, tokenizer, model weights or voice assets.

## INSIGHT 02 — Adaptive Compute Cascade

**Idea:** Use the cheapest capable path first and escalate only when confidence, task complexity or evidence requirements justify it.

**Execution order:** deterministic operator → cached verified result → controller SLM → MoE child → editorial validator.

**Payoff:** Avoid waking the Sleeping Giant for arithmetic, formatting, known structured tasks and cache hits.

**Guardrail:** The controller must not silently answer beyond its evaluated capability. Escalation decisions and fallbacks are logged in a bounded diagnostic record.

## INSIGHT 03 — Model Residency as a First-Class Resource

**Idea:** Model weights are not simply “loaded” or “not loaded”; residency is scheduled around actual free memory, active KV reservations, heat and workload priority.

**Implementation:** `ModelResidencyManager`, dynamic OS telemetry, byte reservations, leases, ephemeral/warm policies, idle LRU/priority eviction, cancellation and pressure handling.

**Payoff:** Prevent controller, MoE, ASR and TTS from accidentally competing for all phone memory.

**Guardrail:** Never unload a model with an active lease. If the live memory budget is insufficient, reject or degrade gracefully before loading.

## INSIGHT 04 — Claim Ledger Before Editorial Prose

**Idea:** Apollo must preserve the meaning and evidence of information while changing its presentation.

**Implementation:** Typed claims, stable IDs, source references, caveats and epistemic status. The neural editor receives both the draft and claim ledger. Structural coverage is checked first; semantic preservation is independently evaluated afterward.

**Payoff:** Cleaner, shorter, more polished writing without casually deleting qualifications or turning a hypothesis into a fact.

**Guardrail:** Claim-ID retention alone is not semantic proof. Unsupported additions are rejected or marked as new claims requiring evidence.

## INSIGHT 05 — Cache the Stable Work, Not the Whole Conversation

**Idea:** Store reusable, expensive deterministic transformations; derive cheap transient plans again when needed.

**Implementation:** Content-addressed knowledge packets; versioned cache keys; byte-bounded LRU/TTL; parent Dream Seeds; cache provenance; atomic store writes.

**Payoff:** Reuse validated context and expensive generation stages without accumulating every intermediate object forever.

**Guardrail:** Cache keys include model/tokenizer/runtime/prompt/strategy/context version. Stale cache entries never override time-sensitive or newly sourced facts.

## INSIGHT 06 — One Dream, Multiple Output Engines

**Idea:** A single validated Dream Blueprint coordinates text, voice, UI composition and eventually visuals.

**Implementation:** Common task graph, typed stage inputs/outputs, dependency graph, generation seeds, resource budget and validation gates. Each output engine remains a separate adapter.

**Payoff:** Apollo can plan one coherent experience while generating each artifact with the best method for that modality.

**Guardrail:** The blueprint is declarative. It cannot contain arbitrary executable code or unrestricted device actions.

## INSIGHT 07 — Voice as a Real-Time Conversation State Machine

**Idea:** Voice should not be a “speak this text” add-on; it is a time-sensitive interface to the same Apollo conversation.

**Implementation:** microphone permission → VAD/ASR → turn planner → controller/MoE → editorial stream → TTS chunk queue → playback; support cancel, interrupt, partial transcripts and back-pressure.

**Payoff:** Natural conversational turn-taking, clean interruption and reduced unnecessary audio buffering.

**Guardrail:** Mic capture is explicit, visible and bounded. On memory pressure, voice can gracefully switch to text or a smaller speech profile.

---

## Cross-cutting principle

**Generate what can be generated. Store what must be stored. Reuse what has already been verified. Load only what is needed now.**

Every proposed procedural optimization must beat the direct implementation on measured total bytes, RAM, latency, energy or quality. Otherwise the simpler implementation wins.
