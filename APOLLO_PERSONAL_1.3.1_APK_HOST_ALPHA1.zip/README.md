# Apollo Personal 1.3.1 — Installable APK Host Alpha 1

**Host product:** Atlas Library  
**Feature under test:** Apollo  
**Test package:** Apollo Personal (temporary Android host)  
**Model strategy:** BYOM + GGUF + llama.cpp  
**SeedLM:** Plan B / research track

## What changed in this release

The previous 1.3.0 package contained the Android native integration as a **library module**. It did not contain a Gradle wrapper and could only produce an AAR. This release preserves that native library and adds a small Android application host under `android-host/host-app` so CI can produce an installable debug APK.

The APK host mounts the Apollo web feature using AndroidX WebViewAssetLoader, restricts navigation and subresources to the app-private HTTPS-like origin, and attaches the existing native Sleeping Giant bridge. The production architecture remains Apollo as a feature inside Atlas Library; this standalone APK is a development/test harness, not a replacement Atlas Library application.

## Features in the APK test host

- Apollo conversation, Dream Studio, history and Settings UI.
- Android document picker for selecting one GGUF model.
- Private model copy, SHA-256 verification and local registry.
- Device RAM/CPU/storage profile and adaptive model/context recommendations.
- Pinned llama.cpp JNI runtime for `arm64-v8a`, CPU-first with KleidiAI enabled.
- Native model load, metadata, smoke generation, streaming, cancellation, unload and model benchmark.
- The loaded GGUF can power Apollo directly if a separate controller endpoint is unavailable.
- No model weights are bundled in the APK.

Offline ASR and Pocket TTS assets are not included in this milestone; the voice control remains unavailable until a real offline voice host is integrated.

## Build facts

- The Android project uses **system Gradle**, not `gradlew`.
- The `android-host` root remains an Android library module.
- `android-host/host-app` is the installable application module.
- Build task: `:host-app:assembleDebug`.
- Output: `android-host/host-app/build/outputs/apk/debug/host-app-debug.apk`.
- Gradle: 8.11.1; JDK 17; AGP 8.9.2; Kotlin 2.1.20.
- Android platform/build tools: API 35 / 35.0.0.
- NDK: 29.0.13113456; CMake: 3.31.6.
- ABI: ARM64 (`arm64-v8a`) only in this alpha.
- llama.cpp is checked out during CI at immutable revision `785322d17f2d51e5185cf996a1f4e46d87640841`.

## GitHub Actions when the repository contains this extracted source tree

Use `.github/workflows/apollo-android-native.yml`. It explicitly sets `packages: platform-tools` for `android-actions/setup-android@v3`, avoiding the deprecated `tools` SDK package. It uses system Gradle and builds the `host-app` APK.

If the repository stores this project as a ZIP instead of extracted files, use the separate `android-build.yml` workflow supplied alongside this archive. That workflow extracts this ZIP into a workspace before building it.

## What has and has not been verified

Source tests and static checks can run in the development environment. This environment does not provide an Android SDK/NDK or a connected Galaxy A07, so the real Gradle/NDK APK link and on-device inference still must be executed by GitHub Actions and the phone. A green source test suite is not represented as a successful APK build.

The first successful CI output should be an installable **debug APK**. It is a functional host shell, but actual model inference is only available if the ARM64 JNI library successfully compiles and the selected GGUF model loads and passes smoke generation on the target device.
