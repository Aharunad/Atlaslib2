import test from 'node:test';
import assert from 'node:assert/strict';
import { DreamKernel, createFluidOrbSpec, validateBlueprint, SeedCache, canonicalStringify, selectResourceProfile } from '../src/index.js';

const kernel = new DreamKernel({ device: { memoryClassMb: 4096, reducedMotion: true } });

test('same generation seed creates byte-stable blueprint', () => {
  const a = kernel.createExperience({ kind: 'apollo-home', seed: 'fixed-test-seed' }).blueprint;
  const b = kernel.createExperience({ kind: 'apollo-home', seed: 'fixed-test-seed' }).blueprint;
  assert.equal(canonicalStringify(a), canonicalStringify(b));
});

test('different generation seeds can produce different layout choices', () => {
  const seen = new Set();
  for (let i = 0; i < 30; i++) {
    const b = kernel.createExperience({ kind: 'apollo-home', seed: `layout-${i}` }).blueprint;
    seen.add(b.metadata.layoutRecipe);
  }
  assert.ok(seen.size > 1);
});

test('fluid orb is deterministic for a saved seed', () => {
  assert.deepEqual(createFluidOrbSpec('orb-123'), createFluidOrbSpec('orb-123'));
  assert.notDeepEqual(createFluidOrbSpec('orb-123'), createFluidOrbSpec('orb-456'));
});

test('blueprint validator rejects unregistered component types', () => {
  const blueprint = structuredClone(kernel.createExperience({ kind: 'apollo-home', seed: 'reject-me' }).blueprint);
  blueprint.tree.children.push({ type: 'execute-code', id: 'bad-node', props: {} });
  assert.throws(() => validateBlueprint(blueprint), /Unregistered component type/);
});

test('blueprint validator rejects arbitrary actions', () => {
  const blueprint = structuredClone(kernel.createExperience({ kind: 'apollo-home', seed: 'reject-action' }).blueprint);
  const composer = blueprint.tree.children.find(n => n.type === 'column').children.find(n => n.type === 'chat-composer');
  composer.props.action = 'shell.execute';
  assert.throws(() => validateBlueprint(blueprint), /Unapproved action id/);
});

test('constrained profile reduces animation, tree and cache budgets', () => {
  const profile = selectResourceProfile({ memoryClassMb: 4096, reducedMotion: false });
  assert.equal(profile.name, 'constrained');
  assert.equal(profile.maxDreamNodes, 90);
  assert.equal(profile.cacheBytes, 2 * 1024 * 1024);
});

test('resource profile uses total physical RAM when Android supplies it', () => {
  assert.equal(selectResourceProfile({ totalRamMb: 8192 }).name, 'capable');
  assert.equal(selectResourceProfile({ totalRamMb: 6144 }).name, 'balanced');
  assert.equal(selectResourceProfile({ totalRamMb: 4096 }).name, 'constrained');
});

test('seed cache enforces a byte cap and evicts least recently used entries', () => {
  let clock = 1000;
  const cache = new SeedCache({ maxBytes: 80, ttlMs: 10000, now: () => clock });
  assert.equal(cache.set('a', { value: 'a'.repeat(20) }), true);
  assert.equal(cache.set('b', { value: 'b'.repeat(20) }), true);
  assert.deepEqual(cache.get('a'), { value: 'a'.repeat(20) });
  assert.equal(cache.set('c', { value: 'c'.repeat(20) }), true);
  assert.equal(cache.get('b'), undefined);
  clock += 20000;
  assert.equal(cache.get('a'), undefined);
});

test('unknown dream kinds are rejected', () => {
  assert.throws(() => kernel.createExperience({ kind: 'arbitrary-app-code' }), /Unsupported dream kind/);
});

test('text experience compiles into an allowlisted component tree', () => {
  const result = kernel.createExperience({
    kind: 'text-experience', seed: 'text-001', title: 'How stars form',
    intro: 'A concise introduction.',
    sections: [{ heading: 'The beginning', paragraphs: ['Gas and dust collapse under gravity.'] }]
  });
  assert.ok(result.validation.nodeCount > 5);
  assert.equal(result.blueprint.tree.type, 'screen');
});

test('fluid orb blueprint stores a seed instead of expanded path geometry', () => {
  const blueprint = kernel.createExperience({ kind: 'apollo-home', seed: 'compact-orb-blueprint' }).blueprint;
  const orb = blueprint.tree.children.find(n => n.type === 'column').children.find(n => n.type === 'fluid-orb');
  assert.equal(typeof orb.props.seed, 'string');
  assert.equal(orb.props.layers, undefined);
  assert.equal(orb.props.quality, 'low');
});

test('validator rejects unknown properties from generated plans', () => {
  const blueprint = structuredClone(kernel.createExperience({ kind: 'apollo-home', seed: 'reject-props' }).blueprint);
  blueprint.tree.children[0].props.onClick = 'alert(1)';
  assert.throws(() => validateBlueprint(blueprint), /Unapproved property/);
});

test('validator rejects unapproved tabs and unsafe URLs', () => {
  const blueprint = structuredClone(kernel.createExperience({ kind: 'apollo-home', seed: 'reject-tabs' }).blueprint);
  const tabs = blueprint.tree.children.find(n => n.type === 'tabs');
  tabs.props.items[0].action = 'javascript:alert(1)';
  assert.throws(() => validateBlueprint(blueprint), /Unapproved tab action/);
});


test('compiled blueprint is deeply immutable after validation', () => {
  const blueprint = kernel.createExperience({ kind: 'apollo-home', seed: 'immutable' }).blueprint;
  assert.equal(Object.isFrozen(blueprint), true);
  assert.equal(Object.isFrozen(blueprint.tree.children), true);
  assert.throws(() => { blueprint.tree.id = 'changed'; }, TypeError);
});

test('validator rejects duplicate component identities', () => {
  const blueprint = structuredClone(kernel.createExperience({ kind: 'apollo-home', seed: 'duplicate-id' }).blueprint);
  blueprint.tree.children[1].children[0].id = blueprint.tree.children[0].id;
  assert.throws(() => validateBlueprint(blueprint), /Duplicate component id/);
});


test('Atlas shell can procedurally compose all three independent features', () => {
  for (const feature of ['magazine', 'books', 'apollo']) {
    const result = kernel.createExperience({ kind: 'atlas-shell', activeFeature: feature, seed: `shell-${feature}` });
    assert.equal(result.blueprint.metadata.activeFeature, feature);
    const tabs = result.blueprint.tree.children.find(n => n.type === 'tabs');
    assert.equal(tabs.props.active, feature);
  }
});

test('Atlas shell rejects an unknown feature instead of silently replacing app navigation', () => {
  assert.throws(() => kernel.createExperience({ kind: 'atlas-shell', activeFeature: 'unknown' }), /Unknown Atlas Library feature/);
});


test('validator rejects unknown metadata and non-screen roots', () => {
  const base = structuredClone(kernel.createExperience({ kind: 'apollo-home', seed: 'metadata-guard' }).blueprint);
  base.metadata.untrustedField = 'should not pass';
  assert.throws(() => validateBlueprint(base), /Unapproved metadata property/);
  const wrongRoot = structuredClone(kernel.createExperience({ kind: 'apollo-home', seed: 'root-guard' }).blueprint);
  wrongRoot.tree.type = 'column';
  assert.throws(() => validateBlueprint(wrongRoot), /root must be a screen/);
});
