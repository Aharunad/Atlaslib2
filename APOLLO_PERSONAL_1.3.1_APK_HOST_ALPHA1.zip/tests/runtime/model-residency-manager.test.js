import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateAiMemoryBudget,
  ModelResidencyManager,
  ModelResidencyError,
  MODEL_MEMORY_UNITS
} from '../../src/runtime/model-residency-manager.js';

const { MIB } = MODEL_MEMORY_UNITS;
const catalog = [
  { id: 'apollo-controller', role: 'controller', baseWorkingSetBytes: 480 * MIB, kvBytesPerToken: 1024, maxContextTokens: 8192, cachePolicy: 'warm', evictionPriority: 40 },
  { id: 'sleeping-giant', role: 'moe', baseWorkingSetBytes: 820 * MIB, kvBytesPerToken: 2048, maxContextTokens: 8192, cachePolicy: 'ephemeral', evictionPriority: 10 },
  { id: 'apollo-asr', role: 'asr', baseWorkingSetBytes: 140 * MIB, kvBytesPerToken: 0, maxContextTokens: 1, cachePolicy: 'ephemeral', evictionPriority: 5 }
];

function fakeLoader({ actualBytes = {} } = {}) {
  const loaded = new Map();
  const events = [];
  return {
    loaded, events,
    async load(id, options) {
      events.push(['load', id, options.contextTokens]);
      const handle = { id, residentBytes: actualBytes[id] ?? options.estimatedBytes };
      loaded.set(id, handle);
      return handle;
    },
    async unload(id) {
      events.push(['unload', id]);
      loaded.delete(id);
    }
  };
}

function memory({ availableBytes = 2 * 1024 * MIB, lowMemory = false, thermalStatus = 'nominal' } = {}) {
  return { totalBytes: 4 * 1024 * MIB, availableBytes, memoryClassMb: 4096, lowMemory, thermalStatus };
}

const generousPolicy = { hardCapBytes: 1300 * MIB, systemReserveBytes: 256 * MIB, usableFraction: 1 };

test('4 GB device receives a budget based on live available memory, not advertised RAM', () => {
  const budget = calculateAiMemoryBudget(memory({ availableBytes: 1200 * MIB }), generousPolicy);
  assert.equal(budget.budgetBytes, 944 * MIB);
  assert.equal(budget.reason, 'OK');
});

test('OS low-memory and severe thermal states close model admission', () => {
  assert.equal(calculateAiMemoryBudget(memory({ lowMemory: true }), generousPolicy).budgetBytes, 0);
  assert.equal(calculateAiMemoryBudget(memory({ thermalStatus: 'severe' }), generousPolicy).budgetBytes, 0);
});

test('controller model loads and remains warm after the lease is released', async () => {
  const loader = fakeLoader();
  const manager = new ModelResidencyManager({ catalog, loader, getMemorySnapshot: async () => memory(), policy: generousPolicy });
  const lease = await manager.acquire('apollo-controller', { contextTokens: 2048 });
  assert.equal(loader.loaded.has('apollo-controller'), true);
  await lease.release();
  assert.equal((await manager.status()).models[0].leaseCount, 0);
  assert.equal(loader.loaded.has('apollo-controller'), true);
});

test('same model reuses one loaded handle and tracks independent KV reservations', async () => {
  const loader = fakeLoader();
  const manager = new ModelResidencyManager({ catalog, loader, getMemorySnapshot: async () => memory(), policy: generousPolicy });
  const a = await manager.acquire('apollo-controller', { contextTokens: 1024 });
  const b = await manager.acquire('apollo-controller', { contextTokens: 2048 });
  assert.equal(a.handle, b.handle);
  assert.equal(loader.events.filter(([kind]) => kind === 'load').length, 1);
  let status = await manager.status();
  assert.equal(status.models[0].leaseCount, 2);
  assert.equal(status.models[0].activeKvBytes, 3 * 1024 * 1024);
  await a.release();
  await b.release();
  status = await manager.status();
  assert.equal(status.models[0].activeKvBytes, 0);
});

test('larger child model evicts an idle lower-priority controller before loading', async () => {
  const loader = fakeLoader();
  const manager = new ModelResidencyManager({ catalog, loader, getMemorySnapshot: async () => memory({ availableBytes: 1400 * MIB }), policy: generousPolicy });
  const controller = await manager.acquire('apollo-controller', { contextTokens: 1024 });
  await controller.release();
  const moe = await manager.acquire('sleeping-giant', { contextTokens: 2048 });
  assert.equal(loader.loaded.has('apollo-controller'), false);
  assert.equal(loader.loaded.has('sleeping-giant'), true);
  await moe.release();
  assert.equal(loader.loaded.has('sleeping-giant'), false);
});

test('active leases are never evicted to make room for another model', async () => {
  const loader = fakeLoader();
  const manager = new ModelResidencyManager({ catalog, loader, getMemorySnapshot: async () => memory({ availableBytes: 1200 * MIB }), policy: generousPolicy });
  const controller = await manager.acquire('apollo-controller', { contextTokens: 1024 });
  await assert.rejects(
    manager.acquire('sleeping-giant', { contextTokens: 2048 }),
    error => error instanceof ModelResidencyError && error.code === 'INSUFFICIENT_HEADROOM'
  );
  assert.equal(loader.loaded.has('apollo-controller'), true);
  await controller.release();
});

test('model larger than current dynamic budget is rejected before loading', async () => {
  const loader = fakeLoader();
  const manager = new ModelResidencyManager({ catalog, loader, getMemorySnapshot: async () => memory({ availableBytes: 700 * MIB }), policy: generousPolicy });
  await assert.rejects(
    manager.acquire('sleeping-giant', { contextTokens: 4096 }),
    error => error instanceof ModelResidencyError && ['MODEL_EXCEEDS_BUDGET', 'INSUFFICIENT_HEADROOM'].includes(error.code)
  );
  assert.equal(loader.events.filter(([kind]) => kind === 'load').length, 0);
});

test('ephemeral speech models unload immediately after release', async () => {
  const loader = fakeLoader();
  const manager = new ModelResidencyManager({ catalog, loader, getMemorySnapshot: async () => memory(), policy: generousPolicy });
  const lease = await manager.acquire('apollo-asr', { contextTokens: 1 });
  await lease.release();
  assert.equal(loader.loaded.has('apollo-asr'), false);
});

test('memory pressure evicts idle models and defers active model eviction until release', async () => {
  const loader = fakeLoader();
  const manager = new ModelResidencyManager({ catalog, loader, getMemorySnapshot: async () => memory(), policy: generousPolicy });
  const controller = await manager.acquire('apollo-controller', { contextTokens: 1024 });
  const result = await manager.handleMemoryPressure();
  assert.deepEqual(result.pending, ['apollo-controller']);
  await controller.release();
  assert.equal(loader.loaded.has('apollo-controller'), false);
});

test('cancelled requests do not load models', async () => {
  const loader = fakeLoader();
  const manager = new ModelResidencyManager({ catalog, loader, getMemorySnapshot: async () => memory(), policy: generousPolicy });
  const controller = new AbortController();
  controller.abort();
  await assert.rejects(manager.acquire('apollo-controller', { signal: controller.signal }), error => error.code === 'ABORTED');
  assert.equal(loader.events.length, 0);
});

test('actual runtime footprint above the reserved budget is unloaded and rejected', async () => {
  const loader = fakeLoader({ actualBytes: { 'apollo-controller': 1500 * MIB } });
  const manager = new ModelResidencyManager({ catalog, loader, getMemorySnapshot: async () => memory({ availableBytes: 1200 * MIB }), policy: generousPolicy });
  await assert.rejects(
    manager.acquire('apollo-controller', { contextTokens: 1024 }),
    error => error instanceof ModelResidencyError && error.code === 'ACTUAL_MEMORY_EXCEEDS_BUDGET'
  );
  assert.equal(loader.loaded.has('apollo-controller'), false);
});

test('leases release idempotently and manager refuses disposal while a lease is active', async () => {
  const loader = fakeLoader();
  const manager = new ModelResidencyManager({ catalog, loader, getMemorySnapshot: async () => memory(), policy: generousPolicy });
  const lease = await manager.acquire('apollo-controller');
  await assert.rejects(manager.dispose(), error => error.code === 'ACTIVE_LEASES');
  assert.equal(await lease.release(), true);
  assert.equal(await lease.release(), false);
  await manager.dispose();
  await assert.rejects(manager.acquire('apollo-controller'), error => error.code === 'DISPOSED');
});

test('a model marked for eviction under memory pressure rejects new leases', async () => {
  const loader = fakeLoader();
  const manager = new ModelResidencyManager({ catalog, loader, getMemorySnapshot: async () => memory(), policy: generousPolicy });
  const lease = await manager.acquire('apollo-controller', { contextTokens: 1024 });
  await manager.handleMemoryPressure();
  await assert.rejects(
    manager.acquire('apollo-controller', { contextTokens: 1024 }),
    error => error instanceof ModelResidencyError && error.code === 'MEMORY_PRESSURE'
  );
  await lease.release();
  assert.equal(loader.loaded.has('apollo-controller'), false);
});

test('cancellation during a model load unloads the completed handle', async () => {
  const controller = new AbortController();
  const loaded = new Map();
  const loader = {
    async load(id, options) {
      const handle = { id, residentBytes: options.estimatedBytes };
      loaded.set(id, handle);
      controller.abort();
      return handle;
    },
    async unload(id) { loaded.delete(id); }
  };
  const manager = new ModelResidencyManager({ catalog, loader, getMemorySnapshot: async () => memory(), policy: generousPolicy });
  await assert.rejects(manager.acquire('apollo-controller', { signal: controller.signal }), error => error.code === 'ABORTED');
  assert.equal(loaded.has('apollo-controller'), false);
});

test('a warm model is unloaded before a new request is denied under a shrunken OS budget', async () => {
  const loader = fakeLoader();
  let currentMemory = memory({ availableBytes: 1400 * MIB });
  const manager = new ModelResidencyManager({ catalog, loader, getMemorySnapshot: async () => currentMemory, policy: generousPolicy });
  const lease = await manager.acquire('apollo-controller', { contextTokens: 1024 });
  await lease.release();
  assert.equal(loader.loaded.has('apollo-controller'), true);
  currentMemory = memory({ availableBytes: 700 * MIB });
  await assert.rejects(manager.acquire('apollo-controller', { contextTokens: 1024 }), error => error.code === 'MODEL_EXCEEDS_BUDGET');
  assert.equal(loader.loaded.has('apollo-controller'), false);
});
