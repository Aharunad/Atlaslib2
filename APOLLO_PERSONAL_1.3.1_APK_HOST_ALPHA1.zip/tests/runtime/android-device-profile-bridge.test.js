import test from 'node:test';
import assert from 'node:assert/strict';
import { AndroidSleepingGiantBridge, AndroidSleepingGiantBridgeError } from '../../src/runtime/android-sleeping-giant-bridge.js';

class FakeEventTarget {
  constructor() { this.listeners = new Map(); }
  addEventListener(name, callback) {
    const set = this.listeners.get(name) ?? new Set();
    set.add(callback);
    this.listeners.set(name, set);
  }
  removeEventListener(name, callback) { this.listeners.get(name)?.delete(callback); }
  emit(name, detail) { for (const callback of this.listeners.get(name) ?? []) callback({ detail }); }
}

test('Android bridge returns a validated device profile through the native result channel', async () => {
  const events = new FakeEventTarget();
  const host = {
    getDeviceProfile(requestId) {
      queueMicrotask(() => events.emit('atlas-apollo-native-result', {
        requestId, ok: true, profile: {
          platform: 'android', totalRamBytes: 4 * 1024 ** 3,
          availableRamBytes: 2 * 1024 ** 3, lowRamDevice: false,
          lowMemory: false, cpuCores: 8, supportedAbis: ['arm64-v8a'],
          apiLevel: 35, appMemoryClassMb: 256,
          availableStorageBytes: 10 * 1024 ** 3, deviceSignature: 'Pixel test'
        }
      }));
    }
  };
  const bridge = new AndroidSleepingGiantBridge({ host, eventTarget: events });
  const profile = await bridge.getDeviceProfile();
  assert.equal(profile.platform, 'android');
  assert.equal(profile.cpuCores, 8);
  assert.deepEqual(profile.supportedAbis, ['arm64-v8a']);
  bridge.dispose();
});

test('Android bridge rejects invalid native device-profile payloads', async () => {
  const events = new FakeEventTarget();
  const host = { getDeviceProfile(requestId) {
    queueMicrotask(() => events.emit('atlas-apollo-native-result', { requestId, ok: true, profile: { platform: 'linux' } }));
  } };
  const bridge = new AndroidSleepingGiantBridge({ host, eventTarget: events });
  await assert.rejects(() => bridge.getDeviceProfile(), error => error instanceof AndroidSleepingGiantBridgeError && error.code === 'DEVICE_PROFILE_INVALID');
  bridge.dispose();
});

test('Android bridge rejects when native device profiling is unavailable', async () => {
  const bridge = new AndroidSleepingGiantBridge({ host: {}, eventTarget: new FakeEventTarget() });
  await assert.rejects(() => bridge.getDeviceProfile(), error => error instanceof AndroidSleepingGiantBridgeError && error.code === 'DEVICE_PROFILE_UNAVAILABLE');
  bridge.dispose();
});
