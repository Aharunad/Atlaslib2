import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { LocalOpenAIClient, validateLocalInferenceUrl } from '../../src/runtime/openai-compatible-client.js';
import { LocalSlmControllerAdapter, LocalMoEChildAdapter, LocalEditorialAdapter, createLocalApolloAdapters } from '../../src/runtime/local-model-adapters.js';

async function withServer(handler, run) {
  const server = createServer(handler);
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const address = server.address();
  try { await run(`http://127.0.0.1:${address.port}/v1`); }
  finally { await new Promise(resolve => server.close(resolve)); }
}

function jsonResponse(res, value) {
  res.writeHead(200, { 'content-type': 'application/json' });
  res.end(JSON.stringify({ model: 'test-local-model', choices: [{ message: { role: 'assistant', content: JSON.stringify(value) } }] }));
}

test('local endpoint validation rejects non-loopback hosts', () => {
  assert.equal(validateLocalInferenceUrl('http://127.0.0.1:8080/v1'), 'http://127.0.0.1:8080/v1');
  assert.throws(() => validateLocalInferenceUrl('https://api.example.com/v1'), /loopback/);
  assert.throws(() => validateLocalInferenceUrl('file:///tmp/model'), /HTTP or HTTPS/);
});

test('OpenAI-compatible local client parses normal completion responses', async () => {
  await withServer(async (_req, res) => jsonResponse(res, { answer: 'local result' }), async baseUrl => {
    const client = new LocalOpenAIClient({ baseUrl, model: 'unit-test' });
    const result = await client.complete({ messages: [{ role: 'user', content: 'hello' }] });
    assert.equal(result.text, JSON.stringify({ answer: 'local result' }));
    assert.equal(result.model, 'test-local-model');
  });
});

test('OpenAI-compatible local client streams SSE deltas and stops on DONE', async () => {
  await withServer(async (_req, res) => {
    res.writeHead(200, { 'content-type': 'text/event-stream' });
    res.write('data: {"choices":[{"delta":{"content":"Apollo "}}]}\n\n');
    res.write('data: {"choices":[{"delta":{"content":"is ready."}}]}\n\n');
    res.end('data: [DONE]\n\n');
  }, async baseUrl => {
    const client = new LocalOpenAIClient({ baseUrl, model: 'unit-test' });
    const chunks = [];
    const result = await client.complete({ messages: [{ role: 'user', content: 'hello' }], onToken: token => chunks.push(token) });
    assert.equal(result.text, 'Apollo is ready.');
    assert.deepEqual(chunks, ['Apollo ', 'is ready.']);
  });
});

test('controller adapter creates an allowlisted route plan and provenance-labeled knowledge packet', async () => {
  let call = 0;
  const client = { model: 'apollo-controller-test', async complete() {
    call++;
    if (call === 1) return { text: JSON.stringify({ needsMoE: false, capabilities: ['general_knowledge'], strategyId: 'conversation_reply' }) };
    return { text: JSON.stringify({ title: 'Test response', claims: [{ id: 'claim-1', text: 'A verified test claim.', kind: 'fact' }] }) };
  } };
  const controller = new LocalSlmControllerAdapter({ client });
  const plan = await controller.plan({ latestMessage: 'Explain a subject.' });
  assert.equal(plan.needsMoE, false);
  const response = await controller.respond({ prompt: 'Explain a subject.' });
  assert.equal(response.knowledgePacket.claims[0].sourceRefs[0], 'model-output:apollo-controller-test');
});

test('MoE and editorial adapters preserve strict data contracts', async () => {
  const moeClient = {
    model: 'apollo-moe-test',
    async complete() {
      return { text: JSON.stringify({ title: 'MoE response', claims: [{ id: 'moe-1', text: 'A specialist claim.', kind: 'inference' }] }) };
    }
  };
  const moe = new LocalMoEChildAdapter({ client: moeClient });
  const response = await moe.generate({ prompt: 'Explain', capabilities: ['scientific_reasoning'] });
  assert.equal(response.knowledgePacket.claims.length, 1);
  const editorClient = {
    async complete() {
      return { text: JSON.stringify({ text: 'A polished sentence.', preservedClaimIds: ['moe-1'] }) };
    }
  };
  const editor = new LocalEditorialAdapter({ client: editorClient });
  const rewritten = await editor.rewrite({ prompt: 'Explain', draft: 'draft', knowledgePacket: response.knowledgePacket, expectedClaimIds: ['moe-1'] });
  assert.equal(rewritten.text, 'A polished sentence.');
});

test('adapter factory supports distinct controller and Sleeping Giant loopback endpoints', () => {
  const fetchImpl = async () => { throw new Error('not called'); };
  const adapters = createLocalApolloAdapters({
    controller: { baseUrl: 'http://127.0.0.1:8080/v1', model: 'controller', fetchImpl },
    moe: { baseUrl: 'http://127.0.0.1:8081/v1', model: 'sleeping-giant', fetchImpl },
    editor: { baseUrl: 'http://127.0.0.1:8080/v1', model: 'controller', fetchImpl }
  });
  assert.equal(adapters.controller.modelId, 'controller');
  assert.equal(adapters.moeChild.modelId, 'sleeping-giant');
  assert.ok(adapters.dreamDirector);
  assert.ok(adapters.dreamSectionGenerator);
});

test('local model client sends an optional bearer key only to loopback inference', async () => {
  await withServer(async (req, res) => {
    assert.equal(req.headers.authorization, 'Bearer local-secret');
    if (req.url === '/v1/models') {
      res.writeHead(200, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ data: [{ id: 'local-qwen' }] }));
    } else jsonResponse(res, { answer: 'ok' });
  }, async baseUrl => {
    const client = new LocalOpenAIClient({ baseUrl, model: 'local-qwen', apiKey: 'local-secret' });
    const result = await client.probe();
    assert.deepEqual(result.models, ['local-qwen']);
  });
});

test('controller planner does not duplicate the latest user turn from session history', async () => {
  let captured;
  const adapter = new LocalSlmControllerAdapter({ client: { async complete(options) {
    captured = options.messages;
    return { text: JSON.stringify({ needsMoE: false, capabilities: ['conversation_context'], strategyId: 'conversation_reply' }) };
  } } });
  await adapter.plan({ latestMessage: 'latest user message', history: [{ role: 'user', text: 'previous turn' }, { role: 'assistant', text: 'previous answer' }, { role: 'user', text: 'latest user message' }] });
  const userMessages = captured.filter(message => message.role === 'user');
  assert.deepEqual(userMessages.map(message => message.content), ['previous turn', 'latest user message']);
});

test('local Apollo adapters can wrap inference with model-residency leases', async () => {
  const events = [];
  const residencyManager = { async withModel(id, options, operation) { events.push(['lease', id]); try { return await operation({}); } finally { events.push(['release', id]); } } };
  const fetchImpl = async (_url, options) => ({
    ok: true,
    status: 200,
    async json() { return { model: 'controller', choices: [{ message: { content: JSON.stringify({ needsMoE: false, capabilities: [], strategyId: 'conversation_reply' }) } }] }; },
    async text() { return ''; }
  });
  const adapters = createLocalApolloAdapters({ controller: { baseUrl: 'http://127.0.0.1:8080/v1', model: 'controller', fetchImpl, residencyManager, residencyModelId: 'controller-runtime', contextWindow: 2048 } });
  await adapters.controller.plan({ latestMessage: 'Hello', history: [] });
  assert.deepEqual(events, [['lease', 'controller-runtime'], ['release', 'controller-runtime']]);
});

test('Dream section generator falls back to controller when the Sleeping Giant is unavailable', async () => {
  const { LocalDreamSectionGenerator } = await import('../../src/runtime/local-model-adapters.js');
  const generator = new LocalDreamSectionGenerator({
    generator: { async generate() { throw new Error('MoE service stopped'); } },
    fallback: { async generate() { return { knowledgePacket: { title: 'fallback', claims: [{ id: 'x', text: 'fallback result' }] } }; } }
  });
  const result = await generator.generate({ objective: 'Explain', title: 'Section', capabilities: [] });
  assert.equal(result.delegatedToMoE, false);
  assert.equal(result.fallbackReason, 'sleeping_giant_unavailable');
});
