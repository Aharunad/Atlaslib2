import test from 'node:test';
import assert from 'node:assert/strict';
import { benchmarkNativeModel } from '../../src/runtime/native-runtime-benchmark.js';

test('native benchmark uses a fixed local prompt and returns measured runtime telemetry', async () => {
  let request;
  const result = await benchmarkNativeModel({
    async complete(options) {
      request = options;
      return {
        model: 'qwen3-0.6b-q4',
        text: 'A local model can work offline.',
        usage: {
          promptTokens: 31,
          generatedTokens: 24,
          promptMs: 82,
          generationMs: 1200,
          promptTokensPerSecond: 378.05,
          generationTokensPerSecond: 20
        }
      };
    }
  });
  assert.equal(request.temperature, 0);
  assert.equal(request.maxTokens, 96);
  assert.equal(request.responseFormat, 'text');
  assert.equal(request.messages.length, 2);
  assert.equal(result.model, 'qwen3-0.6b-q4');
  assert.equal(result.promptTokensPerSecond, 378.05);
  assert.equal(result.generationTokensPerSecond, 20);
  assert.equal(Object.isFrozen(result), true);
});

test('native benchmark rejects missing clients, unsafe limits and incomplete telemetry', async () => {
  await assert.rejects(() => benchmarkNativeModel(null), /client/);
  await assert.rejects(() => benchmarkNativeModel({ complete() {} }, { maxTokens: 8 }), /16 and 512/);
  await assert.rejects(() => benchmarkNativeModel({
    async complete() { return { text: 'generated', usage: { generatedTokens: 1 } }; }
  }), /complete benchmark result/);
});
