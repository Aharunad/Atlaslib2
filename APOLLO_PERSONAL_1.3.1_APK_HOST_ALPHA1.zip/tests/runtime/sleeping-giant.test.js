import test from 'node:test';
import assert from 'node:assert/strict';
import { inspectGgufFile, evaluateGgufCompatibility, GgufInspectionError } from '../../src/runtime/gguf-inspector.js';
import { SleepingGiantRegistry } from '../../src/runtime/sleeping-giant-registry.js';
import { MemoryKVAdapter } from '../../src/persistence/kv-adapters.js';
import { createAdaptiveModelProfile, estimateGgufKvCacheBytes, normalizeAndroidDeviceProfile } from '../../src/runtime/adaptive-model-profile.js';

function u32(value) {
  const out = Buffer.alloc(4); out.writeUInt32LE(value); return out;
}
function u64(value) {
  const out = Buffer.alloc(8); out.writeBigUInt64LE(BigInt(value)); return out;
}
function ggufString(value) {
  const data = Buffer.from(value, 'utf8');
  return Buffer.concat([u64(data.length), data]);
}
function metadataEntry(key, type, payload) {
  return Buffer.concat([ggufString(key), u32(type), payload]);
}
function makeGguf({ arrayCount = 3, metadataBeforeArchitecture = false } = {}) {
  const entries = [];
  const arch = metadataEntry('general.architecture', 8, ggufString('qwen3'));
  const context = metadataEntry('qwen3.context_length', 4, u32(4096));
  if (metadataBeforeArchitecture) entries.push(context, arch);
  else entries.push(arch, context);
  entries.push(
    metadataEntry('general.name', 8, ggufString('Qwen3 MoE fixture')),
    metadataEntry('general.file_type', 4, u32(15)),
    metadataEntry('qwen3.block_count', 4, u32(48)),
    metadataEntry('qwen3.embedding_length', 4, u32(4096)),
    metadataEntry('qwen3.attention.head_count', 4, u32(32)),
    metadataEntry('qwen3.attention.head_count_kv', 4, u32(8)),
    metadataEntry('qwen3.attention.key_length', 4, u32(128)),
    metadataEntry('qwen3.attention.value_length', 4, u32(128)),
    metadataEntry('qwen3.expert_count', 4, u32(128)),
    metadataEntry('qwen3.expert_used_count', 4, u32(8)),
    metadataEntry('tokenizer.ggml.model', 8, ggufString('qwen2')),
    metadataEntry('tokenizer.chat_template', 8, ggufString('template {{ messages }}'))
  );
  const tokens = Buffer.concat([
    u32(8), u64(arrayCount),
    ...Array.from({ length: Math.min(arrayCount, 12) }, (_, i) => ggufString(`token-${i}`))
  ]);
  entries.push(metadataEntry('tokenizer.ggml.tokens', 9, tokens));
  const header = Buffer.concat([
    Buffer.from('GGUF', 'ascii'), u32(3), u64(12), u64(entries.length), ...entries
  ]);
  return new Blob([header]);
}

const HASH = 'a'.repeat(64);
function successfulImport(overrides = {}) {
  const inspection = {
    format: 'gguf', version: 3, architecture: 'qwen3', name: 'Qwen3 MoE',
    tensorCount: 12, fileType: 15, tokenizerModel: 'qwen2', hasChatTemplate: true,
    contextLength: 4096, blockCount: 48, embeddingLength: 4096, headCount: 32, headCountKv: 8, keyLength: 128, valueLength: 128, expertCount: 128, expertUsedCount: 8,
    isMoE: true, fileBytes: 1024, metadataBytesRead: 400
  };
  return {
    ok: true,
    model: {
      displayName: 'qwen3-moe-q4.gguf', assetId: 'sg-aaaaaaaaaaaaaaaaaaaaaaaa',
      sha256: HASH, bytes: 1024, format: 'gguf', inspection,
      runtimeCapabilities: { available: false },
      ...overrides
    }
  };
}

test('GGUF inspector extracts architecture, model size, tokenizer and MoE metadata', async () => {
  const result = await inspectGgufFile(makeGguf());
  assert.equal(result.format, 'gguf');
  assert.equal(result.version, 3);
  assert.equal(result.architecture, 'qwen3');
  assert.equal(result.name, 'Qwen3 MoE fixture');
  assert.equal(result.tensorCount, 12);
  assert.equal(result.contextLength, 4096);
  assert.equal(result.blockCount, 48);
  assert.equal(result.embeddingLength, 4096);
  assert.equal(result.headCount, 32);
  assert.equal(result.headCountKv, 8);
  assert.equal(result.keyLength, 128);
  assert.equal(result.valueLength, 128);
  assert.equal(result.expertCount, 128);
  assert.equal(result.expertUsedCount, 8);
  assert.equal(result.isMoE, true);
  assert.equal(result.hasChatTemplate, true);
});

test('GGUF inspector finds architecture metadata even when it precedes architecture declaration', async () => {
  const result = await inspectGgufFile(makeGguf({ metadataBeforeArchitecture: true }));
  assert.equal(result.architecture, 'qwen3');
  assert.equal(result.contextLength, 4096);
});

test('GGUF inspector rejects a non-GGUF file', async () => {
  await assert.rejects(() => inspectGgufFile(new Blob([Buffer.alloc(64)])), error => error instanceof GgufInspectionError && error.code === 'GGUF_MAGIC');
});

test('GGUF inspector bounds array lengths before iterating', async () => {
  const file = makeGguf({ arrayCount: 1_000_001 });
  await assert.rejects(() => inspectGgufFile(file), error => error instanceof GgufInspectionError && error.code === 'GGUF_LIMIT');
});

test('GGUF inspector fails closed when metadata exceeds its bounded read window', async () => {
  const file = makeGguf();
  await assert.rejects(() => inspectGgufFile(file, { maxMetadataBytes: 64 }), error => error instanceof GgufInspectionError && ['GGUF_TRUNCATED', 'GGUF_LIMIT'].includes(error.code));
});

test('compatibility is never assumed without explicit native runtime capabilities', () => {
  const inspection = { format: 'gguf', architecture: 'qwen3' };
  assert.equal(evaluateGgufCompatibility(inspection).status, 'needs_runtime');
  assert.equal(evaluateGgufCompatibility(inspection, { available: true, formats: ['gguf'], supportedArchitectures: ['llama'] }).status, 'unsupported_architecture');
  assert.equal(evaluateGgufCompatibility(inspection, { available: true, formats: ['gguf'], supportedArchitectures: ['qwen3'] }).status, 'runtime_compatible');
});

test('registry persists selected model profile without storing a source path or URI', async () => {
  const adapter = new MemoryKVAdapter();
  const registry = new SleepingGiantRegistry({ adapter, now: () => 1_800_000_000_000 });
  const model = await registry.registerImport(successfulImport());
  assert.equal(model.modelId, `sg-${HASH.slice(0, 24)}`);
  assert.equal(model.status, 'needs_runtime');
  assert.equal(model.licenseReview, 'pending_user_review');
  assert.equal((await registry.getSelected()).modelId, model.modelId);
  const serialized = JSON.stringify(model);
  assert.equal(serialized.includes('content://'), false);
  assert.equal(serialized.includes('/storage/'), false);
  assert.equal(serialized.includes('privatePath'), false);
});

test('registry refuses malformed native import results before persisting anything', async () => {
  const adapter = new MemoryKVAdapter();
  const registry = new SleepingGiantRegistry({ adapter });
  const invalid = successfulImport();
  invalid.model.sha256 = 'not-a-hash';
  await assert.rejects(() => registry.registerImport(invalid), /SHA-256/);
  assert.equal((await registry.list()).length, 0);
});

test('registry records explicit license review without treating it as legal verification', async () => {
  const registry = new SleepingGiantRegistry({ adapter: new MemoryKVAdapter() });
  const model = await registry.registerImport(successfulImport());
  const updated = await registry.updateLicenseReview(model.modelId, true);
  assert.equal(updated.licenseReview, 'user_reviewed');
  assert.equal((await registry.get(model.modelId)).licenseReview, 'user_reviewed');
});

test('registry requires an explicit private-copy deletion path and leaves record intact on failure', async () => {
  const registry = new SleepingGiantRegistry({ adapter: new MemoryKVAdapter() });
  const model = await registry.registerImport(successfulImport());
  await assert.rejects(() => registry.remove(model.modelId, { deletePrivateCopy: true }), /Native storage host/);
  assert.ok(await registry.get(model.modelId));
  assert.equal(await registry.remove(model.modelId), true);
  assert.equal(await registry.get(model.modelId), undefined);
});

test('registry deletes only the host-managed private asset when explicitly requested', async () => {
  const removed = [];
  const registry = new SleepingGiantRegistry({
    adapter: new MemoryKVAdapter(),
    nativeHost: { async removeModelAsset(assetId) { removed.push(assetId); } }
  });
  const model = await registry.registerImport(successfulImport());
  await registry.remove(model.modelId, { deletePrivateCopy: true });
  assert.deepEqual(removed, [model.assetId]);
});

test('registry preserves a previous license-review acknowledgement when the same model is re-imported', async () => {
  const registry = new SleepingGiantRegistry({ adapter: new MemoryKVAdapter(), now: (() => { let t = 1_800_000_000_000; return () => t++; })() });
  const initial = await registry.registerImport(successfulImport());
  await registry.updateLicenseReview(initial.modelId, true);
  const reimported = await registry.registerImport(successfulImport());
  assert.equal(reimported.licenseReview, 'user_reviewed');
  assert.equal(reimported.createdAt, initial.createdAt);
});

test('registry rejects a private asset identifier that does not match the imported fingerprint', async () => {
  const registry = new SleepingGiantRegistry({ adapter: new MemoryKVAdapter() });
  const malformed = successfulImport();
  malformed.model.assetId = 'sg-bbbbbbbbbbbbbbbbbbbbbbbb';
  await assert.rejects(() => registry.registerImport(malformed), /asset identifier/);
  assert.equal((await registry.list()).length, 0);
});


const GiB = 1024 * 1024 * 1024;
const adaptiveInspection = {
  format: 'gguf', architecture: 'qwen3', fileBytes: 420 * 1024 * 1024,
  contextLength: 4096, blockCount: 28, embeddingLength: 1024,
  headCount: 16, headCountKv: 4, keyLength: 64, valueLength: 64
};
const fourGbAndroid = {
  totalRamBytes: 4 * GiB, availableRamBytes: 2.5 * GiB,
  lowRamDevice: false, lowMemory: false, cpuCores: 8,
  supportedAbis: ['arm64-v8a', 'armeabi-v7a'], apiLevel: 35,
  appMemoryClassMb: 256, availableStorageBytes: 8 * GiB,
  deviceSignature: 'Test Android'
};

test('Android profile normalizes hardware capabilities without treating app heap class as physical RAM', () => {
  const result = normalizeAndroidDeviceProfile(fourGbAndroid);
  assert.equal(result.totalRamBytes, 4 * GiB);
  assert.equal(result.appMemoryClassMb, 256);
  assert.equal(result.isArm64, true);
  assert.equal(result.deviceSignature, 'Test Android');
  assert.throws(() => normalizeAndroidDeviceProfile({ ...fourGbAndroid, supportedAbis: [] }), /ABI/);
});

test('KV cache estimate scales linearly with context length', () => {
  const oneK = estimateGgufKvCacheBytes(adaptiveInspection, 1024);
  const twoK = estimateGgufKvCacheBytes(adaptiveInspection, 2048);
  assert.equal(twoK, oneK * 2);
});

test('adaptive planner recommends a smaller context for a constrained device', () => {
  const profile = createAdaptiveModelProfile({ inspection: adaptiveInspection, device: fourGbAndroid });
  assert.ok([256, 512, 1024, 2048, 4096].includes(profile.recommendedContextTokens));
  assert.equal(profile.status, 'runtime_required');
  assert.equal(profile.runtimeAvailable, false);
  assert.equal(profile.isEstimate, true);
  assert.ok(profile.cpuThreads <= 2);
  assert.ok(profile.llamaCppOptions);
  assert.equal(profile.llamaCppOptions.gpuLayers, 0);
  assert.equal(profile.llamaCppOptions.kvCacheTypeK, 'f16');
});

test('adaptive planner rejects a model that exceeds the conservative device budget', () => {
  const profile = createAdaptiveModelProfile({
    inspection: { ...adaptiveInspection, fileBytes: 8 * GiB },
    device: { ...fourGbAndroid, availableRamBytes: 1 * GiB }
  });
  assert.equal(profile.status, 'likely_too_large');
  assert.equal(profile.recommendedContextTokens, null);
});

test('adaptive planner never marks a model ready merely because memory estimate fits', () => {
  const profile = createAdaptiveModelProfile({
    inspection: adaptiveInspection,
    device: { ...fourGbAndroid, totalRamBytes: 16 * GiB, availableRamBytes: 12 * GiB },
    runtimeCapabilities: { available: true, formats: ['gguf'], supportedArchitectures: ['qwen3'] }
  });
  assert.equal(profile.status, 'load_test_required');
  assert.match(profile.reason, /native model load test/);
  assert.equal(profile.gpuOffload, 'not_enabled_until_native_backend_probe');
});

test('adaptive planner blocks non-ARM64 devices from an unqualified mobile build', () => {
  const profile = createAdaptiveModelProfile({
    inspection: adaptiveInspection,
    device: { ...fourGbAndroid, supportedAbis: ['x86_64'] }
  });
  assert.equal(profile.status, 'unsupported_abi');
});

test('adaptive planner asks for more metadata instead of inventing a KV cache estimate', () => {
  const profile = createAdaptiveModelProfile({
    inspection: { format: 'gguf', architecture: 'unknown', fileBytes: 300 * 1024 * 1024, contextLength: 4096 },
    device: fourGbAndroid
  });
  assert.equal(profile.status, 'needs_more_metadata');
  assert.equal(profile.recommendedContextTokens, null);
});


test('runtime architecture wildcard delegates exact compatibility to the native loader', async () => {
  const { evaluateGgufCompatibility } = await import('../../src/runtime/gguf-inspector.js');
  const inspection = { format: 'gguf', architecture: 'new-architecture-added-upstream', fileBytes: 1024 };
  const result = evaluateGgufCompatibility(inspection, { available: true, formats: ['gguf'], architectureCandidates: ['*'] });
  assert.equal(result.status, 'runtime_compatible');
  assert.match(result.reason, /pinned loader/);
});
