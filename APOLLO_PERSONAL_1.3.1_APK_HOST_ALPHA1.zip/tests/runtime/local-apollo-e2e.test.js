import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { ApolloPersistentStore } from '../../src/persistence/apollo-persistent-store.js';
import { MemoryKVAdapter } from '../../src/persistence/kv-adapters.js';
import { SeedIntelligenceEngine } from '../../src/intelligence/seed-intelligence-engine.js';
import { ApolloConversationService } from '../../src/conversation/apollo-conversation-service.js';
import { createLocalApolloAdapters } from '../../src/runtime/local-model-adapters.js';

function sendJson(res, content) {
  res.writeHead(200, { 'content-type': 'application/json' });
  res.end(JSON.stringify({ model: 'test-local-qwen', choices: [{ message: { role: 'assistant', content: JSON.stringify(content) } }] }));
}

test('end-to-end Apollo conversation uses local OpenAI protocol, seeds, editorial and persistence', async () => {
  const server = createServer(async (req, res) => {
    if (req.method !== 'POST' || req.url !== '/v1/chat/completions') {
      res.writeHead(404); res.end(); return;
    }
    let body = '';
    for await (const chunk of req) body += chunk;
    const payload = JSON.parse(body);
    const system = payload.messages.find(item => item.role === 'system')?.content ?? '';
    if (system.includes('lightweight routing controller')) {
      sendJson(res, { needsMoE: false, capabilities: ['general_knowledge'], strategyId: 'conversation_reply' });
    } else if (system.includes('offline personal assistant')) {
      sendJson(res, { title: 'Ocean currents', claims: [{ id: 'ocean-1', text: 'Ocean currents move water through the global ocean.', kind: 'fact' }] });
    } else if (system.includes('editorial editor')) {
      const user = JSON.parse(payload.messages.at(-1).content);
      sendJson(res, { text: 'Ocean currents are large-scale flows of seawater.', preservedClaimIds: user.expectedClaimIds });
    } else {
      sendJson(res, { text: 'Unexpected test route' });
    }
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const baseUrl = `http://127.0.0.1:${server.address().port}/v1`;
  try {
    const store = new ApolloPersistentStore({ adapter: new MemoryKVAdapter() });
    const seedEngine = new SeedIntelligenceEngine({ contentStore: store, cache: store });
    const adapters = createLocalApolloAdapters({
      controller: { baseUrl, model: 'test-local-qwen' },
      editor: { baseUrl, model: 'test-local-qwen' }
    });
    const conversation = new ApolloConversationService({ store, seedEngine, ...adapters });
    await conversation.createSession({ id: 'apollo-local-e2e', title: 'Local model E2E' });
    const result = await conversation.send({ sessionId: 'apollo-local-e2e', text: 'Explain ocean currents.' });
    assert.equal(result.delegatedToMoE, false);
    assert.equal(result.editorialApplied, true);
    assert.match(result.answer, /large-scale flows/);
    const session = await store.getSession('apollo-local-e2e');
    assert.equal(session.turns.length, 2);
    assert.ok(session.turns[1].seedRefs.length === 2);
  } finally {
    await new Promise(resolve => server.close(resolve));
  }
});
