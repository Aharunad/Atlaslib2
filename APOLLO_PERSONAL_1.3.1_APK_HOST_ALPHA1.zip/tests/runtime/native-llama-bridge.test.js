import test from 'node:test';
import assert from 'node:assert/strict';
import { AndroidSleepingGiantBridge } from '../../src/runtime/android-sleeping-giant-bridge.js';
import { NativeLlamaClient } from '../../src/runtime/native-llama-client.js';

class FakeEventTarget {
  constructor() { this.listeners = new Map(); }
  addEventListener(name, callback) { const set = this.listeners.get(name) ?? new Set(); set.add(callback); this.listeners.set(name, set); }
  removeEventListener(name, callback) { this.listeners.get(name)?.delete(callback); }
  emit(name, detail) { for (const callback of this.listeners.get(name) ?? []) callback({ detail }); }
}

const uuid = 'f4fba4d2-29ae-4a89-b7fd-0e971cbedf10';
const assetId = `sg-${'a'.repeat(24)}`;

function makeHarness() {
  const events = new FakeEventTarget();
  const calls = [];
  const host = {
    getRuntimeCapabilities(requestId) {
      queueMicrotask(() => events.emit('atlas-apollo-native-result', { requestId, ok: true, runtimeCapabilities: {
        available: true, version: 'llama.cpp test-pin', formats: ['gguf'], architectureCandidates: ['*'], backend: 'cpu', gpuOffload: false
      } }));
    },
    loadSleepingGiant(requestId, id, contextTokens, threads, batchTokens) {
      calls.push({ method: 'load', id, contextTokens, threads, batchTokens });
      queueMicrotask(() => events.emit('atlas-apollo-native-result', { requestId, ok: true, sessionId: uuid, assetId: id, modelInfo: { contextTokens }, runtime: { engine: 'llama.cpp', backend: 'cpu' } }));
    },
    generateSleepingGiant(requestId, sessionId, messagesJson, maxTokens, responseFormat, temperature) {
      calls.push({ method: 'generate', sessionId, messagesJson, maxTokens, responseFormat, temperature });
      queueMicrotask(() => {
        events.emit('atlas-apollo-native-token', { requestId, sessionId, token: 'Apollo ' });
        events.emit('atlas-apollo-native-token', { requestId, sessionId, token: 'is ready.' });
        events.emit('atlas-apollo-native-result', { requestId, ok: true, sessionId, text: 'Apollo is ready.', metrics: { promptTokens: 14, generatedTokens: 4, promptMs: 5.5, generationMs: 8, promptTokensPerSecond: 2545, generationTokensPerSecond: 500 }, cancelled: false });
      });
    },
    cancelSleepingGiant(sessionId) { calls.push({ method: 'cancel', sessionId }); },
    unloadSleepingGiant(requestId, sessionId) {
      calls.push({ method: 'unload', sessionId });
      queueMicrotask(() => events.emit('atlas-apollo-native-result', { requestId, ok: true, unloaded: true }));
    }
  };
  return { events, calls, bridge: new AndroidSleepingGiantBridge({ host, eventTarget: events, timeoutMs: 5000 }) };
}

test('native bridge validates capabilities, loads a private asset and streams generation tokens', async () => {
  const { bridge, calls } = makeHarness();
  const capabilities = await bridge.getRuntimeCapabilities();
  assert.equal(capabilities.available, true);
  assert.deepEqual(capabilities.formats, ['gguf']);

  const loaded = await bridge.loadSleepingGiant(assetId, { contextTokens: 2048, threads: 3, batchTokens: 64 });
  assert.equal(loaded.sessionId, uuid);
  assert.equal(loaded.modelInfo.contextTokens, 2048);
  assert.equal(calls[0].method, 'load');

  let streamed = '';
  const result = await bridge.generateSleepingGiant({
    sessionId: loaded.sessionId,
    messages: [{ role: 'user', content: 'Say hello' }],
    maxTokens: 64,
    responseFormat: { type: 'json_object' },
    temperature: 0,
    onToken: token => { streamed += token; }
  });
  assert.equal(result.text, 'Apollo is ready.');
  assert.equal(result.metrics.generationTokensPerSecond, 500);
  assert.equal(streamed, 'Apollo is ready.');
  assert.equal(calls[1].method, 'generate');
  assert.equal(JSON.parse(calls[1].messagesJson)[0].content, 'Say hello');
  assert.equal(calls[1].responseFormat, 'json_object');
  assert.equal(calls[1].temperature, 0);

  assert.equal(await bridge.unloadSleepingGiant(loaded.sessionId), true);
  assert.equal(calls.at(-1).method, 'unload');
  bridge.dispose();
});

test('native bridge sends cancellation to the host and rejects the cancelled generation', async () => {
  const events = new FakeEventTarget();
  let cancelCalled = false;
  const host = {
    getRuntimeCapabilities() {},
    loadSleepingGiant() {},
    generateSleepingGiant(requestId, sessionId) {
      queueMicrotask(() => {
        events.emit('atlas-apollo-native-result', { requestId, ok: true, sessionId, text: 'partial', cancelled: true });
      });
    },
    cancelSleepingGiant() { cancelCalled = true; }
  };
  const bridge = new AndroidSleepingGiantBridge({ host, eventTarget: events, timeoutMs: 5000 });
  const controller = new AbortController();
  controller.abort();
  await assert.rejects(() => bridge.generateSleepingGiant({ sessionId: uuid, messages: [{ role: 'user', content: 'x' }], signal: controller.signal }), /cancelled/i);
  assert.equal(cancelCalled, false, 'already-aborted requests are rejected before they enter native code');
  bridge.dispose();
});

test('native bridge rejects malformed load options before calling Android', async () => {
  const { bridge, calls } = makeHarness();
  await assert.rejects(() => bridge.loadSleepingGiant(assetId, { contextTokens: 20, threads: 2, batchTokens: 32 }), /contextTokens/);
  assert.equal(calls.length, 0);
  bridge.dispose();
});

test('NativeLlamaClient adapts a loaded native session and forwards structured response settings', async () => {
  const { bridge } = makeHarness();
  let session = { sessionId: uuid };
  const client = new NativeLlamaClient({ bridge, getSession: () => session, model: 'qwen3-native' });
  assert.deepEqual(await client.probe(), { available: true, configuredModel: 'qwen3-native', models: ['qwen3-native'] });
  const result = await client.complete({ messages: [{ role: 'user', content: 'Say hello' }], maxTokens: 24, responseFormat: { type: 'json_object' }, temperature: 0 });
  assert.equal(result.text, 'Apollo is ready.');
  assert.equal(result.model, 'qwen3-native');
  assert.equal(result.usage.generationTokensPerSecond, 500);
  session = null;
  await assert.rejects(() => client.complete({ messages: [{ role: 'user', content: 'Again' }] }), /No Sleeping Giant/);
  bridge.dispose();
});


test('native client rejects unsupported response formats and invalid temperature before host access', async () => {
  const { bridge, calls } = makeHarness();
  const client = new NativeLlamaClient({ bridge, getSession: () => ({ sessionId: uuid }), model: 'qwen3-native' });
  await assert.rejects(() => client.complete({ messages: [{ role: 'user', content: 'x' }], responseFormat: { type: 'json_schema' } }), /responseFormat/);
  await assert.rejects(() => client.complete({ messages: [{ role: 'user', content: 'x' }], temperature: 2.1 }), /temperature/);
  assert.equal(calls.length, 0);
  bridge.dispose();
});
