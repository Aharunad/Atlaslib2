import test from 'node:test';
import assert from 'node:assert/strict';
import { ResidencyBoundClient } from '../../src/runtime/residency-bound-client.js';

test('residency-bound client acquires and releases a model lease around inference', async () => {
  const events = [];
  const manager = {
    async withModel(modelId, options, run) {
      events.push(['acquire', modelId, options.contextTokens]);
      try { return await run({ handleId: modelId }); }
      finally { events.push(['release', modelId]); }
    }
  };
  const client = new ResidencyBoundClient({ manager, modelId: 'controller', client: { async complete() { return { text: 'ok' }; } }, estimateTokens: () => 768 });
  const response = await client.complete({ messages: [{ role: 'user', content: 'hi' }] });
  assert.equal(response.text, 'ok');
  assert.deepEqual(events, [['acquire', 'controller', 768], ['release', 'controller']]);
});

test('residency-bound client releases model even when generation fails', async () => {
  let released = false;
  const client = new ResidencyBoundClient({
    manager: { async withModel(_id, _options, run) { try { return await run({}); } finally { released = true; } } },
    modelId: 'controller',
    client: { async complete() { throw new Error('backend failed'); } }
  });
  await assert.rejects(() => client.complete({ messages: [{ role: 'user', content: 'hi' }] }), /backend failed/);
  assert.equal(released, true);
});
