import test from 'node:test';
import assert from 'node:assert/strict';
import { ApolloPersistentStore } from '../../src/persistence/apollo-persistent-store.js';
import { MemoryKVAdapter } from '../../src/persistence/kv-adapters.js';
import { SeedIntelligenceEngine } from '../../src/intelligence/seed-intelligence-engine.js';
import { ApolloDreamService } from '../../src/dream/apollo-dream-service.js';
import { createKnowledgePacket } from '../../src/intelligence/knowledge-packet.js';
import { validateDreamPlan } from '../../src/dream/apollo-dream-service.js';

test('Dream plan rejects unbounded section count and invalid capabilities', () => {
  assert.throws(() => validateDreamPlan({ title: 'Bad', sections: [{ id: 'one', title: 'One', objective: 'One', capabilities: ['run_shell'] }, { id: 'two', title: 'Two', objective: 'Two' }] }), /Unsupported capability/);
});

test('Apollo Dream creates a multi-section editorial artifact using MAKETINY child seeds lazily', async () => {
  const store = new ApolloPersistentStore({ adapter: new MemoryKVAdapter() });
  const seedEngine = new SeedIntelligenceEngine({ contentStore: store, cache: store });
  const director = {
    async plan() {
      return { title: 'A Short Guide to Ocean Currents', sections: [
        { id: 'overview', title: 'Overview', objective: 'Explain what ocean currents are.', capabilities: ['general_knowledge'] },
        { id: 'drivers', title: 'What Drives Them', objective: 'Explain wind, density and Earth rotation.', capabilities: ['scientific_reasoning'] },
        { id: 'importance', title: 'Why They Matter', objective: 'Explain climate and ecosystems.', capabilities: ['general_knowledge'] }
      ] };
    }
  };
  const sectionGenerator = {
    async generate({ title }) {
      const packet = await createKnowledgePacket({ title, claims: [{ id: 'c1', text: `${title}: ocean currents move water through the global ocean.`, kind: 'fact', sourceRefs: ['fixture:oceans'] }] });
      return { knowledgePacket: packet.packet };
    }
  };
  const editor = {
    async rewrite({ expectedClaimIds }) {
      return { text: '# A Short Guide to Ocean Currents\n\nOcean currents move water through the global ocean.', preservedClaimIds: expectedClaimIds };
    }
  };
  const service = new ApolloDreamService({ store, seedEngine, director, sectionGenerator, editor });
  const statuses = [];
  const result = await service.create({ objective: 'Create a concise guide to ocean currents.', randomSeed: 'dream-test-001', onStatus: status => statuses.push(status) });
  assert.equal(result.sections.length, 3);
  assert.equal(result.metrics.claimCount, 3);
  assert.equal(result.metrics.editorialApplied, true);
  assert.equal(result.seeds.sectionSeeds.length, 3);
  assert.match(result.document, /ocean currents/i);
  assert.ok(statuses.includes('dreaming_plan'));
  assert.ok(statuses.includes('dream_complete'));
  const stats = await store.stats();
  assert.equal(stats.seedEntries, 2); // reasoning + parent dream; child seeds are transient.
});
