import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { FileKVAdapter } from '../src/persistence/file-kv-adapter.js';
import { MemoryKVAdapter } from '../src/persistence/kv-adapters.js';
import { ApolloPersistentStore } from '../src/persistence/apollo-persistent-store.js';
import { ApolloConversationService } from '../src/conversation/apollo-conversation-service.js';
import { SeedIntelligenceEngine } from '../src/intelligence/seed-intelligence-engine.js';
import { MakeTiny2Engine } from '../src/intelligence/maketiny2.js';
import { createKnowledgePacket } from '../src/intelligence/knowledge-packet.js';
import { validateReasoningSeed } from '../src/intelligence/seed-packet.js';
import { canonicalBytes } from '../src/intelligence/digest.js';

const claims = [
  { id: 'fact-water-1', text: 'Water evaporates when it gains sufficient energy.', kind: 'fact', sourceRefs: ['fixture:water#evaporation'], topic: 'evaporation' },
  { id: 'fact-water-2', text: 'Water vapor can condense into liquid droplets as air cools.', kind: 'fact', sourceRefs: ['fixture:water#condensation'], topic: 'condensation' }
];

 test('file-backed persistent store survives adapter recreation and verifies content hashes', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'apollo-persist-'));
  const file = join(dir, 'atlas-store.json');
  try {
    const first = new ApolloPersistentStore({ adapter: new FileKVAdapter(file) });
    const packet = await createKnowledgePacket({ title: 'Water cycle', claims });
    const stored = await first.putContent(packet.packet);
    await first.createSession({ id: 'session-persist-1', title: 'Science' });
    await first.appendTurn('session-persist-1', { role: 'user', text: 'Explain evaporation.' });

    const second = new ApolloPersistentStore({ adapter: new FileKVAdapter(file) });
    assert.deepEqual(await second.getContent(stored.reference), packet.packet);
    const session = await second.getSession('session-persist-1');
    assert.equal(session.turns[0].text, 'Explain evaporation.');
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});

test('persistent conversation updates are serialized and bounded', async () => {
  const store = new ApolloPersistentStore({ adapter: new MemoryKVAdapter(), maxSessionTurns: 30 });
  await store.createSession({ id: 'concurrent-session' });
  await Promise.all(Array.from({ length: 20 }, (_, index) => store.appendTurn('concurrent-session', { role: 'user', text: `message-${index}` })));
  const session = await store.getSession('concurrent-session');
  assert.equal(session.turns.length, 20);
  assert.equal(session.revision, 20);
});

test('persistent cache evicts least-recently-used entries to stay within budget', async () => {
  const store = new ApolloPersistentStore({ adapter: new MemoryKVAdapter(), maxCacheBytes: 120, now: (() => { let time = 1000; return () => ++time; })() });
  assert.equal(await store.cacheSet('one', { text: 'a'.repeat(35) }), true);
  assert.equal(await store.cacheSet('two', { text: 'b'.repeat(35) }), true);
  await store.cacheGet('one');
  assert.equal(await store.cacheSet('three', { text: 'c'.repeat(35) }), true);
  assert.notEqual(await store.cacheGet('one'), undefined);
  assert.equal(await store.cacheGet('two'), undefined);
  assert.notEqual(await store.cacheGet('three'), undefined);
});

test('Apollo conversation orchestrates controller, Sleeping Giant, MAKETINY and editorial adapter', async () => {
  const store = new ApolloPersistentStore({ adapter: new MemoryKVAdapter() });
  const makeTiny = new MakeTiny2Engine();
  const seedEngine = new SeedIntelligenceEngine({ contentStore: store, makeTiny });
  const packet = await createKnowledgePacket({ title: 'Water cycle facts', claims });
  let planCalls = 0;
  let moeCalls = 0;
  let editorCalls = 0;
  const controller = {
    async plan({ latestMessage }) {
      planCalls++;
      assert.match(latestMessage, /water/i);
      return { needsMoE: true, capabilities: ['scientific_reasoning', 'general_knowledge'], strategyId: 'conversation_reply' };
    }
  };
  const moeChild = {
    async generate({ capabilities }) {
      moeCalls++;
      assert.deepEqual(capabilities, ['general_knowledge', 'scientific_reasoning']);
      return { knowledgePacket: packet.packet };
    }
  };
  const editor = {
    async rewrite({ expectedClaimIds }) {
      editorCalls++;
      return { text: 'Water moves through evaporation and condensation.', preservedClaimIds: expectedClaimIds };
    }
  };
  const service = new ApolloConversationService({ store, seedEngine, controller, moeChild, editor });
  await service.createSession({ id: 'apollo-demo-session', title: 'Water science' });
  const result = await service.send({ sessionId: 'apollo-demo-session', text: 'Explain the water cycle.' });

  assert.equal(planCalls, 1);
  assert.equal(moeCalls, 1);
  assert.equal(editorCalls, 1);
  assert.equal(result.delegatedToMoE, true);
  assert.equal(result.editorialApplied, true);
  assert.equal(result.derivedChildSeeds, 3); // MoE plan + two capability seeds.
  assert.match(result.answer, /evaporation and condensation/);

  const session = await store.getSession('apollo-demo-session');
  assert.equal(session.turns.length, 2);
  assert.equal(session.turns[1].role, 'assistant');
  assert.equal(session.turns[1].seedRefs.length, 2);
  assert.ok(await store.getSeed(result.reasoningSeedId, validateReasoningSeed));
  assert.ok(await store.getSeed(result.dreamSeedId, seed => makeTiny.validate(seed)));

  // Child seeds were derived only for the active request, not persisted as an expanded tree.
  const stats = await store.stats();
  assert.equal(stats.seedEntries, 2);
});

test('Apollo refuses model-generated tool execution and does not append an assistant success turn', async () => {
  const store = new ApolloPersistentStore({ adapter: new MemoryKVAdapter() });
  const seedEngine = new SeedIntelligenceEngine({ contentStore: store });
  await store.createSession({ id: 'apollo-reject-session' });
  const service = new ApolloConversationService({
    store,
    seedEngine,
    controller: { async plan() { return { needsMoE: true, capabilities: ['scientific_reasoning'] }; } },
    moeChild: { async generate() { return { knowledgePacket: { format: 'APOLLO_KNOWLEDGE_PACKET', schemaVersion: 1, title: 'x', claims: [] }, toolRequests: ['filesystem'] }; } }
  });
  await assert.rejects(() => service.send({ sessionId: 'apollo-reject-session', text: 'Explain science.' }), /tool execution is not enabled/);
  const session = await store.getSession('apollo-reject-session');
  assert.equal(session.turns.length, 1);
  assert.equal(session.turns[0].role, 'user');
});

test('MAKETINY derives an individual child without materializing sibling seed objects', async () => {
  const engine = new MakeTiny2Engine();
  const root = await engine.createRoot({
    parameters: { taskType: 'conversation', objective: 'Explain a subject', editorialStyle: 'editorial', capabilities: ['general_knowledge', 'scientific_reasoning', 'comparison'], sections: ['Overview', 'Details'], voiceEnabled: true, visualEnabled: true },
    generationSeed: 'lazy-child-test'
  });
  const count = await engine.countChildren(root.seed);
  assert.equal(count, 5);
  const one = await engine.deriveChild(root.seed, 1);
  const page = await engine.expand(root.seed, { offset: 1, limit: 1 });
  assert.equal(page.children.length, 1);
  assert.equal(one.seedId, page.children[0].seedId);
  assert.equal(one.role, 'moe_plan');
});

test('persistent store rejects tampered knowledge and keeps existing data intact', async () => {
  const adapter = new MemoryKVAdapter();
  const store = new ApolloPersistentStore({ adapter });
  const packet = await createKnowledgePacket({ title: 'Integrity test', claims });
  const saved = await store.putContent(packet.packet);
  await adapter.put(`content:${saved.digest}`, { reference: saved.reference, digest: saved.digest, size: saved.size, value: { ...packet.packet, title: 'Tampered' }, storedAt: Date.now() });
  await assert.rejects(() => store.getContent(saved.reference), /integrity check failed/);
});

test('parent seed cannot be deleted while a persisted child depends on it', async () => {
  const store = new ApolloPersistentStore({ adapter: new MemoryKVAdapter() });
  const makeTiny = new MakeTiny2Engine();
  const root = await makeTiny.createRoot({ parameters: { taskType: 'conversation', objective: 'Lineage', editorialStyle: 'editorial', capabilities: [], sections: ['Overview'], voiceEnabled: false, visualEnabled: false }, generationSeed: 'lineage-root' });
  await store.putSeed(root.seed, seed => makeTiny.validate(seed));
  const child = await store.deriveChildSeed(root.seed.seedId, 2, makeTiny, { persist: true });
  assert.equal(child.parentSeedId, root.seed.seedId);
  await assert.rejects(() => store.deleteSeed(root.seed.seedId), /persisted child seeds depend on it/);
  await store.deleteSeed(child.seedId);
  await store.deleteSeed(root.seed.seedId);
});

test('failed memory adapter update is atomic and leaves the old value intact', async () => {
  const adapter = new MemoryKVAdapter({ maxBytes: 120 });
  await adapter.put('stable', { value: 'ok' });
  await assert.rejects(() => adapter.update('stable', () => ({ value: 'x'.repeat(500) })), /byte budget exceeded/);
  assert.deepEqual(await adapter.get('stable'), { value: 'ok' });
});

test('failed session append leaves the previous revision untouched', async () => {
  const store = new ApolloPersistentStore({ adapter: new MemoryKVAdapter(), maxSessionBytes: 450 });
  await store.createSession({ id: 'bounded-append-session' });
  await store.appendTurn('bounded-append-session', { role: 'user', text: 'first' });
  const before = await store.getSession('bounded-append-session');
  await assert.rejects(() => store.appendTurn('bounded-append-session', { role: 'assistant', text: 'x'.repeat(1000) }), /storage budget/);
  const after = await store.getSession('bounded-append-session');
  assert.equal(after.revision, before.revision);
  assert.equal(after.turns.length, 1);
});

test('persistent seed-result cache survives a new engine instance', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'apollo-result-cache-'));
  const file = join(dir, 'store.json');
  try {
    const firstStore = new ApolloPersistentStore({ adapter: new FileKVAdapter(file) });
    const firstEngine = new SeedIntelligenceEngine({ contentStore: firstStore, cache: firstStore });
    const packet = await createKnowledgePacket({ title: 'Persistent replay', claims });
    const compiled = await firstEngine.compile({
      request: { taskType: 'explain', objective: 'Explain evaporation.', title: 'Evaporation', editorialStyle: 'editorial' },
      knowledgePackets: [packet.packet],
      strategyId: 'explain_concept',
      randomSeed: 'persistent-result-cache'
    });
    const first = await firstEngine.replay(compiled.seed);
    assert.equal(first.cache.hit, false);

    const secondStore = new ApolloPersistentStore({ adapter: new FileKVAdapter(file) });
    const secondEngine = new SeedIntelligenceEngine({ contentStore: secondStore, cache: secondStore });
    const second = await secondEngine.replay(compiled.seed);
    assert.equal(second.cache.hit, true);
    assert.equal(second.document.text, first.document.text);
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});

test('seed persistence rejects missing referenced knowledge rather than creating an orphan', async () => {
  const store = new ApolloPersistentStore({ adapter: new MemoryKVAdapter() });
  const engine = new SeedIntelligenceEngine({ contentStore: store });
  const packet = await createKnowledgePacket({ title: 'Orphan check', claims });
  const compiled = await engine.compile({
    request: { taskType: 'explain', objective: 'Explain water.', title: 'Water', editorialStyle: 'editorial' },
    knowledgePackets: [packet.packet],
    strategyId: 'explain_concept',
    randomSeed: 'orphan-check'
  });
  await store.deleteContent(compiled.seed.contextRefs[0]);
  await assert.rejects(() => store.putSeed(compiled.seed, validateReasoningSeed), /Required content-addressed context is unavailable/);
});

test('controller can answer directly without waking the MoE child', async () => {
  const store = new ApolloPersistentStore({ adapter: new MemoryKVAdapter() });
  const seedEngine = new SeedIntelligenceEngine({ contentStore: store });
  const packet = await createKnowledgePacket({ title: 'Direct answer', claims: [{ id: 'direct-fact-1', text: 'A triangle has three sides.', kind: 'fact', sourceRefs: ['fixture:geometry'] }] });
  let moeCalls = 0;
  const service = new ApolloConversationService({
    store,
    seedEngine,
    controller: {
      async plan() { return { needsMoE: false, capabilities: [] }; },
      async respond() { return { knowledgePacket: packet.packet }; }
    },
    moeChild: { async generate() { moeCalls++; throw new Error('Must not wake MoE for direct request'); } }
  });
  await store.createSession({ id: 'direct-controller-session' });
  const result = await service.send({ sessionId: 'direct-controller-session', text: 'How many sides does a triangle have?' });
  assert.equal(result.delegatedToMoE, false);
  assert.equal(moeCalls, 0);
  assert.match(result.answer, /three sides/i);
});

test('persistent content-addressed store enforces a total storage budget', async () => {
  const firstPacket = await createKnowledgePacket({ title: 'Budget one', claims: [{ id: 'budget-claim-1', text: 'First content item.', kind: 'fact', sourceRefs: ['fixture:budget'] }] });
  const secondPacket = await createKnowledgePacket({ title: 'Budget two', claims: [{ id: 'budget-claim-2', text: 'Second distinct content item.', kind: 'fact', sourceRefs: ['fixture:budget'] }] });
  const oneBytes = canonicalBytes(firstPacket.packet);
  const twoBytes = canonicalBytes(secondPacket.packet);
  const store = new ApolloPersistentStore({ adapter: new MemoryKVAdapter(), maxContentBytes: oneBytes + twoBytes - 1 });
  await store.putContent(firstPacket.packet);
  assert.ok(twoBytes > 4);
  await assert.rejects(() => store.putContent(secondPacket.packet), /Persistent content store is full/);
  const stats = await store.stats();
  assert.equal(stats.contentEntries, 1);
});

test('knowledge content cannot be deleted while persisted seeds reference it', async () => {
  const store = new ApolloPersistentStore({ adapter: new MemoryKVAdapter() });
  const makeTiny = new MakeTiny2Engine();
  const seedEngine = new SeedIntelligenceEngine({ contentStore: store, makeTiny });
  const packet = await createKnowledgePacket({ title: 'Referenced content', claims });
  const compiled = await seedEngine.compile({
    request: { taskType: 'explain', objective: 'Explain a concept.', title: 'Concept', editorialStyle: 'editorial' },
    knowledgePackets: [packet.packet],
    strategyId: 'explain_concept',
    randomSeed: 'content-dependency'
  });
  await store.putSeed(compiled.seed, validateReasoningSeed);
  await assert.rejects(() => store.deleteContent(compiled.seed.contextRefs[0]), /still referenced by persisted seeds/);
  await store.deleteSeed(compiled.seed.seedId);
  await store.deleteSeed(compiled.dreamSeed.seedId);
  await store.deleteContent(compiled.seed.contextRefs[0]);
  assert.equal(await store.hasContent(compiled.seed.contextRefs[0]), false);
});

test('persistent cache prunes expired entries', async () => {
  let time = 10000;
  const store = new ApolloPersistentStore({ adapter: new MemoryKVAdapter(), now: () => time });
  await store.cacheSet('expire-me', { text: 'temporary' }, { ttlMs: 1000 });
  time += 2000;
  assert.equal(await store.pruneCache(), 1);
  assert.equal(await store.cacheGet('expire-me'), undefined);
});

test('Apollo falls back to the local controller when the Sleeping Giant is not installed', async () => {
  const store = new ApolloPersistentStore({ adapter: new MemoryKVAdapter() });
  const seedEngine = new SeedIntelligenceEngine({ contentStore: store });
  await store.createSession({ id: 'apollo-controller-fallback' });
  const packet = await createKnowledgePacket({ title: 'Fallback answer', claims });
  let controllerCalls = 0;
  const service = new ApolloConversationService({
    store,
    seedEngine,
    controller: {
      async plan() { return { needsMoE: true, capabilities: ['scientific_reasoning'], strategyId: 'conversation_reply' }; },
      async respond() { controllerCalls++; return { knowledgePacket: packet.packet }; }
    },
    moeChild: null
  });
  const events = [];
  const result = await service.send({ sessionId: 'apollo-controller-fallback', text: 'Explain this science topic.', onStatus: state => events.push(state) });
  assert.equal(controllerCalls, 1);
  assert.equal(result.delegatedToMoE, false);
  assert.equal(result.degradedMode, true);
  assert.ok(events.includes('controller_fallback'));
  assert.match(result.answer, /water/i);
});

test('Apollo marks controller-only fallback when the planned MoE child is absent', async () => {
  const store = new ApolloPersistentStore({ adapter: new MemoryKVAdapter() });
  const engine = new SeedIntelligenceEngine({ contentStore: store });
  await store.createSession({ id: 'apollo-fallback-session' });
  const packet = await createKnowledgePacket({ title: 'Fallback knowledge', claims });
  const service = new ApolloConversationService({
    store, seedEngine: engine,
    controller: {
      async plan() { return { needsMoE: true, capabilities: ['scientific_reasoning'], strategyId: 'conversation_reply' }; },
      async respond() { return { knowledgePacket: packet.packet }; }
    },
    moeChild: null
  });
  let sawFallback = false;
  const result = await service.send({ sessionId: 'apollo-fallback-session', text: 'Explain the water cycle.', onStatus: status => { if (status === 'controller_fallback') sawFallback = true; } });
  assert.equal(result.delegatedToMoE, false);
  assert.equal(result.degradedMode, true);
  assert.equal(sawFallback, true);
});

test('Apollo falls back when an installed Sleeping Giant fails to load or generate', async () => {
  const store = new ApolloPersistentStore({ adapter: new MemoryKVAdapter() });
  const engine = new SeedIntelligenceEngine({ contentStore: store });
  await store.createSession({ id: 'apollo-moe-failure-session' });
  const packet = await createKnowledgePacket({ title: 'Controller fallback', claims });
  const service = new ApolloConversationService({
    store, seedEngine: engine,
    controller: {
      async plan() { return { needsMoE: true, capabilities: ['scientific_reasoning'], strategyId: 'conversation_reply' }; },
      async respond() { return { knowledgePacket: packet.packet }; }
    },
    moeChild: { async generate() { throw new Error('Native MoE runtime unavailable'); } }
  });
  const result = await service.send({ sessionId: 'apollo-moe-failure-session', text: 'Explain the water cycle.' });
  assert.equal(result.delegatedToMoE, false);
  assert.equal(result.degradedMode, true);
});

test('Apollo bounds recent conversation context by character budget while retaining the latest turn', async () => {
  const store = new ApolloPersistentStore({ adapter: new MemoryKVAdapter() });
  const engine = new SeedIntelligenceEngine({ contentStore: store });
  await store.createSession({ id: 'apollo-history-budget' });
  for (let index = 0; index < 8; index++) await store.appendTurn('apollo-history-budget', { role: index % 2 ? 'assistant' : 'user', text: `turn-${index}-` + 'x'.repeat(700) });
  const packet = await createKnowledgePacket({ title: 'Bounded history', claims });
  let observedHistory;
  const service = new ApolloConversationService({
    store, seedEngine: engine, maxHistoryTurns: 16, maxHistoryChars: 2400,
    controller: {
      async plan({ latestMessage, history }) { observedHistory = history; return { needsMoE: false, capabilities: [], strategyId: 'conversation_reply' }; },
      async respond() { return { knowledgePacket: packet.packet }; }
    }
  });
  await service.send({ sessionId: 'apollo-history-budget', text: 'latest prompt' });
  assert.ok(observedHistory.reduce((sum, turn) => sum + turn.text.length, 0) <= 2400);
  assert.equal(observedHistory.at(-1).text, 'latest prompt');
});

test('Apollo retains deterministic assembly if the editorial model fails its claim-preservation contract', async () => {
  const store = new ApolloPersistentStore({ adapter: new MemoryKVAdapter() });
  const engine = new SeedIntelligenceEngine({ contentStore: store });
  await store.createSession({ id: 'apollo-editor-fallback' });
  const packet = await createKnowledgePacket({ title: 'Editorial fallback', claims });
  const service = new ApolloConversationService({
    store, seedEngine: engine,
    controller: {
      async plan() { return { needsMoE: false, capabilities: ['general_knowledge'], strategyId: 'conversation_reply' }; },
      async respond() { return { knowledgePacket: packet.packet }; }
    },
    editor: { async rewrite() { return { text: 'An edited answer that dropped a claim.', preservedClaimIds: ['fact-water-1'] }; } }
  });
  let fallbackSeen = false;
  const result = await service.send({ sessionId: 'apollo-editor-fallback', text: 'Explain the water cycle.', onStatus: status => { if (status === 'editorial_fallback') fallbackSeen = true; } });
  assert.equal(result.editorialApplied, false);
  assert.equal(result.editorialFallback, true);
  assert.equal(fallbackSeen, true);
  assert.match(result.answer, /water vapor/i);
});
