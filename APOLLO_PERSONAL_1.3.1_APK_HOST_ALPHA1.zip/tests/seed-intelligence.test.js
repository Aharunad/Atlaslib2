import test from 'node:test';
import assert from 'node:assert/strict';
import {
  SeedIntelligenceEngine,
  ContentAddressedStore,
  SeedCache,
  createKnowledgePacket,
  exportReasoningSeed,
  importReasoningSeed,
  validateReasoningSeed,
  validateControllerPlan,
  validateMoEResponse,
  validateEditorialResponse,
  MissingContextError,
  canonicalStringify
} from '../src/index.js';

const knowledge = async () => createKnowledgePacket({
  title: 'The water cycle',
  metadata: { collection: 'apollo-demo', revision: '1', language: 'en', createdBy: 'fixture' },
  claims: [
    { id: 'evaporation', text: 'Solar energy causes liquid water at the surface to evaporate.', kind: 'fact', sourceRefs: ['demo:water-cycle#evaporation'], confidence: 0.99, priority: 90, topic: 'How it works' },
    { id: 'condensation', text: 'Water vapor cools and condenses into droplets that form clouds.', kind: 'fact', sourceRefs: ['demo:water-cycle#condensation'], confidence: 0.99, priority: 85 },
    { id: 'precipitation', text: 'Water returns to the surface as precipitation, including rain and snow.', kind: 'fact', sourceRefs: ['demo:water-cycle#precipitation'], confidence: 0.99, priority: 80 },
    { id: 'runoff', text: 'Some water flows over land or through groundwater back toward rivers and oceans.', kind: 'fact', sourceRefs: ['demo:water-cycle#collection'], confidence: 0.98, priority: 70 }
  ]
});

const request = {
  taskType: 'explain',
  title: 'How the water cycle works',
  objective: 'Explain the continuous movement of water through the environment.',
  audience: 'curious general reader',
  editorialStyle: 'editorial',
  language: 'en'
};

test('knowledge packet is content-addressed and immutable by reference', async () => {
  const first = await knowledge();
  const second = await knowledge();
  assert.equal(first.reference, second.reference);
  assert.equal(first.digest.length, 64);
});

test('seed compiles to a compact strategy reference without embedding knowledge claims', async () => {
  const packet = await knowledge();
  const engine = new SeedIntelligenceEngine();
  const compiled = await engine.compile({ request, knowledgePackets: [packet.packet], randomSeed: 'water-cycle-fixed' });
  assert.ok(compiled.diagnostics.seedBytes < compiled.diagnostics.referencedContextBytes);
  assert.equal(compiled.seed.contextRefs.length, 1);
  assert.equal(compiled.seed.claims, undefined);
  assert.equal(compiled.diagnostics.seedIsSelfContained, false);
});

test('same seed and same context replay byte-identically', async () => {
  const packet = await knowledge();
  const engine = new SeedIntelligenceEngine();
  const compiled = await engine.compile({ request, knowledgePackets: [packet.packet], randomSeed: 'replay-001' });
  const first = await engine.replay(compiled.seed, { useCache: false });
  const second = await engine.replay(compiled.seed, { useCache: false });
  assert.equal(canonicalStringify(first), canonicalStringify(second));
  assert.equal(first.deterministic, true);
  assert.equal(first.audit.passed, true);
});

test('same input with different generation seeds can select different editorial variants', async () => {
  const packet = await knowledge();
  const engine = new SeedIntelligenceEngine();
  const variants = new Set();
  for (let i = 0; i < 32; i++) {
    const compiled = await engine.compile({ request, knowledgePackets: [packet.packet], randomSeed: `variant-${i}` });
    variants.add(compiled.seed.strategy.variantId);
  }
  assert.ok(variants.size > 1);
});

test('seed export/import validates its digest', async () => {
  const packet = await knowledge();
  const engine = new SeedIntelligenceEngine();
  const { seed } = await engine.compile({ request, knowledgePackets: [packet.packet], randomSeed: 'export-001' });
  const imported = await importReasoningSeed(exportReasoningSeed(seed));
  assert.deepEqual(await validateReasoningSeed(imported), await validateReasoningSeed(seed));
  const tampered = structuredClone(imported);
  tampered.request.title = 'Altered title';
  await assert.rejects(() => validateReasoningSeed(tampered), /digest mismatch/);
});

test('seed alone cannot recreate a missing knowledge packet', async () => {
  const packet = await knowledge();
  const writer = new SeedIntelligenceEngine();
  const { seed } = await writer.compile({ request, knowledgePackets: [packet.packet], randomSeed: 'missing-context' });
  const reader = new SeedIntelligenceEngine({ contentStore: new ContentAddressedStore() });
  await assert.rejects(() => reader.replay(seed), MissingContextError);
});

test('content store detects tampered stored content', async () => {
  const packet = await knowledge();
  const store = new ContentAddressedStore();
  const { reference } = await store.put(packet.packet);
  const entry = store.entries.get(reference);
  entry.value.claims[0].text = 'tampered';
  await assert.rejects(() => store.get(reference), /integrity check failed/);
});

test('replay cache returns a hit without changing the result', async () => {
  const packet = await knowledge();
  const engine = new SeedIntelligenceEngine();
  const { seed } = await engine.compile({ request, knowledgePackets: [packet.packet], randomSeed: 'cache-001' });
  const first = await engine.replay(seed);
  const second = await engine.replay(seed);
  assert.equal(first.cache.hit, false);
  assert.equal(second.cache.hit, true);
  assert.equal(first.document.text, second.document.text);
});

test('multi-packet context is merged with duplicate claim protection', async () => {
  const packetA = await knowledge();
  const packetB = await createKnowledgePacket({ title: 'Extra context', claims: [
    { id: 'water-properties', text: 'Water exists naturally as solid, liquid and gas on Earth.', kind: 'fact', sourceRefs: ['demo:water#states'] }
  ] });
  const engine = new SeedIntelligenceEngine();
  const { seed } = await engine.compile({ request, knowledgePackets: [packetA.packet, packetB.packet], randomSeed: 'multi-context' });
  const result = await engine.replay(seed, { useCache: false });
  assert.equal(result.audit.claimCount, 5);
  assert.equal(result.audit.representedCount, 5);
});

test('duplicate claim IDs across packets are rejected', async () => {
  const packetA = await knowledge();
  const packetB = await createKnowledgePacket({ title: 'Duplicate', claims: [
    { id: 'evaporation', text: 'Different content with a duplicate ID.', kind: 'fact', sourceRefs: ['demo:duplicate'] }
  ] });
  const engine = new SeedIntelligenceEngine();
  const { seed } = await engine.compile({ request, knowledgePackets: [packetA.packet, packetB.packet], randomSeed: 'duplicate-context' });
  await assert.rejects(() => engine.replay(seed, { useCache: false }), /Duplicate claim ID/);
});

test('strategy selection supports the compare task and rejects unknown strategies', async () => {
  const packet = await knowledge();
  const engine = new SeedIntelligenceEngine();
  const compiled = await engine.compile({ request: { ...request, taskType: 'compare' }, knowledgePackets: [packet.packet], randomSeed: 'compare-001' });
  assert.equal(compiled.seed.strategy.id, 'compare_options');
  await assert.rejects(() => engine.compile({ request, knowledgePackets: [packet.packet], strategyId: 'run_shell' }), /Unknown strategy/);
});

test('model adapter contracts reject arbitrary capabilities and tool execution', () => {
  assert.throws(() => validateControllerPlan({ needsMoE: true, capabilities: ['shell_access'] }), /unregistered capability/);
  assert.throws(() => validateMoEResponse({ knowledgePacket: {}, toolRequests: ['shell'] }), /not enabled/);
  assert.deepEqual(validateEditorialResponse({ text: 'edited', preservedClaimIds: ['a', 'b'] }, ['b', 'a']).preservedClaimIds, ['a', 'b']);
  assert.throws(() => validateEditorialResponse({ text: 'edited', preservedClaimIds: ['a'] }, ['a', 'b']), /did not preserve/);
});

test('result output is limited by configured byte budget', async () => {
  const packet = await createKnowledgePacket({ title: 'Oversized', claims: [
    { id: 'large-claim', text: 'x'.repeat(8000), kind: 'fact', sourceRefs: ['demo:large'] }
  ] });
  const engine = new SeedIntelligenceEngine({ maxOutputBytes: 1024 });
  const { seed } = await engine.compile({ request, knowledgePackets: [packet.packet], randomSeed: 'oversized-result' });
  await assert.rejects(() => engine.replay(seed, { useCache: false }), /exceeds 1024 byte output budget/);
});

test('cache has bounded capacity and remains namespaced by seed and engine version', async () => {
  const cache = new SeedCache({ maxBytes: 128, ttlMs: 10000 });
  const packet = await knowledge();
  const engine = new SeedIntelligenceEngine({ cache });
  const { seed } = await engine.compile({ request, knowledgePackets: [packet.packet], randomSeed: 'bounded-cache' });
  const result = await engine.replay(seed);
  assert.ok(result.document.text.length > 0);
  assert.ok(cache.stats.bytes <= cache.stats.maxBytes);
});


test('DreamKernel exposes the seed intelligence layer through the main kernel', async () => {
  const packet = await knowledge();
  const integratedKernel = new (await import('../src/index.js')).DreamKernel({ device: { memoryClassMb: 4096 } });
  const compiled = await integratedKernel.compileReasoningSeed({ request, knowledgePackets: [packet.packet], randomSeed: 'kernel-integration' });
  const result = await integratedKernel.replayReasoningSeed(compiled.seed, { useCache: false });
  assert.equal(result.audit.passed, true);
  assert.equal(result.strategy.id, 'explain_concept');
});

test('invalid task is rejected before context is persisted', async () => {
  const packet = await knowledge();
  const engine = new SeedIntelligenceEngine();
  await assert.rejects(() => engine.compile({ request: { ...request, taskType: 'unknown-task' }, knowledgePackets: [packet.packet] }), /Unsupported task type/);
  assert.equal(engine.contentStore.stats.entries, 0);
});

test('MoE delegation intent cannot be replayed without a real adapter', async () => {
  const packet = await knowledge();
  const engine = new SeedIntelligenceEngine();
  const { seed } = await engine.compile({
    request,
    knowledgePackets: [packet.packet],
    randomSeed: 'moe-intent',
    modelPlan: { needsMoE: true, capabilities: ['scientific_reasoning'] }
  });
  await assert.rejects(() => engine.replay(seed), /does not yet execute a MoE model adapter/);
});

test('seed rejects unknown fields and duplicate context references', async () => {
  const packet = await knowledge();
  const engine = new SeedIntelligenceEngine();
  const { seed } = await engine.compile({ request, knowledgePackets: [packet.packet], randomSeed: 'strict-seed' });
  const extra = structuredClone(seed);
  extra.execute = 'anything';
  await assert.rejects(() => validateReasoningSeed(extra), /unapproved property/);
  const duplicate = structuredClone(seed);
  duplicate.contextRefs.push(duplicate.contextRefs[0]);
  const { sha256Hex } = await import('../src/intelligence/digest.js');
  const { seedId, ...payload } = duplicate;
  duplicate.seedId = await sha256Hex(payload);
  await assert.rejects(() => validateReasoningSeed(duplicate), /Invalid context references/);
});


test('factual claims are never placed under an uncertainty heading', async () => {
  const packet = await createKnowledgePacket({ title: 'Claim placement fixture', claims: [
    { id: 'fact-a', text: 'A sourced factual statement.', kind: 'fact', sourceRefs: ['fixture:fact-a'] },
    { id: 'unknown-a', text: 'The available evidence does not settle this point.', kind: 'unknown', sourceRefs: [] },
    { id: 'hypothesis-a', text: 'One possible explanation remains a hypothesis.', kind: 'hypothesis', sourceRefs: ['fixture:hypothesis-a'] }
  ] });
  const engine = new SeedIntelligenceEngine();
  const { seed } = await engine.compile({ request, knowledgePackets: [packet.packet], randomSeed: 'claim-placement' });
  const result = await engine.replay(seed, { useCache: false });
  assert.equal(result.audit.passed, true);
  assert.deepEqual(result.audit.misplacedClaims, []);
  const uncertainSection = result.document.sections.find(section => /uncertain|unknown|caveat|limitation|qualification|open question|what remains/i.test(section.heading));
  assert.ok(uncertainSection);
  assert.ok(uncertainSection.claimIds.includes('unknown-a'));
  assert.ok(uncertainSection.claimIds.includes('hypothesis-a'));
  assert.ok(!uncertainSection.claimIds.includes('fact-a'));
});


test('factual claims without provenance fail the editorial audit', async () => {
  const packet = await createKnowledgePacket({ title: 'Missing provenance fixture', claims: [
    { id: 'unreferenced-fact', text: 'An unreferenced factual assertion.', kind: 'fact', sourceRefs: [] }
  ] });
  const engine = new SeedIntelligenceEngine();
  const { seed } = await engine.compile({ request, knowledgePackets: [packet.packet], randomSeed: 'missing-provenance' });
  await assert.rejects(() => engine.replay(seed, { useCache: false }), /claim coverage validation/);
});

test('model adapter contracts reject unknown extra fields', () => {
  assert.throws(() => validateControllerPlan({ needsMoE: false, capabilities: [], hidden: true }), /invalid shape/);
  assert.throws(() => validateMoEResponse({ knowledgePacket: { format: 'APOLLO_KNOWLEDGE_PACKET', schemaVersion: 1, title: 'x', claims: [] }, hidden: true }), /invalid shape/);
  assert.throws(() => validateEditorialResponse({ text: 'x', preservedClaimIds: [], hidden: true }, []), /invalid shape/);
});


test('content-store snapshot restores verified knowledge across engine instances', async () => {
  const packet = await knowledge();
  const firstStore = new ContentAddressedStore({ maxBytes: 2 * 1024 * 1024 });
  const { reference } = await firstStore.put(packet.packet);
  const snapshot = await firstStore.exportSnapshot();
  const secondStore = new ContentAddressedStore({ maxBytes: 2 * 1024 * 1024 });
  const restored = await secondStore.restoreSnapshot(snapshot);
  assert.equal(restored.restoredEntries, 1);
  assert.deepEqual(await secondStore.get(reference), packet.packet);
});

test('content-store snapshot restore is atomic and rejects tampering', async () => {
  const packet = await knowledge();
  const sourceStore = new ContentAddressedStore();
  await sourceStore.put(packet.packet);
  const snapshot = await sourceStore.exportSnapshot();
  const broken = structuredClone(snapshot);
  broken.entries[0].value.claims[0].text = 'tampered snapshot';

  const targetStore = new ContentAddressedStore();
  const other = await createKnowledgePacket({ title: 'Existing packet', claims: [
    { id: 'existing', text: 'Existing content.', kind: 'fact', sourceRefs: ['fixture:existing'] }
  ] });
  const { reference: existingRef } = await targetStore.put(other.packet);
  await assert.rejects(() => targetStore.restoreSnapshot(broken), /integrity check failed/);
  assert.equal(targetStore.has(existingRef), true);
  assert.equal(targetStore.stats.entries, 1);
});


test('reasoning compilation also emits a MAKETINY parent Dream seed', async () => {
  const engine = new SeedIntelligenceEngine();
  const packet = await createKnowledgePacket({
    title: 'Apollo dream fixture',
    claims: [{ id: 'apollo-claim-1', text: 'Seed families can derive task-specific child manifests.', kind: 'fact', sourceRefs: ['fixture:maketiny#claim-1'] }]
  });
  const compiled = await engine.compile({
    request: { taskType: 'explain', title: 'Seed families', objective: 'Explain reproductive seed planning.', editorialStyle: 'editorial' },
    knowledgePackets: [packet.packet],
    randomSeed: 'seed-family-integration'
  });
  assert.equal(compiled.dreamSeed.format, 'MAKETINY_PARENT_SEED');
  assert.equal(compiled.dreamSeed.recipe.id, 'apollo_dream_v1');
  assert.equal(compiled.diagnostics.dreamSeedIsReproductivePlan, true);
  const expanded = await engine.expandMakeTinySeed(compiled.dreamSeed);
  assert.ok(expanded.children.some(child => child.role === 'editorial_plan'));
  assert.ok(expanded.children.every(child => child.contextRefs.length === 1));
});
