import test from 'node:test';
import assert from 'node:assert/strict';
import { ApolloVoiceSession, ApolloVoiceUnavailableError, createAndroidApolloVoiceProviders } from '../../src/voice/apollo-voice-session.js';

test('voice session requires explicit offline ASR and TTS providers', async () => {
  const session = new ApolloVoiceSession({ converse: async () => ({ answer: 'Hello' }) });
  await assert.rejects(() => session.listenAndRespond({ sessionId: 's1' }), ApolloVoiceUnavailableError);
  await assert.rejects(() => session.speak('Hello'), ApolloVoiceUnavailableError);
});

test('voice session coordinates one offline ASR → Apollo → TTS turn', async () => {
  const events = [];
  const recognizer = { offline: true, async listenOnce() { events.push('listen'); return { text: 'Explain photosynthesis.' }; }, async stop() {} };
  const synthesizer = { offline: true, async speak(text) { events.push(`speak:${text}`); }, async stop() {} };
  const session = new ApolloVoiceSession({ recognizer, synthesizer, converse: async ({ text }) => { events.push('think'); return { answer: `Answer to ${text}` }; }, onState: state => events.push(state) });
  const result = await session.listenAndRespond({ sessionId: 'session-1' });
  assert.equal(result.userText, 'Explain photosynthesis.');
  assert.equal(result.answer, 'Answer to Explain photosynthesis.');
  assert.ok(events.includes('listening'));
  assert.ok(events.includes('thinking'));
  assert.ok(events.includes('speaking'));
  assert.equal(events.at(-1), 'idle');
});

test('Android voice bridge refuses a non-versioned or cloud-only host', () => {
  assert.throws(() => createAndroidApolloVoiceProviders({ apiVersion: 2, asrOffline: true, ttsOffline: true }), ApolloVoiceUnavailableError);
  const providers = createAndroidApolloVoiceProviders({ apiVersion: 1, asrOffline: false, ttsOffline: true, listenOnce() {}, speak() {} });
  assert.equal(providers.recognizer.offline, false);
  assert.equal(providers.synthesizer.offline, true);
});
