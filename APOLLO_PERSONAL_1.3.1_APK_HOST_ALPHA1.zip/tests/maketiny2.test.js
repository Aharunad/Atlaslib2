import test from 'node:test';
import assert from 'node:assert/strict';
import {
  MakeTiny2Engine,
  MakeTinyRecipeRegistry,
  createQuadraticMetaSeed,
  expandQuadraticMetaSeed,
  inspectQuadraticChildSeed,
  generateQuadraticChunk,
  MAKETINY2_FORMATS
} from '../src/intelligence/maketiny2.js';
import { DreamKernel } from '../src/core/dream-kernel.js';

const dreamParameters = {
  taskType: 'explain',
  objective: 'Explain how photosynthesis converts light energy into chemical energy.',
  editorialStyle: 'editorial',
  capabilities: ['biology', 'chemistry', 'fact_check'],
  sections: ['Overview', 'Mechanism', 'Evidence', 'Limitations', 'Conclusion'],
  voiceEnabled: true,
  visualEnabled: false
};

test('MAKETINY 2.0 recipe registry is fixed and versioned', () => {
  const registry = new MakeTinyRecipeRegistry();
  assert.ok(registry.list().some(item => item.id === 'apollo_dream_v1' && item.version === 1));
  assert.ok(registry.list().some(item => item.id === 'editorial_sections_v1'));
  assert.ok(registry.list().some(item => item.id === 'atomic_task_v1'));
});

test('same parent seed and generation state produce the same family seed', async () => {
  const engine = new MakeTiny2Engine();
  const a = await engine.createRoot({ parameters: dreamParameters, generationSeed: 'apollo-maketiny-root-01' });
  const b = await engine.createRoot({ parameters: dreamParameters, generationSeed: 'apollo-maketiny-root-01' });
  assert.equal(a.seed.seedId, b.seed.seedId);
  assert.equal(a.bytes, b.bytes);
});

test('parent seed procedurally creates compact child seeds for Apollo stages', async () => {
  const engine = new MakeTiny2Engine();
  const root = await engine.createRoot({ parameters: dreamParameters, generationSeed: 'apollo-family-a' });
  const expanded = await engine.expand(root.seed);
  assert.equal(expanded.totalChildren, 4);
  assert.deepEqual(expanded.children.map(item => item.role), ['knowledge_plan', 'moe_plan', 'editorial_plan', 'voice_plan']);
  for (const child of expanded.children) {
    const result = await engine.validate(child);
    assert.equal(result.valid, true);
    assert.equal(child.parentSeedId, root.seed.seedId);
    assert.equal(child.inheritedContextFromParent, true);
  }
});

test('recursive expansion creates nested knowledge, expert and editorial task seeds', async () => {
  const engine = new MakeTiny2Engine();
  const root = await engine.createRoot({ parameters: dreamParameters, generationSeed: 'apollo-family-tree' });
  const tree = await engine.expandTree(root.seed);
  assert.ok(tree.nodeCount > 10);
  assert.equal(tree.truncated, false);
  assert.ok(tree.nodes.some(node => node.role === 'moe_capability_1'));
  assert.ok(tree.nodes.some(node => node.role === 'editorial_section_1'));
  assert.ok(tree.nodes.every(node => node.depth <= 4));
});

test('same parent replay produces byte-identical children', async () => {
  const engine = new MakeTiny2Engine();
  const root = await engine.createRoot({ parameters: dreamParameters, generationSeed: 'stable-family' });
  const first = await engine.expand(root.seed);
  const second = await engine.expand(root.seed);
  assert.deepEqual(first.children, second.children);
});

test('different root generation seeds produce different child generation states', async () => {
  const engine = new MakeTiny2Engine();
  const a = await engine.createRoot({ parameters: dreamParameters, generationSeed: 'variant-a' });
  const b = await engine.createRoot({ parameters: dreamParameters, generationSeed: 'variant-b' });
  const ca = await engine.expand(a.seed);
  const cb = await engine.expand(b.seed);
  assert.notEqual(ca.children[0].generationSeed, cb.children[0].generationSeed);
});

test('parent seed context references flow to child seeds without duplicating source content', async () => {
  const engine = new MakeTiny2Engine();
  const contextRef = `sha256:${'a'.repeat(64)}`;
  const root = await engine.createRoot({ parameters: dreamParameters, contextRefs: [contextRef], generationSeed: 'context-parent' });
  const children = await engine.expand(root.seed);
  assert.ok(children.children.every(child => child.contextRefs.includes(contextRef)));
  assert.ok(children.children.every(child => !('objective' in child.parameters)));
});

test('resource limits stop excessive child generation', async () => {
  const engine = new MakeTiny2Engine();
  const root = await engine.createRoot({ parameters: dreamParameters, generationSeed: 'bounded-parent', maxChildren: 2 });
  await assert.rejects(() => engine.expand(root.seed), /too many child seeds/);
});

test('tampered parent seed is rejected', async () => {
  const engine = new MakeTiny2Engine();
  const root = await engine.createRoot({ parameters: dreamParameters, generationSeed: 'tamper-parent' });
  const tampered = structuredClone(root.seed);
  tampered.parameters.objective = 'Changed objective';
  await assert.rejects(() => engine.validate(tampered), /digest mismatch/);
});

test('seed cannot select unregistered generator code', async () => {
  const engine = new MakeTiny2Engine();
  await assert.rejects(() => engine.createRoot({ recipeId: 'run_arbitrary_javascript', parameters: {}, generationSeed: 'blocked' }), /Unknown MakeTiny recipe/);
});

test('footprint distinguishes transient child generation from persisted storage', async () => {
  const engine = new MakeTiny2Engine();
  const root = await engine.createRoot({ parameters: dreamParameters, generationSeed: 'footprint-parent' });
  const expanded = await engine.expand(root.seed);
  const report = await engine.footprint(root.seed, expanded.children);
  assert.ok(report.generatedChildSeedBytes > 0);
  assert.equal(report.persistedBytesIfChildrenAreRegeneratedOnDemand, report.rootSeedBytes);
  assert.equal(report.persistedBytesIfAllChildrenAreStored, report.rootSeedBytes + report.generatedChildSeedBytes);
  assert.ok(report.expansionFactor > 0);
});

test('MAKETINY parent binary seed expands into a larger 118-byte child seed', async () => {
  const parent = createQuadraticMetaSeed({ count: 65_536_000n, initial: 7n, firstDifference: 3n, secondDifference: 1n });
  const child = await expandQuadraticMetaSeed(parent);
  assert.equal(parent.byteLength, MAKETINY2_FORMATS.quadraticParentBytes);
  assert.equal(child.byteLength, MAKETINY2_FORMATS.quadraticChildBytes);
  assert.ok(child.byteLength > parent.byteLength);
  const decoded = await inspectQuadraticChildSeed(child);
  assert.equal(decoded.count, 65_536_000n);
  assert.equal(decoded.outputBytes, 524_288_000n);
});

test('118-byte child seed deterministically generates the quadratic sequence', async () => {
  const parent = createQuadraticMetaSeed({ count: 16n });
  const child = await expandQuadraticMetaSeed(parent);
  const bytes = await generateQuadraticChunk(child, { count: 8 });
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const values = Array.from({ length: 8 }, (_, index) => view.getBigInt64(index * 8, true));
  assert.deepEqual(values, [7n, 10n, 14n, 19n, 25n, 32n, 40n, 49n]);
});

test('quadratic parent seed detects tampering', async () => {
  const parent = createQuadraticMetaSeed({ count: 100n });
  parent[20] ^= 0x01;
  await assert.rejects(() => expandQuadraticMetaSeed(parent), /parent seed checksum mismatch/);
});

test('quadratic child seed detects tampering', async () => {
  const child = await expandQuadraticMetaSeed(createQuadraticMetaSeed({ count: 100n }));
  const tampered = child.slice();
  tampered[20] ^= 0x01;
  await assert.rejects(() => inspectQuadraticChildSeed(tampered), /checksum mismatch/);
});

test('quadratic generator enforces bounded chunk materialization', async () => {
  const child = await expandQuadraticMetaSeed(createQuadraticMetaSeed({ count: 1000n }));
  await assert.rejects(() => generateQuadraticChunk(child, { count: 1_000_001 }), /outside permitted bounds/);
});

test('DreamKernel exposes MAKETINY family generation as a first-class Apollo service', async () => {
  const kernel = new DreamKernel({ device: { memoryClassMb: 4096 } });
  const root = await kernel.createMakeTinyRoot({ parameters: dreamParameters, generationSeed: 'dream-kernel-maketiny' });
  const children = await kernel.expandMakeTinySeed(root.seed);
  assert.equal(children.children.length, 4);
  const tree = await kernel.expandMakeTinyTree(root.seed);
  assert.ok(tree.nodeCount > 10);
});
