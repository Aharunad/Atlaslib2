import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { performance } from 'node:perf_hooks';
import { MakeTiny2Engine } from '../src/intelligence/maketiny2.js';
import { FileKVAdapter } from '../src/persistence/file-kv-adapter.js';
import { ApolloPersistentStore } from '../src/persistence/apollo-persistent-store.js';
import { createKnowledgePacket } from '../src/intelligence/knowledge-packet.js';
import { canonicalBytes } from '../src/intelligence/digest.js';

const capabilities = Array.from({ length: 16 }, (_, index) => `capability_${String(index + 1).padStart(2, '0')}`);
const sections = Array.from({ length: 64 }, (_, index) => `Editorial section ${String(index + 1).padStart(2, '0')}`);
const packet = await createKnowledgePacket({
  title: 'Apollo Dream Benchmark Context',
  claims: [{ id: 'benchmark-claim-1', text: 'The context packet is a separately stored dependency referenced by the seed.', kind: 'definition', sourceRefs: ['benchmark:fixture'] }]
});

const dir = await mkdtemp(join(tmpdir(), 'apollo-maketiny-bigstep-'));
try {
  const store = new ApolloPersistentStore({ adapter: new FileKVAdapter(join(dir, 'atlas-apollo-store.json')) });
  const savedPacket = await store.putContent(packet.packet);
  const engine = new MakeTiny2Engine({ maxDepth: 4, maxChildren: 128, maxTreeNodes: 512 });
  const parameters = {
    taskType: 'article',
    objective: 'Generate a multi-stage editorial knowledge experience with bounded capability requests and reproducible section plans.',
    editorialStyle: 'editorial',
    capabilities,
    sections,
    contextRefs: [savedPacket.reference],
    voiceEnabled: true,
    visualEnabled: true
  };
  const rootStart = performance.now();
  const root = await engine.createRoot({ parameters, generationSeed: 'apollo-maketiny-v04-big-step' });
  const rootMs = performance.now() - rootStart;
  await store.putSeed(root.seed, seed => engine.validate(seed));

  const count = await engine.countChildren(root.seed);
  const expansionStart = performance.now();
  const fullTree = await engine.expandTree(root.seed, { maxDepth: 2, maxNodes: 200 });
  const expansionMs = performance.now() - expansionStart;
  const totalTreeBytes = fullTree.nodes.reduce((sum, seed) => sum + canonicalBytes(seed), 0);
  const rootBytes = canonicalBytes(root.seed);
  const generatedChildBytes = totalTreeBytes - rootBytes;
  const generatedChildCount = fullTree.nodeCount - 1;

  // Derive one selected child only. No sibling seed objects are created.
  const lazyStart = performance.now();
  const selectedChild = await engine.deriveChild(root.seed, 1);
  const lazyMs = performance.now() - lazyStart;
  const persisted = await store.getSeed(root.seed.seedId, seed => engine.validate(seed));
  const stats = await store.stats();
  const onDemandReduction = totalTreeBytes > 0 ? 100 * (1 - rootBytes / totalTreeBytes) : 0;

  const report = {
    benchmark: 'Apollo Persistent Seed Memory + MAKETINY Lazy Derivation',
    release: '0.4.0',
    fixture: {
      requestedCapabilities: capabilities.length,
      editorialSections: sections.length,
      voicePlan: true,
      visualPlan: true,
      referencedKnowledgePacketBytes: savedPacket.size
    },
    results: {
      rootSeedBytes: rootBytes,
      directChildCount: count,
      expandedTreeNodes: fullTree.nodeCount,
      materializedDerivedSeedBytes: generatedChildBytes,
      completeMaterializedSeedTreeBytes: totalTreeBytes,
      bytesPersistedForSeedFamily: rootBytes,
      estimatedSeedManifestStorageAvoidedByOnDemandDerivationPercent: Number(onDemandReduction.toFixed(3)),
      selectedLazyChildBytes: canonicalBytes(selectedChild),
      selectedLazyChildRole: selectedChild.role,
      selectedLazyChildIndex: selectedChild.childIndex,
      childSeedsPersisted: 0,
      rootSeedSurvivedStoreReopen: Boolean(persisted)
    },
    timingsMs: {
      rootCreation: Number(rootMs.toFixed(3)),
      fullTreeMaterializationReference: Number(expansionMs.toFixed(3)),
      singleChildDerivation: Number(lazyMs.toFixed(3))
    },
    persistentStore: stats,
    interpretation: 'This measures storage avoided by regenerating seed manifests from a parent recipe. It does not compress the referenced knowledge packet, language-model weights or generated information payloads. Full tree materialization is a transient benchmark reference; production derives only the required child.'
  };
  process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
} finally {
  await rm(dir, { recursive: true, force: true });
}
