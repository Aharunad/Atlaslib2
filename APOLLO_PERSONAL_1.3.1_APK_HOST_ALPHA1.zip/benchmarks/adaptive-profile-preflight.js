import { performance } from 'node:perf_hooks';
import os from 'node:os';
import { createAdaptiveModelProfile } from '../src/runtime/adaptive-model-profile.js';

const MiB = 1024 * 1024;
const GiB = 1024 * MiB;
const inspection = Object.freeze({
  format: 'gguf',
  architecture: 'qwen3',
  fileBytes: 420_000_000,
  contextLength: 32768,
  blockCount: 28,
  embeddingLength: 2048,
  headCount: 16,
  headCountKv: 8,
  keyLength: 64,
  valueLength: 64
});
const runtimeCapabilities = Object.freeze({
  available: true,
  formats: ['gguf'],
  architectureCandidates: ['qwen3'],
  backend: 'cpu',
  gpuOffload: false
});
const deviceFor = (ramGiB, cpuCores = 8) => Object.freeze({
  platform: 'android',
  totalRamBytes: ramGiB * GiB,
  availableRamBytes: Math.floor(ramGiB * GiB * 0.72),
  lowRamDevice: ramGiB <= 4,
  lowMemory: false,
  cpuCores,
  supportedAbis: ['arm64-v8a'],
  apiLevel: 35,
  appMemoryClassMb: Math.min(256 + ramGiB * 128, 2048),
  availableStorageBytes: 16 * GiB,
  deviceSignature: `synthetic-${ramGiB}GiB-arm64`
});
const percentile = (sorted, p) => sorted[Math.min(sorted.length - 1, Math.floor((sorted.length - 1) * p))];

const warmup = 500;
const repetitions = 5000;
const rows = [];
for (const ramGiB of [4, 6, 8, 12, 16]) {
  const device = deviceFor(ramGiB);
  for (let index = 0; index < warmup; index++) createAdaptiveModelProfile({ inspection, device, runtimeCapabilities });
  const samples = [];
  let profile;
  for (let index = 0; index < repetitions; index++) {
    const started = performance.now();
    profile = createAdaptiveModelProfile({ inspection, device, runtimeCapabilities });
    samples.push((performance.now() - started) * 1000);
  }
  samples.sort((a, b) => a - b);
  rows.push({
    deviceRamGiB: ramGiB,
    recommendedContext: profile.recommendedContextTokens,
    status: profile.status,
    estimatedWorkingSetMiB: profile.estimatedWorkingSetBytes == null ? null : Math.round(profile.estimatedWorkingSetBytes / MiB),
    modelBudgetMiB: Math.round(profile.memoryBudgetBytes / MiB),
    plannerMedianMicroseconds: Number(percentile(samples, 0.5).toFixed(2)),
    plannerP95Microseconds: Number(percentile(samples, 0.95).toFixed(2))
  });
}
console.log(JSON.stringify({
  benchmark: 'Apollo adaptive GGUF preflight planner',
  host: { node: process.version, platform: process.platform, architecture: process.arch, cpu: os.cpus()[0]?.model ?? 'unknown' },
  kind: 'synthetic metadata-only microbenchmark',
  modelFixture: inspection,
  warmupIterations: warmup,
  measuredIterationsPerDevice: repetitions,
  inferenceExecuted: false,
  rows
}, null, 2));
