# Apollo Personal 1.3.0-alpha.3 — Native GGUF Runtime Source

- Preserved BYOM as the Sleeping Giant delivery strategy.
- Added a JNI runtime implementation based on llama.cpp C APIs.
- Pinned upstream llama.cpp to `785322d17f2d51e5185cf996a1f4e46d87640841`.
- Added an Android library module and GitHub Actions ARM64 AAR build workflow.
- Enabled Arm KleidiAI CPU kernels for runtime-detected ARM64 execution. GPU backends remain disabled.
- Added native model load, model metadata, chat-template formatting, prompt tokenization, temperature-aware and grammar-constrained decode, token streaming, abort callback cancellation and unload.
- Added a smoke generation gate before activating a model for Apollo Sleeping Giant delegation.
- Added NativeLlamaClient and exported it from the Apollo public runtime surface.
- Added GBNF JSON-object constrained sampling and temperature-aware sampling through the Kotlin/JNI bridge.
- Added a native-controller fallback so a loaded GGUF can power Apollo chat and Dream Studio when no dedicated local controller endpoint is reachable. The dedicated controller remains preferred when reachable.
- Added a reproducible adaptive-profile preflight benchmark and release report.
- Added an in-app **Benchmark model** action that measures local prompt-prefill and generation throughput after a model passes its smoke test.
- Reused a single native decode batch across generation steps to avoid per-token allocation. Batched small UTF-8 token pieces before crossing JNI and posting them to the WebView, reducing per-token host event overhead.
- Renamed native architecture declarations to architecture candidates. Exact GGUF files still require native load and inference tests.
- Updated service-worker cache contents and release cache identity.

## Validation

- JavaScript test suite: 144 passed, 0 failed.
- Kotlin JNI facade and Android host bridge: compiled against lightweight Android/JSON API stubs.
- JNI C++ translation unit: syntax-checked against Java 21 JNI headers and a minimal llama API declaration stub.
- Android SDK/NDK build: not run in this environment. The CI build pins NDK `29.0.13113456` and CMake `3.31.6`. The GitHub Actions workflow must perform the real pinned upstream checkout and AAR build.
- Adaptive profile microbenchmark: 5,000 measured planning runs per synthetic 4, 6, 8, 12 and 16 GiB profile after 500 warmups. Median planning latency in the latest run: 2.02–2.77 μs. P95: 2.39–6.43 μs. No model was loaded.
- Physical-device GGUF inference benchmarks: not run. No Android device or model weights were available.

## Release boundary

This is a source milestone, not an APK. The archive contains the application-facing JNI and Kotlin integration source, but it does not contain the upstream llama.cpp checkout or compiled native libraries. The AAR build and physical Android qualification remain required.
