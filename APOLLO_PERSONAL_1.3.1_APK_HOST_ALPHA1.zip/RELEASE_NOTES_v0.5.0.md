# Apollo's Dream v0.5.0 — Runtime Governance + Miracle Insights 1.0

## Major additions

### Model Runtime Supervisor
- Dynamic memory budget from live OS telemetry, system reserve, memory class, low-memory and thermal state.
- Working-set accounting for model base memory and per-session KV-cache reservations.
- Model load/lease/release/unload lifecycle behind a native runtime adapter.
- Warm and ephemeral cache policies.
- Idle LRU/priority eviction; active leases are never evicted.
- Memory-pressure handling, cancellation cleanup and measured-footprint rejection.

### Apollo 1.0 governance
- Definitive versioned release programme and gate-based schedule.
- MIRACLE Insights 1.0 catalogue.
- Model/runtime/license qualification register.
- Android host bridge contract and model-manifest schema.

## Validation
- Complete suite: **89 passed, 0 failed**.
- Runtime supervisor: **15 passed, 0 failed**.

## Not included
- No real pretrained SLM inference.
- No MoE checkpoint or expert runtime.
- No Android native memory bridge.
- No physical 4 GB hardware benchmark.
- No ASR/Pocket TTS integration.
- No production Atlas Library Android application integration or APK.
