# Apollo Personal 1.3.1 — APK Host Alpha 1

## Fixed build architecture

- Confirmed the previous source ZIP had no `gradlew` wrapper.
- Kept `android-host` as a reusable Android library.
- Added `:host-app` as an installable Android application module depending on the native library.
- Added an AndroidX WebViewAssetLoader host for the existing Apollo web feature.
- Added strict trusted-origin loading and blocked external WebView origins, file access and mixed content.
- Added a Gradle asset-sync task that preserves the existing `demo/` and `src/` relative paths.
- The correct build task is `:host-app:assembleDebug`, using system Gradle 8.11.1.
- CI explicitly sets `packages: platform-tools` for setup-android v3 so it does not request the deprecated `tools` SDK package.

## Expected artifact

`android-host/host-app/build/outputs/apk/debug/host-app-debug.apk`

The app is an Apollo test harness. Apollo's production destination remains the Atlas Library feature module.

## Acceptance boundary

This source package is prepared for the GitHub Android build. The current environment does not have Android SDK/NDK or a phone connected, so it has not been represented as a successful APK build or physical-device inference run. CI must compile and verify the ARM64 JNI library inside the APK before the artifact is accepted.
